function setup() {
  createCanvas(400, 400);
  tiles = [];
  paused = false;
  screenCenter = createVector(width / 2, height / 2);

  logFrameRate = [];
  avgFrameRate = frameRate();

  gridsize = 300;
  tileBuffer = 2;
  
  cam = new Camera();
  ship = new Ship();
  
  shipMover = [false, false, false, false];

  for (let i = -tileBuffer; i < width / gridsize + tileBuffer-1; i++) {
    for (let j = -tileBuffer; j < height / gridsize + tileBuffer-1; j++) {
      tiles.push(new Tile([i, j]));
    }
  }
  tiles = sort2Darray(tiles);
  cam.updateCornerIndices();
  cam.shiftByOffset();
}

function draw() {
  background(0, 255, 0);
  if (!paused) {
    checkInput();
    ship.updateTrueLoc();
    ship.checkCollision();
    cam.updateMapPos();
    for (let i = 0; i < tiles.length; i++) {
      tiles[i].update();
    }
    ship.updateMisc();
    
  }
  
  for (let i = 0; i < tiles.length; i++) {
    tiles[i].displayFill();
  }
  
  for (let i = 0; i < tiles.length; i++) {
    tiles[i].display();
  }
  
  cam.display();
  ship.display();

  Debugger.displayBottomLeft([ship.vel.mag()]);
  updateFrameRate();
  displayFrameRate();
}

function updateFrameRate() {
  var lArray = 30;
  if (logFrameRate.length >= lArray) {
    logFrameRate.splice(0, 1);
  }
  logFrameRate.push(frameRate());
  var avg = 0;
  for (let i = 0; i < logFrameRate.length; i++) {
    avg += logFrameRate[i];
  }
  avgFrameRate = avg / logFrameRate.length;
}

function displayFrameRate(){
  var notRed = map(avgFrameRate, 30, 55, 0, 255);
  noStroke();
  fill(255, notRed, notRed, 200);
  text(parseInt(avgFrameRate), width - 25, 20);
}

