class Hitbox {
  constructor(){
   this.elements = []; 
    
    this.elements.push(new HBE(createVector(-7, 0), 5));
    this.elements.push(new HBE(createVector(1, 0), 3));
    this.elements.push(new HBE(createVector(6, 0), 2));
    this.elements.push(new HBE(createVector(11, 0), .5));
    this.elements.push(new HBE(createVector(-11, -5), 1));
    this.elements.push(new HBE(createVector(-11, 5), 1));
  }
  
  updateTrueLoc(shipTrueLoc, shipAng){
    
    for(let i = 0; i < this.elements.length; i++){
      this.elements[i].updateTrueLoc(shipTrueLoc, shipAng);
    }
  }
  
  updateScreenPos(shipScreenPos, shipAng){
    for(let i = 0; i < this.elements.length; i++){
      this.elements[i].updateScreenPos(shipScreenPos, shipAng);
    }
  }
  
  display(){
    for(let i = 0; i < this.elements.length; i++){
      this.elements[i].display();
    }
  }
}

class HBE { //HitBoxElement
  constructor(pos, r) {
    this.pos = pos;
    this.r = r;
    this.trueLoc = createVector();
    this.screenPos = createVector();
  }

  updateTrueLoc(shipTrueLoc, shipAng) {
    this.trueLoc.set(shipTrueLoc.copy().add(this.pos.copy().rotate(shipAng)));
  }
  
  updateScreenPos(shipScreenPos, shipAng){
    this.screenPos.set(shipScreenPos.copy().add(this.pos.copy().rotate(shipAng)));
  }

  display() {
    
      noFill();
      strokeWeight(1);
      stroke(255, 0, 0);
      circle(this.screenPos.x, this.screenPos.y, this.r);
    
  }
}