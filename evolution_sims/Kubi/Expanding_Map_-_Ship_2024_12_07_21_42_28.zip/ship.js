class Ship {
  constructor() {
    this.l = 24;
    this.w = 12;

    this.trueLoc = screenCenter.copy().sub(cam.offset);
    this.trueLocPrevFrame = createVector();
    this.rearLoc = createVector();
    this.vel = createVector();
    this.acc = createVector();
    this.ang = -HALF_PI;

    this.turnrate = 0.06;
    
    this.dampening = 0.995;
    this.maxV =25;
    this.maxBoost = this.maxV*0.018;//.35;

    this.hitbox = new Hitbox();

    this.velDisplay = createVector();
  }

  turn(dir) {
    if (dir == 0) {
      this.ang -= this.turnrate;
    } else {
      this.ang += this.turnrate;
    }
  }

  thrust(dir) {
    var boost = map(this.vel.mag(), 0, this.maxV, this.maxBoost, this.maxBoost * .4);
    if (dir == 0) {
      this.acc.x = cos(this.ang) * boost;
      this.acc.y = sin(this.ang) * boost;
    } else {
      this.acc.x = -cos(this.ang) * this.maxBoost * 0.5;
      this.acc.y = -sin(this.ang) * this.maxBoost * 0.5;
    }
  }

  updateTrueLoc() {
    this.trueLocPrevFrame = this.trueLoc.copy();
    this.vel.add(this.acc);
    this.trueLoc.add(this.vel);
    this.acc.mult(0);
    this.vel.mult(this.dampening);
    this.vel.limit(this.maxV);
    this.rearLoc = this.trueLoc.copy().add(createVector(-this.l / 2, 0).rotate(this.ang));
  }

  /*updateHitboxTrueLoc() {
    this.hitbox.updateTrueLoc(this.trueLoc, this.ang);
  }*/

  updateMisc() {

    this.velDisplay.set(this.trueLoc.copy().add(this.vel.copy().mult(10)));
  }

  checkCollision() {
    var dist;
    for (let i = 0; i < this.hitbox.elements.length; i++) {
      for (let j = 0; j < tiles.length; j++) {
        if (tiles[j].containsBoulder) {
          dist = this.trueLoc.copy().sub(tiles[j].boulder.trueLoc).mag();
          if (dist < tiles[j].boulder.r) {
            for (let k = 0; k < tiles[j].boulder.elements.length; k++) {

              dist = this.hitbox.elements[i].trueLoc.copy().sub(tiles[j].boulder.elements[k].trueLoc).mag();
              if (abs(dist) < this.hitbox.elements[i].r + tiles[j].boulder.elements[k].r) {
                //paused = true;
                this.repel(tiles[j].boulder);
                break;
              }
            }
          }
        }
      }
    }
  }

  repel(boulder) {
    var ray = ship.vel.copy().mult(-1);
    
    
    
    //find hbe that first touched the boulder


    //calculate distance ship needs to be reset
    //calculate repulsion angle
  }


  display() {
    push();
    translate(cam.toScreen(this.trueLoc).x, cam.toScreen(this.trueLoc).y);
    rotate(this.ang);
    fill(0);
    strokeWeight(1);
    stroke(255);
    triangle(-this.l / 2, -this.w / 2, this.l / 2, 0, -this.l / 2, this.w / 2);
    pop();

    var opac = map(this.vel.mag(), 0, this.maxV, 50, 255);
    stroke(50, 200, 240, opac);
    strokeWeight(4);
    line(cam.toScreen(this.trueLoc).x, cam.toScreen(this.trueLoc).y, cam.toScreen(this.velDisplay).x, cam.toScreen(this.velDisplay).y);

    //this.hitbox.display();

    stroke(255, 0, 0);
    strokeWeight(2);
    //line(this.screenPos.x, this.screenPos.y, center.x, center.y);

    stroke(255, 150);
    strokeWeight(1);
    line(screenCenter.x - 10, screenCenter.y, screenCenter.x + 10, screenCenter.y);
    line(screenCenter.x, screenCenter.y - 10, screenCenter.x, screenCenter.y + 10);
    /*
    noStroke();
    fill(255);
    text(this.velocity.mag(), 5, height-5);
    */
    stroke(255);
    strokeWeight(3);
    //point(mc.toScreen(this.rearLoc).x, mc.toScreen(this.rearLoc).y);

    fill(255);
    noStroke();
    var debugText = round(this.trueLoc.x) + ", " + round(this.trueLoc.y);
    text(debugText, cam.toScreen(this.trueLoc).x + 15, cam.toScreen(this.trueLoc).y + 15);
  }
}