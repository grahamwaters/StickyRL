class Boulder {
  constructor(trueLocChunk, relPosInChunk) {
    var nElements = round(random(10, 20));
    var minElementR = 10;
    var maxElementR = 20;
    this.r = 50;

    this.relPosInChunk = relPosInChunk;
    this.trueLoc = p5.Vector.add(trueLocChunk, this.relPosInChunk);
    this.screenPos = createVector();

    this.elements = new Array(nElements);
    this.elements[0] = new BoulderElement(this.trueLoc, createVector(0, 0), random(minElementR, maxElementR));

    var rElement, indexFather, father, rFather, minDist, maxDist, relAng, pos;

    for (let i = 1; i < nElements; i++) {
      rElement = round(random(minElementR, maxElementR));
      indexFather = floor(random(0, i));
      pos = createVector();
      father = this.elements[indexFather];
      rFather = father.r;
      minDist = 0;
      maxDist = 0;
      relAng = random(TWO_PI);

      if (rElement >= rFather) {
        minDist = rElement - rFather;
        maxDist = (rElement + rFather) * 0.6;
      } else if (rElement < rFather) {
        minDist = rFather - rElement;
        maxDist = (rFather + rElement) * 0.6;
      }

      pos.x = father.relPosToBoulderCenter.x + random(cos(relAng) * minDist, cos(relAng) * maxDist);
      pos.y = father.relPosToBoulderCenter.y + random(sin(relAng) * minDist, sin(relAng) * maxDist);
      this.elements[i] = new BoulderElement(this.trueLoc, pos, rElement);
    }
  }

  updateScreenPos(chunkLoc) {
    this.screenPos = p5.Vector.add(chunkLoc, this.relPosInChunk);
    for (let i = 0; i < this.elements.length; i++) {
      this.elements[i].updateScreenPos(this.screenPos);
    }
  }

  display() {
    for (let i = 0; i < this.elements.length; i++) {
      this.elements[i].display();
    }
  stroke(255, 70);
    strokeWeight(1);
    noFill();
    circle(this.screenPos.x, this.screenPos.y, this.r);
  }
}


class BoulderElement {
  constructor(boulderTrueLoc, relPosToBoulderCenter, r) {
    this.relPosToBoulderCenter = relPosToBoulderCenter;
    this.r = r;
    this.trueLoc = p5.Vector.add(boulderTrueLoc, relPosToBoulderCenter);
    this.screenPos = createVector();
  }

  updateScreenPos(centerPos) {
    this.screenPos.set(p5.Vector.add(centerPos, this.relPosToBoulderCenter));
  }

  display() {

    stroke(255);
    strokeWeight(1);
    fill(255, 0, 0);
    circle(this.screenPos.x, this.screenPos.y, this.r);

    fill(255);
    noStroke();
    var debugText = round(this.trueLoc.x) + ", " + round(this.trueLoc.y);
    //text(debugText, this.screenPos.x, this.screenPos.y);

  }

}