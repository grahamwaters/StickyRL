function checkInput() {
  if (shipMover[0]) { //left
    ship.turn(0);
  }
  if (shipMover[2]) { //right
    ship.turn(1);
  }
  if (shipMover[1]) { //forward
    ship.thrust(0);
  }
  if (shipMover[3]) { //back
    ship.thrust(1);
  }
}

function keyPressed() {
  //moving
  if (key === "a" || key === "A") {
    shipMover[0] = true;
  }
  if (key === "w" || key === "W") {
    shipMover[1] = true;
  }
  if (key === "s" || key === "S") {
    shipMover[3] = true;
  }
  if (key === "d" || key === "D") {
    shipMover[2] = true;
  }
  
  if (key === "p" || key === "P") {
    paused = !paused;
  }
  
  if (key === "l" || key === "L") {
    mapController.logChunks();
  }
}

function keyReleased() {

  if (key === "a" || key === "A") {
    shipMover[0] = false;
  }
  if (key === "w" || key === "W") {
    shipMover[1] = false;
  }
  if (key === "s" || key === "S") {
    shipMover[3] = false;
  }
  if (key === "d" || key === "D") {
    shipMover[2] = false;
  }
}