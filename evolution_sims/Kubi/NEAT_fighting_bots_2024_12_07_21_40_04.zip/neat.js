class Neat {
  constructor(nGenomes, nInputs, nOutputs, prePopulate) {
    this.nGenomes = nGenomes
    
    this.innovationTracker = new InnovationTracker()
    this.innovationTracker.increaseInnoNumberBy(nInputs + nOutputs)
    if(prePopulate) {
      this.innovationTracker.createDefaultConnections(nInputs, nOutputs)
    }
    
    this.evolutionController = new EvolutionController(nGenomes, this.innovationTracker)
    
    this.genomes = []
    for(let i = 0; i < this.nGenomes; i++){
      let newGenome = new Genome(nInputs, nOutputs, i)
      newGenome.createNodes()
      if(prePopulate) newGenome.createAllConnections(this.innovationTracker)
      this.genomes.push(newGenome)
    }
  }
  
  createNextGeneration(){
    this.genomes = this.evolutionController.evolve(this.genomes)
  }
      
  processInput(indGenome, inputs){
    let result = this.genomes[indGenome].process(inputs)
    return result
  }
  
  wire(genome, inNodeID, outNodeID){
    genome.addConnectionMutation(inNodeID, outNodeID, this.innovationTracker)
  }
  
  setupRendering(indGenome, x, y, w, h){
    this.genomes[indGenome].setupRendering(x, y, w, h)
  }
    
  calcRenderLocs(indGenome){
    this.genomes[indGenome].calcRenderLocs()
  }
  
  render(indGenome){
    this.genomes[indGenome].render()
  }
}