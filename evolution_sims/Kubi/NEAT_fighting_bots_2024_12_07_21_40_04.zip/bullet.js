class Bullet {
  constructor(loc, dir, arena, origin, enemy, spray) {

    //movement
    this.loc = loc;
    this.speed = 15 - spray * 5  // = 12
    this.vel = dir.setMag(this.speed).rotate(random(-spray * 0.7,spray*0.7))
    
    // arena
    this.arena = arena
    
    // origin and enemy
    this.origin = origin
    this.enemy = enemy

    //status
    this.collided = false; //false until bullet hits wall, border or unit

    //bullet color
    this.clr = color(60, 255, 150)
  }

  update() {
    this.move();
    this.checkEnemyCollision()
    this.checkWallCollision();
  }

  move() {
    this.loc.add(this.vel);
  }

  checkWallCollision() {
    let locToCenter = p5.Vector.sub(this.loc, this.arena.center)
    let distToCenter = locToCenter.mag()
    
    if (distToCenter >= this.arena.dia/2) {
      this.loc.add(locToCenter.mult(-1).setMag(distToCenter - this.arena.dia/2))
      this.handleCollision("wall");
    }
  }
  
  checkEnemyCollision(){
    let locToEnemy = p5.Vector.sub(this.loc, this.enemy.loc)
    let distToEnemy = locToEnemy.mag();
    
    if(distToEnemy <= this.enemy.dia/2) {
      this.loc.add(locToEnemy.setMag(this.enemy.dia/2-distToEnemy))
      this.handleCollision("enemy");
    }
  }

  handleCollision(type) {
    // transform to switch case statement!!!
    
    this.collided = true;
    /*
    if(manager.fights[this.fightID].isRendered){
      animationHandler.initAnimation(new ProjectileBurst(this.loc.copy()));
    }*/
    
    if(type == "enemy") {
       this.enemy.life.changeCount(-10)
      this.origin.brain.stats.enemyShot ++
      this.enemy.brain.stats.shot ++
    }
  }

  render() {
    let temp = this.vel.copy().mult(-1).setMag(15).add(this.loc);
    stroke(this.clr);
    strokeWeight(6);
    line(this.loc.x, this.loc.y, temp.x, temp.y);

  }
}