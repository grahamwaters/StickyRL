// long list: https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
// recommendations: https://towardsdatascience.com/neuro-evolution-on-steroids-82bd14ddc2f6

class Activation {
  static sigmoid(x) {
    // NEAT paper uses a modified sigmoid function!
    // see here ways to modify: https://en.wikipedia.org/wiki/Logistic_function
    return 1 / (1 + Math.exp(-x));
  }
  
  static modifiedSigmoid(x){
    // modified as in NEAT paper
    return 1 / (1 + Math.exp(-4.9 * x));
  }
  
  static reLU(x){
    // https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
    if(x > 0) return x
    else return 0
  }
  
  static hyperbolicTangent(x){
    // https://en.wikipedia.org/wiki/Hyperbolic_functions
    let numerator = Math.exp(2 * x) - 1
    let denominator = Math.exp(2 * x) + 1
    return numerator / denominator
  }
  
  static hardHyperbolicTangent(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return max(-1, min(1, x))
  }
  
  static identity(x) {
    // https://en.wikipedia.org/wiki/Identity_function
    return x
  }
  
  static binaryStep(x) {
    // https://en.wikipedia.org/wiki/Heaviside_step_function
    if(x > 0) return 1
    else return 0
  }
  
  static bipolar(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    if(x > 0) return 1
    if(x < 0) return -1
    else return 0
  }
  
  static bipolarSigmoid(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    let numerator = 1 - Math.exp(-x)
    let denominator = 1 + Math.exp(-x)
    return numerator / denominator
  }
  
  static absolute(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return abs(x)
  }
  
  static gaussian(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return exp(-0.5 * sq(x))      
  }
  
  static piecewiseLinear(x, xMin, xMax){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    if(x < xMin) return 0
    if(x > xMax) return 1
    
    let m = 1 / (xMax - xMin)
    let b = 1 - m * xMax
    return m * x + b
  }
}