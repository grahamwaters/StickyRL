class Species {
  constructor(representative){
    this.representative = representative
    
    this.members = []
    this.members.push(this.representative)
    
    this.totalAdjustedFitness = 0 
  }
  
  addAdjustedFitness(adjustedFitness){
    this.totalAdjustedFitness += adjustedFitness
  }
  
  kill(percentage){
     // https://www.youtube.com/watch?v=1fFumsDw1xk 15:40
    // https://www.youtube.com/watch?v=qB80QOtv6j8&t=1s 07:40
    
    // sort members by fitness
    
    // kill the worst ones
  }
  
  reset(){
   // https://www.youtube.com/watch?v=PXxRjKNX1uw&t=2145s 15:30 
    
    // choose a random member as next representative
    let randInd = floor(random(this.members.length))
    
    this.representative = this.members[randInd]

    this.members = []
    this.totalAdjustedFitness = 0
  }
}