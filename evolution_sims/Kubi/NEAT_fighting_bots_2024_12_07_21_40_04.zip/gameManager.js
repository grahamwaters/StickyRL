class GameManager {
  constructor() {
    this.generationCount = new Counter("ascending", 1);
    this.nGenomes = 150
    this.fightsPerBot = 10
    
    this.timer = new Counter("ascending", 0, 1200)
    
    this.arena = new Arena(10, 10, 500)

    this.neat = new Neat(this.nGenomes, 10, 8, false)
    for(let g of this.neat.genomes){
      this.neat.wire(g, 1, 12)  // wall front -> move medial
      this.neat.wire(g, 1, 13)  // wall front -> move medial
      this.neat.wire(g, 2, 14)  // wall right -> move lateral
      this.neat.wire(g, 2, 15)  // wall right -> move lateral
      this.neat.wire(g, 3, 12)  // wall back -> move medial
      this.neat.wire(g, 3, 13)  // wall back -> move medial
      this.neat.wire(g, 4, 14)  // wall left -> move lateral
      this.neat.wire(g, 4, 15)  // wall left -> move lateral
      this.neat.wire(g, 5, 16)  // enemy left -> turn
      this.neat.wire(g, 5, 17)  // enemy left -> turn
      this.neat.wire(g, 5, 11)  // enemy left -> mobility
      this.neat.wire(g, 6, 16)  // enemy right -> turn
      this.neat.wire(g, 6, 17)  // enemy right -> turn
      this.neat.wire(g, 6, 11)  // enemy right -> mobility
      this.neat.wire(g, 7, 12)  // dist enemy -> move medial
      this.neat.wire(g, 7, 13)  // dist enemy -> move medial
      this.neat.wire(g, 7, 11)  // dist enemy -> mobility
      this.neat.wire(g, 8, 14)  // bullet left -> move lateral
      this.neat.wire(g, 8, 15)  // bullet left -> move lateral
      this.neat.wire(g, 8, 11)  // bullet left -> mobility
      this.neat.wire(g, 9, 14)  // bullet right -> move lateral
      this.neat.wire(g, 9, 15)  // bullet right -> move lateral
      this.neat.wire(g, 9, 11)  // bullet right -> mobility
      this.neat.wire(g, 10, 18)  // gun charge -> shoot
      this.neat.wire(g, 10, 11)  // gun charge -> mobility
    }
    
    this.overrideGenomes()
    this.overrideEvaluation()

    this.initFights()
    this.setupRendering()
    
  }

  initFights() {
    this.fights = []
    
    // each bot fights in n (='fightsPerBot') separate fights at once against random opponents
    for(let i = 0; i < this.fightsPerBot; i++){
      // create temporary copy of genome array from which items can be deleted
    let tempGenomes = this.neat.genomes.slice()
    
      // randomly choose brains for each fight
      for(let j = 0; j < this.nGenomes / 2; j++){

        let randInd = floor(random(tempGenomes.length))
        if(j == 0) randInd = 0  // first fight contains best brain (= first in genome array)
        let brain0 = tempGenomes.splice(randInd, 1)[0]

        randInd = floor(random(tempGenomes.length))
        let brain1 = tempGenomes.splice(randInd, 1)[0]

        this.fights.push(new Fight([brain0, brain1], this.arena))
      }
    }
  }
  
  
  
  newGeneration() {
    this.neat.createNextGeneration()
    
    print("Gen " + this.generationCount.count + ", avg fitness: " + roundDecimals(this.neat.evolutionController.avgFitness, 1) + ", species: " + this.neat.evolutionController.species.length)
          
    this.overrideGenomes()
    this.initFights()
    this.setupRendering()
    
    // other settings
    this.timer.reset()
    this.generationCount.update();
  }

  update() {
    for (let f of this.fights) f.update();
    
    this.timer.update();
    if (this.timer.finished()) this.newGeneration()
  }
  
  setupRendering(){
    // render fight with best bot of previous generation (= index 0, since best genome is stored in index 0 of genome list)
    this.renderedFight = this.fights[this.nGenomes * this.fightsPerBot * 0.5 - this.nGenomes / 2]
    this.renderedFight.bots[0].renderAll = true
    this.neat.genomes[0].setupRendering(width - 220, 10, 200, 200)
    this.neat.genomes[0].calcRenderLocs()
  }

  render() {
    this.arena.render()
    this.renderedFight.render()
    this.displayInfo()
    this.neat.genomes[0].render()
  }
  
  overrideGenomes() {
    for(let g of this.neat.genomes){
      g.stats = {
        wallTouched: 0,
        enemyTouched: 0,
        enemyShot: 0,
        shot: 0
      }
    }
  }

  overrideEvaluation() {
    this.neat.evolutionController.calcFitness = function(genome) {
      
      let fitness = 100
      fitness += genome.stats.enemyShot
      fitness -= genome.stats.shot * 5
      
      if(genome.stats.wallTouched > 0){
        fitness -= genome.stats.wallTouched * 0.1
      }
      if(genome.stats.enemyTouched > 0){
        fitness -= genome.stats.enemyTouched * 0.5
      }
      
      if(fitness <= 0) fitness = 0.00001
      return fitness
    }
  }

  displayInfo() {

    fill(255)
    noStroke();
    textSize(12)
    textAlign(LEFT, TOP)
    let str = round(this.timer.count / this.timer.threshold * 100) + "%"
    text(str, 5, 5)

    str = "fights: " + this.nGenomes / 2 * this.fightsPerBot;
    text(str, 5, 20)
    
    str = "genomes: " + this.nGenomes
    text(str, 5, 35)
    
    str = "species: " + this.neat.evolutionController.species.length
    text(str, 5, 50)

    str = "generation: " + this.generationCount.count;
    text(str, 5, 65)
    
    str = "score genome class: " + this.neat.evolutionController.calcFitness(this.neat.genomes[0])
    text(str, 5, 80)
    
    str = "wallTouched: " + this.neat.genomes[0].stats.wallTouched
    text(str, 5, 95)
    
    str = "enemyTouched: " + this.neat.genomes[0].stats.enemyTouched
    text(str, 5, 110)
    
    str = "enemyShot: " + this.neat.genomes[0].stats.enemyShot
    text(str, 5, 125)
    
    str = "shot: " + this.neat.genomes[0].stats.shot
    text(str, 5, 140)
  }
}