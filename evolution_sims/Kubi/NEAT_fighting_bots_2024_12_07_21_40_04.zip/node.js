class Node {
  constructor(type, id, layer, bias) {
    this.type = type  // types: input / hidden / output
    this.bias = bias
    this.id = id
    this.layer = layer
    this.inConnections = []
  }
  
  process(genome){
     let sum = 0
    
     for(let conID of this.inConnections){
       let connection = genome.connections.get(conID)
        
        if(connection.enabled){
          let prevNode = genome.nodes.get(connection.inNodeID)
           sum += prevNode.output * connection.weight
        }
     }
    if(this.type != "input") sum += this.bias
    
    let output = Activation.modifiedSigmoid(sum)
    this.output = output
  }
  
  copy(){
    let clone = new Node(this.type, this.id, this.layer, this.bias)
    clone.inConnections = this.inConnections.slice()
    return clone
  }
  
  render() {
    stroke(0)
    strokeWeight(1)
    if(this.output != undefined){
       fill(map(this.output, 0, 1, 0, 255)) 
    }
    else fill(255)
    circle(this.renderLoc.x, this.renderLoc.y, 10)
  }
}