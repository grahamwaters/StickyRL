class Evaluator {
  constructor(popSize, maxGeneration, prePopulate, test) {
    this.test = test
    this.maxGeneration = maxGeneration
    this.generation = 1
    this.neat = new Neat(popSize, 3, 2, prePopulate)

    this.overrideTest()
    this.printStats()
    
    this.finished = false
  }

  update() {
    if (!this.finished) {
      this.neat.createNextGeneration()
      this.generation++
      this.printStats()
    }
    if (this.generation >= this.maxGeneration) {
      this.finished = true
    }
  }

  printStats() {
    let customString = ""
    if (this.test == "totalWeight10") {
      if (this.neat.evolutionController.fittestGenome) {
        let totalWeight = 0
        for (let c of this.neat.evolutionController.fittestGenome.connections.values()) {
          totalWeight += c.weight
        }
        customString = ", total weight: " + roundDecimals(totalWeight, 2) + " (" + (roundDecimals(abs(10 - totalWeight), 2) + ")")
      }
    }
    print("Gen " + this.generation + ", highest fitness: " + roundDecimals(this.neat.evolutionController.highestActualFitness, 1) + ", species: " + this.neat.evolutionController.species.length + customString)
    
    
    fill(0)
    noStroke()
    rect(this.generation*2, 420, 2, this.neat.evolutionController.highestActualFitness)
  }

  overrideTest() {
    switch (this.test) {
      case "absWeightTotal":
        this.neat.evolutionController.calcFitness = function(genome) {
          let absSum = 0
          for (let c of genome.connections.values()) {
            absSum += abs(c.weight)
          }
          return absSum
        }
        break

      case "maxWeightTotal":
        this.neat.evolutionController.calcFitness = function(genome) {
          let sum = 0
          for (let c of genome.connections.values()) {
            sum += c.weight
          }
          if (sum <= 0) sum = 0.00000001
          return sum
        }
        break

      case "minWeightTotal":
        this.neat.evolutionController.calcFitness = function(genome) {
          let sum = 0
          for (let c of genome.connections.values()) {
            sum += c.weight
          }
          sum *= -1
          if (sum <= 0) sum = 0.00000001
          return sum
        }
        break

      case "totalWeight10":
        this.neat.evolutionController.calcFitness = function(genome) {
          let sum = 0
          for (let c of genome.connections.values()) {
            sum += c.weight
          }
          let diff = abs(10 - sum)

          return 1000 / diff
        }
        break

      case "maxConnections":
        this.neat.evolutionController.calcFitness = function(genome) {
          let nConnections = genome.connections.size
          return nConnections
        }
        break

      case "minConnections":
        this.neat.evolutionController.calcFitness = function(genome) {
          let nConnections = genome.connections.size
          return 1000 / nConnections
        }
        break

      case "maxNodes":
        this.neat.evolutionController.calcFitness = function(genome) {
          let nNodes = genome.nodes.size
          return nNodes
        }
        break

      case "minNodes":
        this.neat.evolutionController.calcFitness = function(genome) {
          let nNodes = genome.nodes.size
          return 1000 / nNodes
        }
        break

      case "maxDisabledCons":
        this.neat.evolutionController.calcFitness = function(genome) {
          let nDisabledCons = 0
          for (let c of genome.connections.values()) {
            if (!c.enabled) nDisabledCons++
          }
          if (nDisabledCons <= 0) nDisabledCons = 0.00000001
          return nDisabledCons
        }
        break
    }
  }
}