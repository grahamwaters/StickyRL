class Bot {
  constructor(brain, fight, arena, socket) {
    this.brain = brain
    this.fight = fight
    this.arena = arena

    this.alive = true

    // location and angle
    this.ang = random(0, TWO_PI)
    this.loc = this.arena.sockets[socket].copy()

    // geometry
    this.dia = 28;
    this.wGun = this.dia * 0.15;
    this.lGun = this.dia * 0.7;

    // life
    this.life = new Counter("descending", 500, 0)

    // gun
    this.gunCharge = new Counter("ascending", 0, 50)

    // wall detection
    this.rWallVision = this.arena.dia / 4;
    this.wallRays = [];
    this.wallRays[0] = createVector(this.rWallVision, 0)
    this.wallRays[1] = createVector(0, this.rWallVision);
    this.wallRays[2] = createVector(-this.rWallVision, 0);
    this.wallRays[3] = createVector(0, -this.rWallVision);
    this.wallRayCollisions = [];

    // mobility
    this.mobility = 1.5

    // vision
    this.minVision = PI * 0.05
    this.maxVision = PI * 0.4
    this.vision = map(this.mobility, 1, 2, this.maxVision, this.minVision)

    this.brainInput = {
      wallRay0: 0,
      wallRay1: 0,
      wallRay2: 0,
      wallRay3: 0,
      angEnemyLeft: 0,
      angEnemyRight: 0,
      distEnemy: 0,
      //rotEnemy: 0,
      dangerBulletLeft: 0,
      dangerBulletRight: 0,
      //angBullet: 0,
      //distBullet: 0
      gunCharge: 0
    }
  }

  update() {
    this.perceive()
    this.process();

    this.checkEnemyCollision();
    this.checkWallCollision();

    if (!this.gunCharge.finished()) this.gunCharge.update()

    if (this.life.finished()) this.alive = false
  }

  perceive() {
    this.scanEnemy();
    this.scanBullets();
    this.scanWall();
    this.scanGunCharge()
  }
  
  scanGunCharge(){
    let inputGunCharge = map(this.gunCharge.count, 0, this.gunCharge.threshold, 0, 1)
    this.brainInput.gunCharge = inputGunCharge
  }

  scanEnemy() {
    let enemyToLoc = p5.Vector.sub(this.loc, this.enemy.loc)
    let orientation = createVector(1, 0).rotate(this.ang)

    // enemy angle (angle between own gun and enemy)
    let angEnemy = enemyToLoc.angleBetween(orientation.rotate(-PI));

    if (abs(angEnemy) <= this.vision) {
      let inputAngEnemyLeft = map(angEnemy, this.vision, 0, 0, 1)
      if (inputAngEnemyLeft > 1) inputAngEnemyLeft = 0;
      this.brainInput.angEnemyLeft = sq(inputAngEnemyLeft)

      let inputAngEnemyRight = map(angEnemy, -this.vision, 0, 0, 1)
      if (inputAngEnemyRight > 1) inputAngEnemyRight = 0;
      this.brainInput.angEnemyRight = sq(inputAngEnemyRight)

      // enemy distance
      let distToEnemy = enemyToLoc.mag();
      let inputDistEnemy = map(distToEnemy, this.dia, this.arena.dia - this.dia, 1, 0)
      if (inputDistEnemy < 0) inputDistEnemy = 0;
      this.brainInput.distEnemy = sq(inputDistEnemy)

      // enemy rotation (angle between direct connection to enemy and enemy rotation)
      let enemyOrientation = createVector(1, 0).rotate(this.enemy.ang % TWO_PI)
      let relRotationEnemy = abs(enemyToLoc.angleBetween(enemyOrientation))
      let inputRotEnemy = map(relRotationEnemy, 0, PI, 1, 0)
      //this.brainInput.rotEnemy = inputRotEnemy;

    } else {
      this.brainInput.distEnemy = 0
      this.brainInput.angEnemyRight = 0
      this.brainInput.angEnemyLeft = 0
      //this.brainInput.rotEnemy = 0
    }

  }

  scanBullets() {
    let sharpestAng = TWO_PI
    let bulletTracked = false
    let angTrackedBullet, distTrackedBullet, locTrackedBullet
    let orientation = createVector(1, 0).rotate(this.ang)
    
    for (let b of this.fight.bullets) {
      // check if bullet is shot by enemy
      if (b.origin == this.enemy) {
        let bulletToLoc = p5.Vector.sub(this.loc, b.loc)

        // angle between own gun and bullet
        let headingBullet = bulletToLoc.angleBetween(orientation.rotate(-PI));
        
        // check if bullet in view
        if (abs(headingBullet) <= this.vision) {
          let angBullet = b.vel.angleBetween(bulletToLoc)
          
          // check if bullet is headed towards own location
          if (abs(angBullet) <= HALF_PI) {
            bulletTracked = true;

            if (abs(angBullet) < sharpestAng) {
              sharpestAng = abs(angBullet)
              
              distTrackedBullet = bulletToLoc.mag();
              angTrackedBullet = angBullet;
              locTrackedBullet = b.loc.copy()
            }
          }
       }

      }
    }

    if (bulletTracked) {
      let dangerDistBullet = map(distTrackedBullet, this.arena.dia - this.dia, this.dia / 2, 0, 1)
      
      let angBulletLeft, angBulletRight
      if(angTrackedBullet < 0){
        angBulletLeft = map(angTrackedBullet, -HALF_PI, 0, 0, 1)
        angBulletRight = 0
      }
      else if(angTrackedBullet > 0){
        angBulletLeft = 0
        angBulletRight = map(angTrackedBullet, HALF_PI, 0, 0, 1)
      }
      else {
        angBulletLeft = 1
        angBulletRight = 1
      }

      let dangerLeft = angBulletLeft * dangerDistBullet
      let dangerRight = angBulletRight * dangerDistBullet
      this.brainInput.dangerBulletLeft = sq(dangerLeft)
      this.brainInput.dangerBulletRight = sq(dangerRight)
    } else {
      this.brainInput.dangerBulletLeft = 0
      this.brainInput.dangerBulletRight = 0
    }

    if (bulletTracked) {
      this.locTrackedBullet = locTrackedBullet;
    } else {
      this.locTrackedBullet = undefined;
    }
  }

  scanWall() {
    for (let i = 0; i < this.wallRays.length; i++) {
      this.wallRayCollisions[i] = this.lWallRay(this.wallRays[i].copy())
    }

    let inputWallRays = []
    for (let i = 0; i < this.wallRayCollisions.length; i++) {
      if (this.wallRayCollisions[i] > 0) {
        inputWallRays.push(map(this.wallRayCollisions[i], this.dia / 2, this.rWallVision, 1, 0))
      } else {
        inputWallRays.push(0);
      }
    }
    this.brainInput.wallRay0 = sq(inputWallRays[0])
    this.brainInput.wallRay1 = sq(inputWallRays[1])
    this.brainInput.wallRay2 = sq(inputWallRays[2])
    this.brainInput.wallRay3 = sq(inputWallRays[3])
  }

  process() {
    // generate output
    let input = Object.values(this.brainInput)
    this.output = this.brain.process(input) // assign to "this" for visual debugging

    // mobility
    this.mobility += (this.output[0] - 0.5) * 0.3
    this.mobility = clamp(this.mobility, 1, 2)
    this.vision = map(this.mobility, 1, 2, this.minVision, this.maxVision)

    // move
    this.move("medial", this.output[1] - this.output[2]) // forward / backwards
    this.move("lateral", this.output[3] - this.output[4]) // to the sides

    // rotate
    this.turn(this.output[5] - this.output[6])

    // shoot
    if (this.output[7] > 0.5) this.shoot()
  }

  move(dir, impulse) {
    impulse *= map(this.mobility, 1, 2, 0.1, 4)
    let movement = createVector(impulse, 0).rotate(this.ang)

    switch (dir) {
      case "medial":
        this.loc.add(movement)
        break
      case "lateral":
        this.loc.add(movement.rotate(HALF_PI))
        break
    }
  }

  turn(impulse) {
    impulse *= map(this.mobility, 1, 2, 0.2, 3)
    this.ang += impulse * 0.1;
  }

  checkWallCollision() {
    let locToCenter = p5.Vector.sub(this.loc, this.arena.center)
    let distToCenter = locToCenter.mag()

    if (distToCenter >= this.arena.dia / 2 - this.dia / 2) {
      //this.stats.nWallTouched++;
      let overlap = distToCenter + this.dia / 2 - this.arena.dia / 2;
      this.loc.add(locToCenter.mult(-1).setMag(overlap))
      this.brain.stats.wallTouched++
    }

  }

  checkEnemyCollision() {
    let locToEnemy = p5.Vector.sub(this.enemy.loc, this.loc)
    let distToEnemy = locToEnemy.mag();

    if (distToEnemy <= this.dia) {
      let overlap = this.dia - distToEnemy;
      this.loc.add(locToEnemy.mult(-1).setMag(overlap))
      this.brain.stats.enemyTouched++
    }
  }

  shoot() {
    if (this.gunCharge.finished()) {
      let spray = map(this.mobility, 1, 2, 0, 1)
      this.fight.bullets.push(new Bullet(this.loc.copy(), createVector(1, 0).rotate(this.ang), this.arena, this, this.enemy, spray));
      this.gunCharge.reset();
    }
  }

  lWallRay(p2Ray) {
    let centerCircle = this.arena.center.copy()
    let p1 = this.loc.copy()
    let p2 = this.loc.copy().add(p2Ray.rotate(this.ang));
    let r = this.arena.dia / 2;

    let p1ToCenter = p5.Vector.sub(centerCircle, p1);
    let centerToP2 = p5.Vector.sub(p2, centerCircle);
    let line = p5.Vector.sub(p2, p1);

    let collision
    if (centerToP2.mag() > r) collision = true;
    else collision = false;

    if (collision) {
      // A -> Center
      // B -> p1 of line
      // C -> Collision Point

      let angB = abs(line.angleBetween(p1ToCenter))
      let angC = abs(asin((p1ToCenter.mag() * sin(angB)) / r));
      let angA = PI - angC - angB

      let dBtoC = (sin(angA) * r) / sin(angB)

      return (abs(dBtoC))
    } else return -1;
  }

  isClicked(x, y) {
    let locClick = createVector(x, y)
    let dist = locClick.sub(this.loc).mag()
    if (dist <= this.dia / 2) return true;
    else return false;
  }

  renderWallRays() {
    strokeWeight(2)
    push()
    translate(this.loc.x, this.loc.y)
    rotate(this.ang)
    for (let i = 0; i < this.wallRays.length; i++) {
      if (this.wallRayCollisions[i] > 0) stroke(0, 255, 0, 130)
      else stroke(255, 130)
      line(0, 0, this.wallRays[i].x, this.wallRays[i].y)
    }
    pop()
  }

  renderVision() {
    push()
    translate(this.loc.x, this.loc.y)
    rotate(this.ang)
    noStroke()
    fill(255, 0, 0, 40)
    arc(0, 0, 400, 400, -this.vision, this.vision)
    pop()
  }

  renderBody() {
    fill(0, 0, 60);
    stroke(255);
    strokeWeight(1);
    circle(this.loc.x, this.loc.y, this.dia);
  }

  renderGun() {
    stroke(255);
    strokeWeight(1);
    fill(0, 0, 120);

    push();
    translate(this.loc.x, this.loc.y);
    rotate(this.ang);
    let shift = map(this.gunCharge.count, 0, this.gunCharge.threshold, -this.dia * 0.35, 0);
    rect(shift, -this.wGun / 2, this.lGun, this.wGun)
    rect(-this.dia * 0.3 + shift * 0.25, -this.dia * 0.15, this.dia * 0.6, this.dia * 0.3)
    pop();
  }

  renderLifeBar() {
    noStroke();
    fill(0, 255, 0);
    let maxW = 30;
    let w = map(this.life.count, this.life.defaultValue, this.life.threshold, maxW, 0)
    if (w < 0) w = 0
    rect(this.loc.x - maxW / 2, this.loc.y + this.dia / 2 + 5, w, 5)

    stroke(255);
    strokeWeight(1);
    noFill();
    rect(this.loc.x - maxW / 2, this.loc.y + this.dia / 2 + 5, maxW, 5)
  }

  renderBulletTracking() {
    if (this.locTrackedBullet) {
      let g = map(this.brainInput.dangerBulletLeft + this.brainInput.dangerBulletRight, 0, 1, 255, 0)
      let b = g
      stroke(255, g, b);
      strokeWeight(3);
      line(this.loc.x, this.loc.y, this.locTrackedBullet.x, this.locTrackedBullet.y)
    }
  }

  displayOutput() {
    if (this.output) {
      textAlign(LEFT, TOP)
      fill(255);
      noStroke();
      textSize(11);
      let x = this.loc.x + this.dia / 2 + 7;
      let y = this.loc.y - 13 * this.output.length / 2;
      let str;
      for (let i of this.output) {
        str = round(i * 100) / 100
        text(str, x, y);
        y += 13
      }
    }
  }

  displayInput() {
    textAlign(RIGHT, TOP)
    fill(255);
    noStroke();
    textSize(11);
    let x = this.loc.x - this.dia / 2 - 7;
    let y = this.loc.y - 13 * Object.keys(this.brainInput).length / 2;
    let str;
    for (let i of Object.values(this.brainInput)) {
      str = round(i * 100) / 100
      text(str, x, y);
      y += 13
    }
  }

  render() {
    if (this.renderAll && showInfo) {
      this.renderWallRays()
      this.renderBulletTracking()
      this.renderVision()
      this.displayInput()
      this.displayOutput()
    }
    this.renderLifeBar()
    this.renderBody()
    this.renderGun()

    this.showInfo = false
    if (this.showInfo) {


      // stats
      /*
      textAlign(LEFT, TOP)
      x = this.loc.x + this.dia/2+7
      y = this.loc.y-20
      
      str = (this.nEnemyShot + " (" + round(this.nEnemyShot*manager.scoreMultipliers.nEnemyShot*10)/10 + ")")
      text(str, x, y)
      y+=13;
      
      /*str = (this.enemyInFocus + " (" + round(this.enemyInFocus*manager.scoreMultipliers.enemyInFocus*10)/10 + ")")
      text(str, x, y)
      y += 13*/

      /*
      
      str = (this.nHitByProjectile + " (" + round(this.nHitByProjectile*manager.scoreMultipliers.nHitByProjectile*10)/10 + ")")
      text(str, x, y)
      y += 13
      
      str = (this.nEnemyTouched + " (" + round(this.nEnemyTouched*manager.scoreMultipliers.nEnemyTouched*10)/10 + ")")
      text(str, x, y)
      y += 13
      
      
      
      /*
      str = (this.nWallTouched + " (" + round(this.nWallTouched*manager.scoreMultipliers.nWallTouched*10)/10 + ")")
      text(str, x, y)
      y += 13
      
      
      str = (this.nShotsFired + " (" + round(this.nShotsFired*manager.scoreMultipliers.nShotsFired*10)/10 + ")")
      text(str, x, y)
      y += 13
      
      str = (this.fightWon + " (" + round(this.fightWon*manager.scoreMultipliers.fightWon*10)/10 + ")")
      text(str, x, y)
      y += 13
      
      str = (this.life + " (" + round(this.life*manager.scoreMultipliers.life*10)/10 + ")")
      text(str, x, y)
      y += 13*/

      /*str=round((
        this.enemyInFocus * manager.scoreMultipliers.enemyInFocus+
        this.nEnemyShot * manager.scoreMultipliers.nEnemyShot+
        this.nWallTouched * manager.scoreMultipliers.nWallTouched+
        this.life * manager.scoreMultipliers.life+
        this.nShotsFired * manager.scoreMultipliers.nShotsFired+
        this.fightWon * manager.scoreMultipliers.fightWon)*10)/10*/
      /*
      str = round((this.nEnemyShot * manager.scoreMultipliers.nEnemyShot + this.nHitByProjectile * manager.scoreMultipliers.nHitByProjectile + this.nEnemyTouched * manager.scoreMultipliers.nEnemyTouched)*10)/10
      text(str, x, y)
      */
    }

  }

}