class MutationController {
  constructor(innovationTracker){
    this.innovationTracker = innovationTracker
    
    this.nTries = 50
    
    this.probabilities = {
      addNode: 0.1,
      addConnection: 0.15,
      toggleConnection: 0.15,
      changeWeight: 0.8,
      shiftWeight: 0.9,  // "randomize weight" is inverse value
      changeBias: 0.8,
      shiftBias: 0.9      // "randomize bias" is inverse value
    }
  }
  
  mutate(genome){
    let rand = random()

    if(rand < this.probabilities.addNode) this.addNodeMutation(genome)
    if(rand < this.probabilities.addConnection) this.addConnectionMutation(genome)
    if(rand < this.probabilities.toggleConnection) this.toggleConnectionMutation(genome)
    if(rand < this.probabilities.changeWeight) this.changeWeightMutation(genome)
    if(rand < this.probabilities.changeBias) this.changeBiasMutation(genome)
  }
  
  addNodeMutation(genome){
    let nTries = this.nTries
    
    // create an array containing all IDs of the genome's connections
    let conIDs = Array.from(genome.connections.keys())
    
    while(nTries > 0) {
      // picks a random connection ID 
      let randConID = getRandValue(conIDs)
      
      // remove connection ID from (temporary) ID array so it doesn't get picked twice
      conIDs.splice(findIndex(conIDs, randConID), 1)

      // "add Node" mutation on connection with chosen ID
      if(genome.addNodeMutation(randConID, this.innovationTracker)) {
        return
      } else {
        nTries--
      }
    }
  }
    
  addConnectionMutation(genome){
    let nTries = this.nTries
    
    let nodeIDs = Array.from(genome.nodes.keys())
        
    while(nTries > 0) {
      // pick random node IDs
      let randNodeID1 = getRandValue(nodeIDs)
      let randNodeID2 = getRandValue(nodeIDs)

      // connect chosen nodes
      if(genome.addConnectionMutation(randNodeID1, randNodeID2, this.innovationTracker)) {
        return
      } else {
        nTries--
      }
    }
  }
    
  toggleConnectionMutation(genome){
    // create an array containing all IDs of the genome's connections
    let conIDs = Array.from(genome.connections.keys())
    
    // picks a random connection ID 
    let randConID = getRandValue(conIDs)
    
    genome.toggleConnectionMutation(randConID)
  }
    
  changeWeightMutation(genome){
    // NEAT paper: "each weight had a 90% chance of being uniformly perturbed and a 10% chance of being assigned a new random value"
    for(let conID of genome.connections.keys()){
      let rand = random()
      
      if(rand < this.probabilities.shiftWeight){
        genome.shiftWeightMutation(conID)
      }
      else {
        genome.randomizeWeightMutation(conID)
      }
    }
  }
    
    changeBiasMutation(genome){

    for(let nodeID of genome.nodes.keys()){
      let rand = random()
      
      if(rand < this.probabilities.shiftBias){
        genome.shiftBiasMutation(nodeID)
      }
      else {
        genome.randomizeBiasMutation(nodeID)
      }
    }
  }
}