class Genome {
  constructor(nInputs, nOutputs, id) {
    this.id = id
    this.connections = new Map() // stores value pair of connection's ID and connection itself
    this.nodes = new Map() // stores value pair of node's ID (inno number) and node itself

    this.layers = new Map() // stores value pair of layer and array with node IDs in this layer
    this.layers.set(0, []) // input layer
    this.layers.set(1, []) // output layer

    this.nInputs = nInputs
    this.nOutputs = nOutputs

    this.nLayers = 2
  }
  
  copy(){
    let clone = new Genome(this.nInputs, this.nOutputs)
    
    // clone connections (needs to be copied value by value to create deep copies of the connections)
    for (let [conID, connection] of this.connections.entries()){
      clone.connections.set(conID, connection.copy())
    }
    
    // clone nodes (needs to be copied value by value to create deep copies of the nodes)
    for (let [nodeID, node] of this.nodes.entries()){
      clone.nodes.set(nodeID, node.copy())
    }
    
    // clone layers (needs to be copied value by value to create deep copies of the arrays)
    //clone.layers = new Map(this.layers)
    for (let [layer, nodeIDs] of this.layers.entries()){
      clone.layers.set(layer, nodeIDs.slice())
    }
    
    clone.nLayers = this.nLayers
    
    return clone
  }

  createNodes() {
    /* no need to worry about innovation here; 
    all initially created nodes simply get their ID according to the order in which they were created;
    all later created nodes get the next innovation number as an ID
    */

    // create in-nodes
    for (let i = 1; i <= this.nInputs; i++) {
      let inNode = new Node("input", i, 0)
      this.nodes.set(i, inNode)
      this.layers.get(0).push(i)
    }
    // create out-nodes
    for (let i = this.nInputs + 1; i <= this.nInputs + this.nOutputs; i++) {
      let outNode = new Node("output", i, 1, random(-1, 1))
      this.nodes.set(i, outNode)
      this.layers.get(1).push(i)
    }
  }

  createAllConnections(innovationTracker) {
    for (let i = 1; i <= this.nInputs; i++) { // loop through input nodes

      for (let j = this.nInputs + 1; j <= this.nInputs + this.nOutputs; j++) { // loop through output nodes

        let weight = random(-2, 2)
        weight = roundDecimals(weight, 5)
        let id = innovationTracker.getConnectionID(i, j)

        // establish a connection
        let connection = new Connection(i, j, weight, true, id)
        this.connections.set(connection.id, connection)
        
        // store connection id in output node
        this.nodes.get(j).inConnections.push(id)
      }
    }
  }

  printOut() {
    print("***** GENOME " + this.id + " *****")
    print("Nodes:")
    for (let n of this.nodes.values()) {
      print("ID: " + n.id + ", type: '" + n.type + "', layer: " + n.layer)
    }

    print("Connections:")
    if (this.connections.size > 0) {
      for (let c of this.connections.values()) {

        print("ID: " + c.id + ", inNode: " + c.inNodeID + ", outNode: " + c.outNodeID + ", weight: " + c.weight + (c.enabled ? ", enabled" : ", disabled"))

      }
    } else print("none")
    print("-------------")
  }

  process(inputs) {
    // input layer
    for (let i = 0; i < this.layers.get(0).length; i++) {
      let id = this.layers.get(0)[i]
      this.nodes.get(id).output = inputs[i]
    }

    // go through hidden layers
    for (let layer = 1; layer < this.nLayers - 1; layer++) {

      // go through nodes of each layer
      for (let i = 0; i < this.layers.get(layer).length; i++) {
        let id = this.layers.get(layer)[i]
        this.nodes.get(id).process(this)
      }
    }

    // output layer
    let outputs = []
    for (let i = 0; i < this.layers.get(this.nLayers - 1).length; i++) {
      let id = this.layers.get(this.nLayers - 1)[i]
      this.nodes.get(id).process(this)
      outputs[i] = this.nodes.get(id).output
    }
    return outputs
  }

  addConnectionMutation(randNodeID1, randNodeID2, innovationTracker) {
    /* 
      MAIN RULE: layer must increase from input to output node
    */

    let node1 = this.nodes.get(randNodeID1)
    let node2 = this.nodes.get(randNodeID2)

    // check if node1 and node2 are the same
    if (node1 == node2) return false

    // check if node 1 and node2 are on the same layer
    if (node1.layer == node2.layer) return false

    // check direction of connection and possibly reverse
    let reverse = false
    if (node1.layer > node2.layer) reverse = true

    let inNodeID = reverse ? node2.id : node1.id
    let outNodeID = reverse ? node1.id : node2.id

    // check if connection already exists in this genome
    for (let c of this.connections.values()) {
      if (c.inNodeID == inNodeID && c.outNodeID == outNodeID) {
        return false
      }
    }

    let weight = random(-2, 2) // -2, 2: see Tim Eggers Vid 1
    weight = roundDecimals(weight, 5)
    
    // check if connection exists in global connections
    let newConID = innovationTracker.getConnectionID(inNodeID, outNodeID)

    // if connection does not yet exist, create a new one in the innovation tracker
    if (newConID == -1) { 
      newConID = innovationTracker.getNextConnectionID()
      innovationTracker.addConnection(inNodeID, outNodeID)
    }

    // establish connection
    let newConnection = new Connection(inNodeID, outNodeID, weight, true, newConID)
    this.connections.set(newConID, newConnection)
    
    // store connection id in corresponding output node
    this.nodes.get(outNodeID).inConnections.push(newConID)

    //print("connection " + newConID + " created between node " + inNodeID + " and " + outNodeID)
    //print("-------------")
    return true
  }

  addNodeMutation(conID, innovationTracker) {
    // find the connection that is to be 'split'
    let oldConnection = this.connections.get(conID)

    if (oldConnection == undefined) return false;

    let inNode = this.nodes.get(oldConnection.inNodeID)
    let outNode = this.nodes.get(oldConnection.outNodeID)
    
    let inNodeLayer = inNode.layer
    let outNodeLayer = outNode.layer
    let newNodeLayer = inNodeLayer + 1

    /* if no available layer between nodes:
        a) create new Layer
        b) increment layers of all nodes in layers >= outNodeLayer
    */
    let newLayer = false
    if (outNodeLayer - inNodeLayer <= 1) { // includes 1 because their must be a layer in between!
      // increment layer count
      this.nLayers++
      
      // increment all nodes in higher layers
      for (let n of this.nodes.values()) {
        if (n.layer >= outNodeLayer) n.layer++
      }

      newLayer = true
    }

    // create new Node; innovation number gets incremented with each new node so no checking required!
    let newNodeID = innovationTracker.innoNumber
    let newNode = new Node("hidden", newNodeID, newNodeLayer, 0)
    innovationTracker.incrementInnoNumber()

    // update layer map
    if (newLayer) {
      for (let i = this.nLayers - 1; i > outNodeLayer; i--) {
        let temp = this.layers.get(i - 1)
        this.layers.set(i, temp)
      }
      this.layers.set(newNodeLayer, [newNodeID])
    } else this.layers.get(newNodeLayer).push(newNodeID)

    // generate new connection IDs; since the new node receives a new innovation number, the connections also get completely new IDs since they could not have been created ever before
    let newInConnectionID = innovationTracker.getNextConnectionID()
    innovationTracker.addConnection(inNode.id, newNode.id)
    let newOutConnectionID = innovationTracker.getNextConnectionID()
    innovationTracker.addConnection(newNode.id, outNode.id)

    // create new connections
    let newInConnection = new Connection(inNode.id, newNode.id, 1, true, newInConnectionID)
    let newOutConnection = new Connection(newNode.id, outNode.id, oldConnection.weight, oldConnection.enabled, newOutConnectionID)

    // disable the old connection
    oldConnection.enabled = false
    
    // store id of ingoing connection in the new node
    newNode.inConnections.push(newInConnection.id)
    
    // store id of outgoing connection in the corresponding output node
    outNode.inConnections.push(newOutConnection.id)

    this.nodes.set(newNodeID, newNode)
    this.connections.set(newInConnection.id, newInConnection)
    this.connections.set(newOutConnection.id, newOutConnection)

    //print("node " + newNodeID + " created, connection " + oldConnection.id + " disabled, new connections: " + newInConnection.id + " and " + newOutConnection.id)
    //print("-------------")
    return true

  }

  shiftWeightMutation(conID) {
    // see vid2(hydroxoa) 5:50 or txt S.14

    // find the connection that is to be changed
    let connection = this.connections.get(conID)

    if (connection == undefined) return

    let temp = connection.weight 
    
    // HAUCK BA: standard deviation 1.3
    let sd = 1.3
    let change = randomGaussian(0, sd)
    connection.weight += change
    connection.weight = roundDecimals(connection.weight, 5)
    
    //print("connection " + conID + " shifted by " + change + " from " + temp + " to " + connection.weight)
    //print("-------------")
  }

  randomizeWeightMutation(conID) {
    // find the connection that is to be changed
    let connection = this.connections.get(conID)

    if (connection == undefined) return

    let weight = random(-2, 2)
    weight = roundDecimals(weight, 5)
    
    connection.weight = weight
    
    //print("connection " + conID + " randomized to " + connection.weight)
    //print("-------------")
  }
  
  shiftBiasMutation(nodeID){
    let node = this.nodes.get(nodeID)
    
    if(node.type == "input") return
    
    // HAUCK BA: standard deviation 1.3
    let sd = 1.3
    let change = randomGaussian(0, sd)
    node.bias += change
    node.bias = roundDecimals(node.bias, 5)
  }
  
  randomizeBiasMutation(nodeID){
    let node = this.nodes.get(nodeID)
    
    if(node.type == "input") return
    
    let newBias = random(-2, 2)
    newBias = roundDecimals(newBias, 5)
    node.bias = newBias
  }

  toggleConnectionMutation(conID) {
    // find the connection that is to be toggled
    let connection = this.connections.get(conID)
    connection.enabled = !connection.enabled

    //print("connection " + conID + (connection.enabled ? " enabled" : " disabled"))
    //print("-------------")
  }
  
  setAdjustedFitness(adjustedFitness){
    this.adjustedFitness = adjustedFitness
  }
  
  setActualFitness(actualFitness){
    this.actualFitness = actualFitness
  }

  setupRendering(x, y, w, h) {
    this.x = x
    this.y = y
    this.w = w
    this.h = h
  }

  calcRenderLocs() {
    // array contains number of nodes of each layer (actually only needed for hidden nodes)
    let layers = []

    // array contains number of nodes that have already been 'placed' in each layer
    let placed = []

    // populate the two arrays
    for (let i = 0; i < this.nLayers; i++) {
      layers[i] = 0
      placed[i] = 0
    }
    for (let n of this.nodes.values()) {
      layers[n.layer]++
    }

    // space between box border and network
    let padding = 0.05 * this.w

    // y-space between input or output nodes
    let dYIO
    if (this.nInputs >= this.nOutputs) {
      dYIO = (this.h - 2 * padding) / (this.nInputs - 1)
    } else {
      dYIO = (this.h - 2 * padding) / (this.nOutputs - 1)
    }

    // x-space between layers
    let dXLayers = (this.w - 2 * padding) / (this.nLayers - 1)

    for (let n of this.nodes.values()) {
      if (n.type == "input") {
        let tempX = this.x + padding
        let ySpacer = ((this.h - 2 * padding) - (this.nInputs - 1) * dYIO) / 2
        let tempY = this.y + padding + ySpacer + placed[n.layer] * dYIO
        n.renderLoc = createVector(tempX, tempY)
        placed[n.layer]++
      }

      if (n.type == "output") {
        let tempX = this.x + this.w - padding
        let ySpacer = ((this.h - 2 * padding) - (this.nOutputs - 1) * dYIO) / 2
        let tempY = this.y + padding + ySpacer + placed[n.layer] * dYIO
        n.renderLoc = createVector(tempX, tempY)
        placed[n.layer]++
      }

      if (n.type == "hidden") {
        let dY = (this.h - 2 * padding) / (layers[n.layer] + 1)
        let tempX = this.x + padding + dXLayers * n.layer
        let tempY = this.y + padding + (placed[n.layer] + 1) * dY

        n.renderLoc = createVector(tempX, tempY)
        placed[n.layer]++
      }
    }
  }

  render() {
    noStroke()
    fill(255, 200, 200)
    rect(this.x, this.y, this.w, this.h)

    for (let c of this.connections.values()) {
      let inNode = this.nodes.get(c.inNodeID)
      let outNode = this.nodes.get(c.outNodeID)
      c.render(inNode, outNode)
    }

    for (let n of this.nodes.values()) {
      n.render()
    }
  }
}