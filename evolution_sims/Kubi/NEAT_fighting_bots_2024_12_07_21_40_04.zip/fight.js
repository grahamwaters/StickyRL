class Fight {
  constructor(brains, arena){
    this.isRendered = false;
    this.running = true;
    
    let bot0 = new Bot(brains[0], this, arena, 0)
    let bot1 = new Bot(brains[1], this, arena, 1)
    bot0.enemy = bot1
    bot1.enemy = bot0
    
    this.bots = [bot0, bot1]
    
    this.bullets = [];
  }

  update() {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      this.bullets[i].update();

      if (this.bullets[i].collided) {
        this.bullets.splice(i, 1);
      }
    }
    
    if (this.running) {
      for (let b of this.bots) {
        b.update();
        if (!b.alive) this.running = false;
      }
    }
  }

  render() {
    
    for (let b of this.bullets) b.render()
    for (let b of this.bots) b.render();
  }
}