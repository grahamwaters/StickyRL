class FramerateTracker {
  constructor(x, y, tint, framerate){
    this.x = x
    this.y = y
    this.tint = tint
    this.logFramerate = [];
    this.avgFramerate = framerate;
  }
  update(framerate) {
  let lArray = 30;
  if (this.logFramerate.length >= lArray) {
    this.logFramerate.splice(0, 1);
  }
  this.logFramerate.push(framerate);
  let avg = 0;
  for (let i = 0; i < this.logFramerate.length; i++) {
    avg += this.logFramerate[i];
  }
  this.avgFramerate = avg / this.logFramerate.length;
}

render() {
  let str = parseInt(this.avgFramerate) + " fps";

  if (this.tint == "white") {
    let notRed = map(this.avgFramerate, 30, 55, 0, 255);
    fill(255, notRed, notRed, 200);
  } 
  else if (this.tint == "black") {
    var red = map(this.avgFramerate, 30, 55, 255, 0);
    fill(red, 0, 0);
  }
  
  textAlign(RIGHT, BOTTOM);
  textSize(14);
  noStroke();
  text(str, this.x, this.y);
}
}