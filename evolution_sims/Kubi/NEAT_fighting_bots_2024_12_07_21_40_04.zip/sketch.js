paused = false
showInfo = true

function setup() {
  createCanvas(700, 520);
  gameManager = new GameManager()
  sliderSimSpeed = createSlider(1, 10, 1, 1)
  framerateTracker = new FramerateTracker(width - 5, height - 5, "white", frameRate())
}

function draw() {
  if (!paused) {
    background(20, 10, 50);
    for (let i = 0; i < this.sliderSimSpeed.value(); i++) {
      gameManager.update()
    }

    gameManager.render()
  }
  framerateTracker.update(frameRate())
  framerateTracker.render()
}

function mousePressed() {

}

function keyPressed() {
  if (key == "1") {

  }
  if (key == "2") {

  }

  if (key == "3") {

  }

  if (key == "i") {showInfo = !showInfo}

  if (key == "p") {paused = !paused}

  if (key == "h") {

  }

  if (key == "d") {}

  if (key == "c") {}

  if (key == "t") {}

  if (key == "q") {}
}