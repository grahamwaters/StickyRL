class Connection {
  constructor(inNodeID, outNodeID, weight, enabled, id) {
    this.inNodeID = inNodeID
    this.outNodeID = outNodeID
    this.weight = weight
    this.enabled = enabled
    this.id = id
  }

  copy() {
    return new Connection(this.inNodeID, this.outNodeID, this.weight, this.enabled, this.id)
  }

  render(inNode, outNode) {
    noStroke()
    if (this.enabled) {

      let alpha = map(abs(this.weight), 0, 2, 0, 255)
      if (this.weight >= 0) {
        fill(255, 0, 0, alpha)
      } else if (this.weight < 0) {
        fill(0, 0, 255, alpha)
      }
    } else if (!this.enabled) {
      let alpha = map(abs(this.weight), 0, 2, 0, 255)
      fill(255, alpha)
    }

    let locInNode = inNode.renderLoc.copy()
    let locOutNode = outNode.renderLoc.copy()
    let connection = p5.Vector.sub(locOutNode, locInNode)
    let ang = connection.heading()
    let dist = connection.mag()

    let maxW = 4

    push(); // Start a new drawing state
    translate(locInNode.x, locInNode.y);
    rotate(ang)
    triangle(dist, 0, 0, maxW / 2, 0, -maxW / 2)

    pop()
  }
}