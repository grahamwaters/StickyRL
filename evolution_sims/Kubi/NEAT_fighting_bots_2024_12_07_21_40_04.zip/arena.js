class Arena {
   constructor(x, y, dia){
    this.center = createVector(x+dia/2, y+dia/2)
     this.dia = dia;
     this.sockets = [];
     this.sockets[0] = createVector(this.center.x-this.dia*0.32, this.center.y)
     this.sockets[1] = createVector(this.center.x+this.dia*0.32, this.center.y)
   }
  
  render(){
    fill(150, 110, 120);
    stroke(255);
    strokeWeight(2);
    circle(this.center.x, this.center.y, this.dia)
  }
}