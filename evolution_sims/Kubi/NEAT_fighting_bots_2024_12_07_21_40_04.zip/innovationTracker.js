// new innovation number for every global new node



class InnovationTracker {
  constructor() {
    this.innoNumber = 1 // gets increased only when a new node is created

    this.globalConnections = []
  }

  createDefaultConnections(nInputs, nOutputs) {
    let index = 1

    for (let i = 1; i <= nInputs; i++) {
      for (let j = nInputs + 1; j <= nInputs + nOutputs; j++) {
        this.globalConnections.push([index, i, j])
        index++
      }
    }
  }
  
  addConnection(inNodeID, outNodeID) {
    let newConnectionID = this.globalConnections.length + 1
    this.globalConnections.push([newConnectionID, inNodeID, outNodeID])
  }

  getConnectionID(inNodeID, outNodeID) {
    for (let i = 0; i < this.globalConnections.length; i++) {
      if (inNodeID == this.globalConnections[i][1]) {
        if (outNodeID == this.globalConnections[i][2]) {
          return this.globalConnections[i][0]
        }
      }
    }
    return -1
  }
  
  getNextConnectionID(){
    return this.globalConnections.length + 1
  }

  incrementInnoNumber() {
    this.innoNumber++
  }

  increaseInnoNumberBy(value) {
    this.innoNumber += value
  }

  
  /*
  generateConnectionID(inNodeID, outNodeID, maxNodes) {
    return inNodeID * maxNodes + outNodeID
  }
  */
}