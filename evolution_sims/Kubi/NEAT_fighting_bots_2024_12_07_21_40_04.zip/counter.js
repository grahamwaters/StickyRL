class Counter {
  constructor(type, defaultValue, threshold){
    this.type = type // ascending or descending
    this.defaultValue = defaultValue
    this.count = defaultValue;
    this.threshold = threshold
  }
  
  update(){
    if (this.type == "ascending") this.count++
    else if (this.type == "descending") this.count--
  }
  
  changeCount(value){
    this.count += value
  }
  
  finished(){
    if (this.type == "ascending") {
      if (this.count >= this.threshold) return true
    }
    else if (this.type == "descending") {
      if (this.count <= this.threshold) return true
    }
    return false
  }
  
  reset(){
    this.count = this.defaultValue;
  }
}