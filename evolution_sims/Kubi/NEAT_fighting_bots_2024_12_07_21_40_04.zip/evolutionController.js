class EvolutionController {
  constructor(popSize, innovationTracker) {
    this.popSize = popSize
    this.nextGenomeID = popSize
    this.species = []
    this.speciesMap = new Map() // stores value pair of genome and species
    this.mutationController = new MutationController(innovationTracker)
    this.highestActualFitness = 0

    this.params = {
      c1: 1,
      c2: 1,
      c3: 0.5,
      c4: 0.5,
      deltaT: 3, // compatibility threshold
      unchangedReproductionThreshold: 4, // species size required to forward its best genome unchanged, see NEAT paper
      crossoverRate: 0.9 // no source
    }
  }

  evolve(genomes) {
    this.highestActualFitness = 0
    this.fittestGenome = undefined
    this.speciesMap.clear()

    this.resetSpecies()
    this.sortIntoSpecies(genomes)
    this.removeExtinctSpecies()
    this.evaluate(genomes)
    let reproductionTickets = this.distributeReproductionTickets()
    // kill some of each species?
    let nextGeneration = this.breed(reproductionTickets)

    return nextGeneration
  }

  resetSpecies() {
    for (let s of this.species) s.reset()
  }

  sortIntoSpecies(genomes) {
    // assign genomes to species
    for (let g of genomes) {
      let speciesFound = false

      for (let s of this.species) {
        // check if genome belongs to species
        let dist = this.calcDistance(g, s.representative)
        if (dist < this.params.deltaT) {
          s.members.push(g)
          this.speciesMap.set(g, s)
          speciesFound = true
          break
        }
      }

      // if no species -> make new species with the current species as representative
      if (!speciesFound) {

        let newSpecies = new Species(g)
        this.species.push(newSpecies)
        this.speciesMap.set(g, newSpecies)
      }
    }
  }

  removeExtinctSpecies() {
    for (let i = this.species.length - 1; i >= 0; i--) {
      if (this.species[i].members.length <= 0) {
        this.species.splice(i, 1)
      }
    }
    // https://www.youtube.com/watch?v=qB80QOtv6j8&t=1s
  }

  evaluate(genomes) {
    let sumFitness = 0
    // calculate fitness of genomes 
    for (let g of genomes) {
      let species = this.speciesMap.get(g)

      let fitness = this.calcFitness(g)
      sumFitness += fitness
      let adjustedFitness = fitness / species.members.length

      species.addAdjustedFitness(adjustedFitness)
      g.setAdjustedFitness(adjustedFitness)
      g.setActualFitness(fitness)

      if (fitness > this.highestActualFitness) {
        this.highestActualFitness = fitness
        this.fittestGenome = g
      }
    }
    
    this.avgFitness = sumFitness / genomes.length
  }

  distributeReproductionTickets() {
    let reproductionTickets = new Map()
    let protectedSpecies = []

    // the species with the fittest genome gets at least 1 ticket
    if (this.fittestGenome) {
      let speciesFittestGenome = this.speciesMap.get(this.fittestGenome)
      reproductionTickets.set(speciesFittestGenome, 1)
      protectedSpecies.push(speciesFittestGenome)
    }

    // each species with a certain amount of members gets at least one ticket
    for (let s of this.species) {
      if (s.members.length >= this.params.unchangedReproductionThreshold) {
        if (!reproductionTickets.has(s)) {
          reproductionTickets.set(s, 1)
          protectedSpecies.push(s)
        }
      }
    }

    // calculate total fitness of all species
    let totalAdjustedFitness = 0
    for (let s of this.species) {
      totalAdjustedFitness += s.totalAdjustedFitness
    }

    // distribute ticktes based on species fitness
    let distributedTickets = 0
    for (let s of this.species) {
      let tickets = round((s.totalAdjustedFitness / totalAdjustedFitness) * this.popSize)
      reproductionTickets.set(s, tickets)
      distributedTickets += tickets
    }

    // make sure ticket list size equals population size
    if (distributedTickets > this.popSize) {

      // remove random tickets if too many
      let diff = distributedTickets - this.popSize
      for (let i = 0; i < diff; i++) {
        let successfulRemoval = false

        // don't remove when species is protected
        while (successfulRemoval == false) {
          let randSpecies = getRandKey(reproductionTickets)

          if (!protectedSpecies.includes(randSpecies) || protectedSpecies.length >= this.species.length) {
            let tickets = reproductionTickets.get(randSpecies)
            tickets--
            reproductionTickets.set(randSpecies, tickets)
            successfulRemoval = true
          }
        }
      }
    } else if (distributedTickets < this.popSize) {
      // randomly add tickets if too few
      let diff = this.popSize - distributedTickets
      for (let i = 0; i < diff; i++) {
        let randSpecies = getRandKey(reproductionTickets)
        let tickets = reproductionTickets.get(randSpecies)
        tickets++
        reproductionTickets.set(randSpecies, tickets)
      }
    }

    for (let [s, t] of reproductionTickets.entries()) {
      //print("size: " + s.members.length + ", fitness: " + round(s.totalAdjustedFitness) + ", tickets: " + t)
    }
    return reproductionTickets
  }

  breed(reproductionTickets) {
    let nextGeneration = []

    // forward fittest genome of whole generation unchanged, put it first place of array
    let genomeCopy = this.fittestGenome.copy() // create deep copy
    genomeCopy.id = this.nextGenomeID
    this.nextGenomeID++
    nextGeneration.push(genomeCopy)
    
    // update tickets
    let speciesFittestGenome = this.speciesMap.get(this.fittestGenome)
    let tickets = reproductionTickets.get(speciesFittestGenome)
    tickets--
    reproductionTickets.set(speciesFittestGenome, tickets)

    // forward the best genome of each species unchanged
    for (let s of this.species) {
      
      // condition: species must have a certain amount of members
      if (s.members.length >= this.params.unchangedReproductionThreshold) {
        let maxFitnessInSpecies = 0
        let fittestGenomeInSpecies

        for (let g of s.members) {
          if (g.adjustedFitness > maxFitnessInSpecies) {
            maxFitnessInSpecies = g.adjustedFitness
            fittestGenomeInSpecies = g
          }
        }

        // condition: chosen genome not equal to fittest genome of generation, since it is already in array
        if (fittestGenomeInSpecies != this.fittestGenome) {
          // create deep copy
          let genomeCopy = fittestGenomeInSpecies.copy()
          genomeCopy.id = this.nextGenomeID
          this.nextGenomeID++
          nextGeneration.push(genomeCopy)

          // update tickets
          let tickets = reproductionTickets.get(s)
          tickets--
          reproductionTickets.set(s, tickets)
        }
      }
    }
    

    // breed the rest of the genomes
    for (let [species, tickets] of reproductionTickets.entries()) {
      let remainingTickets = tickets
      while (remainingTickets > 0) {
        let child

        // create child from crossover or simply copy parent
        if (random() < this.params.crossoverRate && species.members.length > 1) {
          let parent1 = this.getRandomGenomeBasedOnFitness(species)
          let parent2 = this.getRandomGenomeBasedOnFitness(species)

          if (parent1.adjustedFitness >= parent2.adjustedFitness) {
            child = this.crossover(parent1, parent2)
          } else {
            child = this.crossover(parent2, parent1)
          }
        } else {
          child = this.getRandomGenomeBasedOnFitness(species).copy()
          child.id = this.nextGenomeID
          this.nextGenomeID++
        }

        // mutate
        this.mutationController.mutate(child)

        nextGeneration.push(child)

        // reduce tickets
        remainingTickets--
      }
    }
    return nextGeneration
  }

  getRandomSpeciesBasedOnFitness(totalFitness) {
    // species with higher totalAdjustedFitness more likely to be chosen
    // https://stackoverflow.com/q/56692

    let rand = random(totalFitness)

    for (let s of this.species) {
      if (rand < s.totalAdjustedFitness) return s

      rand -= s.totalAdjustedFitness
    }
  }

  getRandomGenomeBasedOnFitness(species) {
    // species with higher totalAdjustedFitness more likely to be chosen
    // https://stackoverflow.com/q/56692

    let totalFitness = 0
    for (let g of species.members) {
      totalFitness += g.adjustedFitness
    }

    let rand = random(totalFitness)

    for (let g of species.members) {
      if (rand < g.adjustedFitness) return g

      rand -= g.adjustedFitness
    }
  }

  calcFitness(genome) {
    // must be overwritten from external!
  }

  calcDistance(genome1, genome2) {
    // both genomes have no connections
    if (genome1.connections.size == 0 && genome2.connections.size == 0) return 0

    // find out max connection IDs of the two genomes
    let maxConID1 = max(Array.from(genome1.connections.keys()))
    let maxConID2 = max(Array.from(genome2.connections.keys()))

    // genome1 must be the one with the highest connection ID; if not the case, swap!
    if (maxConID1 < maxConID2) {

      // swap genomes
      let tempGenome = genome1
      genome1 = genome2
      genome2 = tempGenome

      // swap max connection IDs
      let tempConID = maxConID1
      maxConID1 = maxConID2
      maxConID2 = tempConID
    }

    let nMatching = 0
    let nExcess = 0
    let nDisjoint = 0
    let weightDiff = 0

    let checkedIDs = []

    // go through connections of genome 1 and compare them to genome 2
    for (let c of genome1.connections.values()) {
      let id = c.id

      // matching gene
      if (genome2.connections.has(id)) {
        nMatching++
        weightDiff += abs(c.weight - genome2.connections.get(id).weight)
      }

      // disjoint or excess gene
      else {
        // excess gene
        if (id > maxConID2) {
          nExcess++
        }
        // disjoint gene
        else {
          nDisjoint++
        }
      }
      checkedIDs.push(id)
    }

    // go through connections of genome 2 and find connections that are not included in genome 1
    for (let c of genome2.connections.values()) {
      if (!checkedIDs.includes(c.id)) {
        nDisjoint++
      }
    }

    // go through nodes of genome1
    let matchingNodes = 0
    let biasDiff = 0
    for (let n of genome1.nodes.values()) {
      if (n.type != "input") {
        let nodeID = n.id
        if (genome2.nodes.has(nodeID)) {
          biasDiff += abs(n.bias - genome2.nodes.get(nodeID).bias)
          matchingNodes++
        }
      }
    }

    if (nMatching > 0) { // otherwise division by zero!
      weightDiff /= nMatching
    } else weightDiff = 0

    if (matchingNodes > 0) { // otherwise division by zero!
      biasDiff /= matchingNodes
    } else biasDiff = 0

    let n = max(genome1.connections.size, genome2.connections.size)
    if (n < 20) n = 1

    // formula see neat paper
    let dist = (nExcess * this.params.c1) / n + (nDisjoint * this.params.c2) / n + weightDiff * this.params.c3 + biasDiff * this.params.c4

    return dist
  }

  crossover(parent1, parent2) {
    // assumption: parent1 is the fitter parent!

    let child = new Genome(parent1.nInputs, parent1.nOutputs, this.nextGenomeID)
    this.nextGenomeID++
    child.nLayers = parent1.nLayers

    //child.layers = new Map(parent1.layers)
    for (let [layer, nodeIDs] of parent1.layers.entries()) {
      child.layers.set(layer, nodeIDs.slice())
    }

    // copy nodes from fitter parent (= parent1)
    for (let n of parent1.nodes.values()) {
      child.nodes.set(n.id, n.copy())
      child.nodes.get(n.id).inConnections = []
    }

    for (let c of parent1.connections.values()) {
      let id = c.id

      let newConnection

      // matching gene
      if (parent2.connections.has(id)) {
        if (random() < 0.5) {
          newConnection = parent1.connections.get(id).copy()
        } else {
          newConnection = parent2.connections.get(id).copy()
        }
        // NEAT paper: "There was a 75% chance that an inherited gene was disabled if it was disabled in either parent"
        if ((!parent1.connections.get(id).enabled || !parent2.connections.get(id).enabled) && random() < 0.75) {
          newConnection.enabled = false
        } else {
          newConnection.enabled = true
        }
      }

      // disjoint or excess gene
      else {
        newConnection = parent1.connections.get(id).copy()
      }

      child.connections.set(id, newConnection)

      // store connection id as in connection of the corresponding node
      child.nodes.get(newConnection.outNodeID).inConnections.push(id)
    }

    return child
  }
}