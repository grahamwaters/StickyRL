function findIndex(array, value) {
  for (let i = 0; i < array.length; i++) {
    if (array[i] == value) return i
  }
  return -1
}

function getRandValue(array) {
  let randInd = floor(random(array.length))
  return array[randInd]
}

function getRandKey(map){
  let keys = Array.from(map.keys())
  return keys[floor(random(keys.length))]
}

function roundDecimals(value, nDigits) {
  let factor = pow(10, nDigits)
  let result = round(value * factor) / factor
  return result
}

function clamp(value, min, max){
 if(value < min) return min
  else if(value > max) return max
  else return value
}