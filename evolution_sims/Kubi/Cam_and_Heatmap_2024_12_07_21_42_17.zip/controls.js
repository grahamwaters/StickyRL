function keyPressed() {
  if (key === "a" || key === "A") {
    mover[0] = true;
  }
  if (key === "w" || key === "W") {
    mover[1] = true;
  }
  if (key === "s" || key === "S") {
    mover[3] = true;
  }
  if (key === "d" || key === "D") {
    mover[2] = true;
  }
  
  if (key === "p" || key === "P") {
    paused = !paused;
    if(paused) noLoop();
    else if(!paused) loop();
  }
  
  if (key === "r" || key === "R") {
    heatmap.reset();
  }
  
  if (key === "t" || key === "T") {
    if(terrainMode == "heatmap") terrainMode = "gradient";
    else if(terrainMode == "gradient") terrainMode = "heatmap";
  }
  
  if (key === "1") {
    displayShiftFrame = !displayShiftFrame;
  }
  if (key === "2") {
    displayVel = !displayVel;
  }
  
  if (key === "c" || key === "C") {
    cutSpikes = !cutSpikes;
  }
  if (key === "b" || key === "B") {
    blur = !blur;
  }
  if (key === " ") {
    player.shoot();
  }
}

function checkInput() {
  if (mover[0]) { //left
    player.turn(0);
  }
  if (mover[2]) { //right
    player.turn(1);
  }
  if (mover[1]) { //forward
    player.thrust(0);
  }
  if (mover[3]) { //back
    player.thrust(1);
  }
}


function keyReleased() {

  if (key === "a" || key === "A") {
    mover[0] = false;
  }
  if (key === "w" || key === "W") {
    mover[1] = false;
  }
  if (key === "s" || key === "S") {
    mover[3] = false;
  }
  if (key === "d" || key === "D") {
    mover[2] = false;
  }
}