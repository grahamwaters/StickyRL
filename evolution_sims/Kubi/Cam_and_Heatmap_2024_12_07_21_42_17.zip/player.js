class Player {
  constructor() {
    this.l = 30;
    this.w = 16;

    this.loc = createVector(terrainSize / 2, terrainSize / 2);
    this.vel = createVector();
    this.acc = createVector();

    this.ang = -HALF_PI;
    this.turnrate = 0.06;
    this.dampening = 0.99;
    this.maxV = 18;
    this.boost = .7;
  }

  turn(dir) {
    if (dir == 0) {
      this.ang -= this.turnrate;
    } else {
      this.ang += this.turnrate;
    }
  }

  thrust(dir) {
    if (dir == 0) {
      this.acc.x = cos(this.ang) * this.boost;
      this.acc.y = sin(this.ang) * this.boost;
    } else {
      this.acc.x = -cos(this.ang) * this.boost * 0.5;
      this.acc.y = -sin(this.ang) * this.boost * 0.5;
    }
  }

  update() {
    this.checkEdges();
    this.move();
        heatmap.addLoc(terrain.getCurrentTile(this.loc.copy()));
  }

  move() {
    this.vel.add(this.acc);
    this.vel.mult(this.dampening);
    this.vel.limit(this.maxV);
    this.loc.add(this.vel);
    this.acc.mult(0);
  }
  
  shoot() {
    var dir = createVector(1, 0).rotate(this.ang);
    bullets.push(new Bullet(this.loc.copy(), dir));
  }

  checkEdges() {
    let vertices = this.getShipCornerCoords();
    let collision = false;
    for (let v of vertices) {
      // top edge
      if (v.y <= 0) {
        this.vel.y *= -1;
        this.loc.y += (-v.y);
        collision = true;
        break;
      }
      // right edge
      if (v.x >= terrainSize) {
        this.vel.x *= -1;
        this.loc.x -= (v.x - terrainSize);
        collision = true;
        break;
      }

      // bottom edge
      if (v.y >= terrainSize) {
        this.vel.y *= -1;
        this.loc.y -= (v.y - terrainSize);
        collision = true;
        break;
      }
      // left edge
      if (v.x <= 0) {
        this.vel.x *= -1;
        this.loc.x += (-v.x);
        collision = true;
        break;
      }
    }
    if(collision) this.vel.mult(0.9);
  }

  getShipCornerCoords() {
    let vertices = [];
    // get coordinates of corner points
    let posTip = createVector();
    posTip.x = cos(this.ang) * this.l / 2;
    posTip.y = sin(this.ang) * this.l / 2;

    let posWingL = createVector();
    let centerWingL = createVector(-this.l / 2, -this.w / 2);
    let angCenterWingL = centerWingL.heading();
    let dCenterWingL = centerWingL.mag();
    posWingL.x = cos(this.ang + angCenterWingL) * dCenterWingL;
    posWingL.y = sin(this.ang + angCenterWingL) * dCenterWingL;

    let posWingR = createVector();
    let centerWingR = createVector(-this.l / 2, this.w / 2);
    let angCenterWingR = centerWingR.heading();
    let dCenterWingR = centerWingR.mag();
    posWingR.x = cos(this.ang + angCenterWingR) * dCenterWingR;
    posWingR.y = sin(this.ang + angCenterWingR) * dCenterWingR;

    let locTip = posTip.add(this.loc);
    let locWingL = posWingL.add(this.loc);
    let locWingR = posWingR.add(this.loc);

    vertices.push(locTip);
    vertices.push(locWingL);
    vertices.push(locWingR);

    return vertices;
  }

  display() {
    push();
    translate(cam.toScreenCoords(this.loc).x, cam.toScreenCoords(this.loc).y);
    rotate(this.ang);
    fill(203, 21, 58);
    strokeWeight(1);
    stroke(255, 150);
    triangle(-this.l / 2, -this.w / 2, this.l / 2, 0, -this.l / 2, this.w / 2);
    pop();


    if (displayVel) {
      stroke(10, 255, 180, 150);
      strokeWeight(4);
      let velCopy = this.vel.copy();
      velCopy.setMag(map(velCopy.mag(), 0, this.maxV, 0, 140));
      line(cam.toScreenCoords(this.loc).x, cam.toScreenCoords(this.loc).y, cam.toScreenCoords(this.loc.copy().add(velCopy)).x, cam.toScreenCoords(this.loc.copy().add(velCopy)).y);
    }
  }
}