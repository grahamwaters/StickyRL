class Bullet {
  constructor(loc, dir) {
    //movement
    this.loc = loc;
    this.lastLoc = loc;
    this.impactLoc = createVector();

    this.speed = 30;
    this.vel = dir.setMag(this.speed);

    this.interpolated = new Array(round(this.speed / 3));

    //status
    this.hitWall = false; //false until bullet hits wall

    //bullet color
    this.red = 0;
    this.green = 255;
    this.blue = 90;

    //animation
    this.impactAnimationTimer = 0;
    this.maxImpactAnimationTime = 18; //duration of impact animation
    this.impactAnimationFinished = false; //false until impact animation has finished
  }

  update() {
    if (!this.hitWall) { //flying bullet
      this.lastLoc = this.loc.copy();
      this.loc.add(this.vel);
      this.checkWalls();
      
    } else { //impact explosion
      this.impactAnimationTimer++;
      if (this.impactAnimationTimer >= this.maxImpactAnimationTime) {
        this.impactAnimationFinished = true;
      }
    }
  }

  checkWalls() {
    if (this.loc.x < 0 || this.loc.x > terrainSize || this.loc.y < 0 || this.loc.y > terrainSize) {
      this.interpolated = this.interpolate(this.lastLoc.copy(), this.loc.copy(), this.interpolated.length);
      var coords;
      for (let i = 0; i < this.interpolated.length; i++){
        coords = this.interpolated[i].copy();
        if (coords.x < 0 || coords.x > terrainSize || coords.y < 0 || coords.y > terrainSize){
          this.hitWall = true;
          this.impactLoc = coords;
          break;
        }
      }
    }
  }
  
  interpolate(coordsA, coordsB, nSteps) {
    var step = coordsB.sub(coordsA).div(nSteps);
    var interpolated = new Array(nSteps);
    for (let i = 0; i < nSteps; i++) {
      interpolated[i] = p5.Vector.add(coordsA, step.copy().mult(i + 1));
    }
    return interpolated;
  }

  display() {
    if (!this.hitWall) {
      let temp = this.vel.copy().mult(-1).setMag(15).add(this.loc);
      stroke(this.red, this.green, this.blue);
      strokeWeight(6);
      line(cam.toScreenCoords(this.loc).x, cam.toScreenCoords(this.loc).y, cam.toScreenCoords(temp).x, cam.toScreenCoords(temp).y);
    } else {
      this.animateImpact();
    }
  }

  animateImpact() {

    //animation of impact explosion on wall
    var r = map(this.impactAnimationTimer, 0, this.maxImpactAnimationTime, 1, 25);
    var opacity = map(this.impactAnimationTimer, 0, this.maxImpactAnimationTime, 255, 0);
    noStroke();
    fill(this.red, this.green, this.blue, opacity);
    circle(cam.toScreenCoords(this.impactLoc).x, cam.toScreenCoords(this.impactLoc).y, r);
  }
}