function updateFrameRate() {
  let lArray = 30;
  if (logFrameRate.length >= lArray) {
    logFrameRate.splice(0, 1);
  }
  logFrameRate.push(frameRate());
  let avg = 0;
  for (let i = 0; i < logFrameRate.length; i++) {
    avg += logFrameRate[i];
  }
  avgFrameRate = avg / logFrameRate.length;
}

function displayFrameRate(tint) {
  let str = parseInt(avgFrameRate) + " fps";

  if (tint == "white") {
    let notRed = map(avgFrameRate, 30, 55, 0, 255);
    fill(255, notRed, notRed, 200);
  } 
  else if (tint == "black") {
    var red = map(avgFrameRate, 30, 55, 255, 0);
    fill(red, 0, 0);
  }
  
  textAlign(RIGHT, TOP);
  textSize(14);
  noStroke();
  text(str, width - 5, 5);
}

function displayClickRequest() {
  fill(255, 50);
  noStroke();
  rect(0, 0, width, height);

  noStroke();
  textSize(20);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Click here to activate the sketch", width / 2, height / 2);
}