class Heatmap {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;

    this.pixelSize = w / resolution;
    this.nPixels = resolution * resolution;

    this.sectors = [];
    this.processedData = [];
    this.colorValues = [];

    this.init();
  }

  init() {
    for (let i = 0; i < this.nPixels; i++) {
      this.sectors[i] = 0;
    }

    for (let i = 0; i < this.nPixels; i++) {
      this.processedData[i] = 0;
    }
  }

  reset() {
    this.init();
  }

  addLoc(ind) {
    this.indPlayer = ind;
    this.sectors[ind]++;

  }

  update() {
    if (cutSpikes) {
      this.processedData = this.processData(this.sectors);
    } else {
      this.processedData = this.sectors;
    }

    if(blur){
    for (let i = 0; i < sliderBlur.value(); i++) {
      this.processedData = this.blur(this.processedData);
    }
    }

    this.highestValue = 0;

    for (let i = 0; i < this.sectors.length; i++) { //determine highest value of processed data
      if (this.processedData[i] > this.highestValue) {
        this.highestValue = this.processedData[i];
      }
    }
    
  }
  display() {
    this.displayPixels();
    this.displayFrame();
    this.displayFilterPanel1();
    this.displayFilterPanel2();
    this.displayBlurPanel1();
    this.displayBlurPanel2();
    this.displayBlurPanel3();
  }
  
  calcColors(){
    let indHeatMap, ratio, r, g, b, a, max;
    for (let indY = 0; indY < resolution; indY++) {
      for (let indX = 0; indX < resolution; indX++) {
        indHeatMap = indY * resolution + indX;

        ratio = this.processedData[indHeatMap] / this.highestValue;

        r = 0;
        g = 0;
        b = 0;

        if (this.processedData[indHeatMap] > 0) {
          max = round(map(ratio, 0, 1, 0, 255));
          b = round(map(ratio, 0, 1, 0, 255));
          g = round(map(ratio, 0, 1, 0, max));
          r = round(map(ratio, 0, 1, 0, max));
        }
        this.colorValues[indHeatMap] = color(r, g, b);

      }
    }
  }

  displayPixels() {
    let indHeatMap, r, g, b, a;
    for (let indY = 0; indY < resolution; indY++) {
      for (let indX = 0; indX < resolution; indX++) {
        indHeatMap = indY * resolution + indX;
        a = 230;
        if (indHeatMap == this.indPlayer) {
          r = 255;
          g = 0;
          b = 0;
          
        }
        else {
          r = this.colorValues[indHeatMap].levels[0];  
          g = this.colorValues[indHeatMap].levels[1]; 
          b = this.colorValues[indHeatMap].levels[2]; 
        }
        fill(r, g, b);
        noStroke();
        rect(this.x + indX * this.pixelSize, this.y + indY * this.pixelSize, this.pixelSize, this.pixelSize);

      }
    }
  }

  displayFrame() {
    stroke(255);
    strokeWeight(1);
    noFill();
    rect(this.x, this.y, this.w, this.h);
  }

  processData(originalData) {
    let relevantData = this.extractRelevantData(this.sectors);

    relevantData = this.bubbleSort(relevantData);

    if (relevantData.length > 1) {
      //let avg = this.calcAverage(relevantData);
      let quartiles = this.calcQuartiles(relevantData);
      let boundaries = this.calcBoundaries(quartiles);

      
      this.filter = quartiles[1] + (boundaries[3] - quartiles[1]) * sliderFilter.value();

      return this.lowPass(this.sectors, this.filter); // default:  boundaries[3]
    }

    return originalData;
  }


  extractRelevantData(originalData) {
    let result = [];
    for (let i = 0; i < originalData.length; i++) {
      if (originalData[i] > 0) {
        result.push(originalData[i]);
      }
    }
    return result;
  }

  calcQuartiles(data) {
    let q1 = 0; //lowerQuartile
    let q2 = 0; //median value
    let q3 = 0; //upper quartile

    //calc quartiles
    if (data.length % 2 == 0) { //arrayLength: even
      let indA1 = data.length / 2 - 1;
      let indA2 = data.length / 2;
      q2 = (data[indA1] + data[indA2]) / 2;

      if (indA1 % 2 == 0) { //remaining length: odd
        q1 = data[indA1 / 2];
        q3 = data[(indA1 / 2) * 3 + 1];
      } else if (indA1 % 2 == 1) { //remaining length: even
        let indB1 = (indA1 - 1) / 2;
        let indB2 = indB1 + 1;
        let indB3 = indA1 + indB2;
        let indB4 = indB3 + 1;
        q1 = (data[indB1] + data[indB2]) / 2;
        q3 = (data[indB3] + data[indB4]) / 2;
      }
    } else { //arrayLength: odd
      let ind = (data.length - 1) / 2;
      q2 = data[ind];

      if (ind % 2 == 0) { //remaining length: even
        let indB2 = ind / 2;
        let indB1 = indB2 - 1;
        let indB3 = ind + indB2;
        let indB4 = indB3 + 1;
        q1 = (data[indB1] + data[indB2]) / 2;
        q3 = (data[indB3] + data[indB4]) / 2;
      } else if (ind % 2 == 1) { //remaining length: odd
        q1 = data[(ind - 1) / 2];
        q3 = data[ind + (ind + 1) / 2];
      }
    }
    return [
      q1,
      q2,
      q3
    ];
  }

  calcBoundaries(quartiles) {
    let q1 = quartiles[0];
    let q3 = quartiles[2];


    //calculate difference between quartiles
    let diffQuartiles = q3 - q1;

    //calculate boundries
    let innerBoundryUp = q3 + diffQuartiles * 1.5;
    let innerBoundryDown = q1 - diffQuartiles * 1.5;

    let outerBoundryUp = q3 + diffQuartiles * 3;
    let outerBoundryDown = q1 - diffQuartiles * 3;

    //return boundries
    return [
      outerBoundryDown,
      innerBoundryDown,
      innerBoundryUp,
      outerBoundryUp
    ];
  }

  lowPass(data, filter) {
    let result = [];
    for (let i = 0; i < data.length; i++) {
      result.push(data[i]);
      if (result[i] > filter) {
        result[i] = filter;
      }

    }
    return result;
  }

  calcAverage(data) {
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i];
    }
    let result = sum / data.length;
    return result;
  }

  bubbleSort(arr) {
    for (let j = 0; j < arr.length; j++) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] > arr[i + 1]) {
          var temp = arr[i];
          arr[i] = arr[i + 1];
          arr[i + 1] = temp;
        }
      }
    }
    return arr;
  }

  blur(originalData) {
    let data = this.arrToMatrix(originalData, resolution, resolution);
    let kernelSize = sliderKernelSize.value();
    let avg, count;
    let result = [];

    // go through matrix
    for (let y = 0; y < data.length; y++) {
      for (let x = 0; x < data[y].length; x++) {
        avg = 0;
        count = 0;
        // at each matrix element, calculate kernel average
        for (let yk = -floor(kernelSize / 2); yk <= floor(kernelSize / 2); yk++) {
          for (let xk = -floor(kernelSize / 2); xk <= floor(kernelSize / 2); xk++) {
            if (data[y + yk] != undefined) {
              if (data[y + yk][x + xk] != undefined) {
                avg += data[y + yk][x + xk];
                count++;
              }
            }
          }
        }
        avg /= count;
        result.push(avg);
      }
    }
    return result;
  }

  arrToMatrix(data, xSize, ySize) {
    let matrix = [];
    let row, ind;
    for (let y = 0; y < ySize; y++) {
      row = [];
      for (let x = 0; x < xSize; x++) {
        let ind = x + y * xSize;
        row.push(data[ind]);
      }
      matrix.push(row);
    }
    return matrix;
  }

  displayFilterPanel1() {
    let x = 5;
    let y = 165;
    let h = 25;
    stroke(255);
    strokeWeight(1);
    fill(0, 230);
    rect(x, y, this.w, h);

    fill(255);
    noStroke();
    textSize(14);
    textAlign(LEFT, TOP);
    text("cut outliers:", x + 5, y + 5);
    if (cutSpikes){
      fill(0, 255, 0);
      text("on", x + 85, y + 5);
    }
    else {
      fill(255, 0, 0);
      text("off", x + 85, y + 5);
    }
  }

  displayFilterPanel2() {
    let x = 5;
    let y = 195;
    let h = 65;
    stroke(255);
    strokeWeight(1);
    fill(0, 230);
    rect(x, y, this.w, h);

    fill(255);
    noStroke();
    text("low pass:", x + 5, y + 5);
    if(this.filter !=undefined && cutSpikes){
      text(round(this.filter), x + 70, y + 5);
    }
    else {
      text("-", x + 70, y + 5);
    }

    sliderFilter.position(x + 3, y + 25);
    sliderFilter.style("width", this.w - 2 * 5 + "px");

    noStroke();
    textSize(10);
    text("median", x + 5, y + 50);
    textAlign(RIGHT, TOP);
    text("outer fence", x + this.w - 5, y + 50);
  }

  displayBlurPanel1() {
    let x = 5;
    let y = 270;
    let h = 25;
    stroke(255);
    strokeWeight(1);
    fill(0, 230);
    rect(x, y, this.w, h);

    fill(255);
    noStroke();
    textSize(14);
    textAlign(LEFT, TOP);
    text("blur:", x + 5, y + 5);
    if (blur && sliderBlur.value() > 0 && sliderKernelSize.value() > 1) {
      fill(0, 255, 0);
      text("on", x + 40, y + 5);
    } else {
      fill(255, 0, 0);
      text("off", x + 40, y + 5);
    }
  }

  displayBlurPanel2() {
    let x = 5;
    let y = 300;
    let h = 65;
    stroke(255);
    strokeWeight(1);
    fill(0, 230);
    rect(x, y, this.w, h);

    fill(255);
    noStroke();
    textAlign(LEFT, TOP);
    textSize(14);
    text("iterations:", x + 5, y + 5);
    text(sliderBlur.value(), x + 75, y + 5);

    sliderBlur.position(x + 3, y + 25);
    sliderBlur.style("width", this.w - 2 * 5 + "px");

    noStroke();
    textSize(10);
    text("0", x + 5, y + 50);
    textAlign(RIGHT, TOP);
    text("8", x + this.w - 5, y + 50);
  }
  displayBlurPanel3() {
    let x = 5;
    let y = 370;
    let h = 65;
    stroke(255);
    strokeWeight(1);
    fill(0, 230);
    rect(x, y, this.w, h);

    fill(255);
    noStroke();
    textAlign(LEFT, TOP);
    textSize(14);
    text("kernel size:", x + 5, y + 5);
    text(sliderKernelSize.value(), x + 85, y + 5);

    sliderKernelSize.position(x + 3, y + 25);
    sliderKernelSize.style("width", this.w - 2 * 5 + "px");

    noStroke();
    textSize(10);
    text("1", x + 5, y + 50);
    textAlign(RIGHT, TOP);
    text("7", x + this.w - 5, y + 50);
  }
}