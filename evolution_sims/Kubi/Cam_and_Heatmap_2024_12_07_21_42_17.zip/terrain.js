class Terrain {
  constructor() {
    this.tileSize = round(terrainSize / resolution);

    this.tiles = [];
    for (let indY = 0; indY < resolution; indY++) {
      for (let indX = 0; indX < resolution; indX++) {
        this.tiles.push(new Tile(indX, indY, this.tileSize));
      }
    }
  }

  getCurrentTile(loc) {
    let indX = floor(loc.x / this.tileSize);
    let indY = floor(loc.y / this.tileSize);

    return indY * resolution + indX;
  }

  display() {
    for (let t of this.tiles) {
      if (t.isVisible()) {
        t.display();
      }
    }
  }
}

class Tile {
  constructor(indX, indY, size) {
    this.indX = indX;
    this.indY = indY;
    this.size = size; // tiles are squares
    this.loc = createVector(size * indX, size * indY);
  }

  isVisible() {
    if (rectRect(this.loc.x, this.loc.y, this.size, this.size, cam.visTL.x, cam.visTL.y, cam.visW, cam.visH)) {
      return true;
    } else {
      return false;
    }
  }

  display() {
    this.displayTile();
    if (displayTileDesc) this.displayTileDesc();
  }

  displayTile() {
    if (terrainMode == "heatmap") {
      let indHeatMap = this.indY * resolution + this.indX;
      fill(heatmap.colorValues[indHeatMap]);
    } else {
      let r1 = 55;
      let g1 = 130;
      let b1 = 154;
      let r2 = 230;
      let g2 = 175;
      let b2 = 173;

      let r = map(this.indX, 0, resolution, r1, r2);
      let g = map(this.indY, 0, resolution, g1, g2);
      let b = map(this.indY, 0, resolution, b1, b2);
      fill(r, g, b);
    }

    stroke(255, 100);
    strokeWeight(1);

    let screenCoords = cam.toScreenCoords(this.loc);
    rect(screenCoords.x, screenCoords.y, this.size, this.size);

  }
  displayTileDesc() {
    fill(70);
    textSize(12);
    noStroke();
    textAlign(LEFT, TOP);

    let str = "[" + this.indX + ", " + this.indY + "]";
    text(str, cam.toScreenCoords(this.loc).x + 3, cam.toScreenCoords(this.loc).y + 3);

    str = "x: " + this.loc.x + ", y: " + this.loc.y;
    text(str, cam.toScreenCoords(this.loc).x + 3, cam.toScreenCoords(this.loc).y + 17);
  }
}