let terrainSize = 2000; // terrain is square
let resolution = 20; // number of tiles across width/height
let paused = false;
let cutSpikes = true;
let displayVel = false;
let displayShiftFrame = false;
let displayTileDesc = false;
let terrainMode = "heatmap";
let blur = true;

function setup() {
  createCanvas(700, 600);

  mover = [false, false, false, false];
  terrain = new Terrain();
  player = new Player();
  cam = new Camera();
  bullets = [];

  sliderFilter = createSlider(0, 1, 1, 0.01);
  sliderBlur = createSlider(0, 8, 4, 1);
  sliderKernelSize = createSlider(1, 7, 3, 2);

  heatmap = new Heatmap(5, 5, 150, 150);
  cam.setAnchor(player);

  logFrameRate = [];
  avgFrameRate = frameRate();
}

function draw() {
  background(10, 10, 20);
  if (focused) {
    if (!paused) {
      checkInput();
      player.update();
      handleBullets();
      cam.update();
      heatmap.update();
      updateFrameRate();
    }
  }
  heatmap.calcColors();
  terrain.display();
  for(let b of bullets) b.display();
  player.display();
  cam.display();
  heatmap.display();
  displayFrameRate("white");
  if (!focused) displayClickRequest();
}

function handleBullets() {
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();

    //event of finished impact animation
    if (bullets[i].impactAnimationFinished) {
      bullets.splice(i, 1);
      break;
    }
  }
}