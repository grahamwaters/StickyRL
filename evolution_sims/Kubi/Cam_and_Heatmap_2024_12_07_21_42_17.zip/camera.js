class Camera {
  constructor() {
    this.loc = createVector(terrainSize / 2, terrainSize / 2);
    this.centerOffset = createVector(width / 2, height / 2);

    this.maxShift = 80;

    this.visTL = createVector(this.loc.x - width / 2, this.loc.y - height / 2);
    this.visW = width;
    this.visH = height;

    this.locked = true;
    
    this.maxForce = 50;
    this.maxV = 0;
    this.vel = createVector();
  }

  setAnchor(anchor) {
    this.anchor = anchor;
    this.maxV = this.anchor.maxV*1.05;
  }

  update() {
    this.desLoc = this.anchor.loc.copy().add(this.shift());
    let distDesLoc = this.loc.copy().sub(this.desLoc).mag();
    
    if (distDesLoc >= this.anchor.vel.copy().mag()) {
      this.locked = false;
      this.vel.set(0, 0);
    }
    
    if (this.locked) {
      this.loc.set(this.desLoc);
    }
    else if(!this.locked){
      let desHeading = this.desLoc.copy().sub(this.loc);
      desHeading.setMag(this.maxV);
      let steering = desHeading.sub(this.vel);
      let force = map(distDesLoc, 0, this.maxShift, this.maxForce*0.1, this.maxForce);
      steering.limit(force);
      
      this.vel.add(steering);
      this.vel.limit(this.maxV);
      if(distDesLoc < this.maxV) this.vel.limit(distDesLoc*0.95);
      
      this.loc.add(this.vel);

      distDesLoc = this.loc.copy().sub(this.desLoc).mag();
      if(distDesLoc <= 1){
        this.locked = true;
      }
    }

    this.visTL.set(this.loc.x - width / 2, this.loc.y - height / 2);
  }

  shift() {
    let velAnchor = this.anchor.vel.copy();
    let shift = map(velAnchor.mag(), 0, this.anchor.maxV, 0, this.maxShift);
    return velAnchor.setMag(shift);
  }

  toScreenCoords(coords) {
    let screenCoords = coords.copy().sub(this.loc).add(this.centerOffset);
    return screenCoords;
  }
  
  display(){
    if(displayShiftFrame) this.displayCircle();
    this.displayCross();
  }

  displayCircle() {
    let opac = 150;
    if(this.locked) stroke(0, 173, 5, opac);
    else if(!this.locked) stroke(255, 0, 0, opac);
    strokeWeight(3);
    noFill();
    circle(width / 2, height / 2, this.maxShift * 2);
    
    if(!this.locked){
    stroke(255,0,0);
      strokeWeight(5);
      point(this.toScreenCoords(this.desLoc).x, this.toScreenCoords(this.desLoc).y);
     
      strokeWeight(1);
      stroke(255,0,0, 100);
      line(width/2, height/2, this.toScreenCoords(this.desLoc).x, this.toScreenCoords(this.desLoc).y);
    }
  }
    
  displayCross(){
    stroke(255, 200);
    strokeWeight(1);
    line(width/2-10, height/2, width/2+10, height/2);
    line(width/2, height/2-10, width/2, height/2+10);
  }
}
