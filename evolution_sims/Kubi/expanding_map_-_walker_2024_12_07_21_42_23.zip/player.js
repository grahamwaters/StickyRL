class Player {
  constructor() {
    this.r = 16;

    this.trueLoc = screenCenter.copy().sub(mc.offset);
    this.trueLocPrevFrame = createVector();
    this.rearLoc = createVector();
    this.vel = createVector();
    this.acc = createVector();
    this.ang = -HALF_PI;

    this.turnrate = 0.06;

    this.glide = 0.8;
    this.maxV = 10;
    this.maxBoost = 2; //this.maxV * 0.1; //.35;

    this.velDisplay = createVector();

    this.collision = false;
  }

  move(dir) {
    var boost = map(this.vel.mag(), 0, this.maxV, this.maxBoost, this.maxBoost * 0.5);

    if (dir == 0) { //forward
      this.acc.y = -boost;
    } else if (dir == 1) {
      this.acc.x = boost;
    } else if (dir == 2) { //back
      this.acc.y = boost;
    } else {
      this.acc.x = -boost;
    }
  }

  updateHeading() {
    this.ang = this.ang % TWO_PI;
    var maxTurnrate = 0.4;
    var mouseToPlayer = createVector(mouseX, mouseY).sub(mc.toScreen(this.trueLoc));

    var angMouse = CustomFunction.convertTo2PiSystem(mouseToPlayer.heading());
    var angPlayer = abs(CustomFunction.convertTo2PiSystem(this.ang));

    var diff = abs(angMouse - angPlayer);
    var absDiff = diff;

    if (diff > PI) {
      absDiff = TWO_PI - diff;
    }

    var turnRate = map(absDiff, 0, PI, 0, maxTurnrate);

    if (diff < PI) {
      if (angMouse > angPlayer) {
        this.ang += turnRate;
      } else {
        this.ang -= turnRate;
      }
    } else {
      if (angMouse > PI) {
        this.ang -= turnRate;
      } else {
        this.ang += turnRate;
      }
    }
  }

  updateTrueLoc() {
    this.trueLocPrevFrame = this.trueLoc.copy();
    this.vel.add(this.acc);
    //this.checkCollision();
    this.trueLoc.add(this.vel);
    this.acc.mult(0);
    this.vel.mult(this.glide);
    this.vel.limit(this.maxV);
  }

  updateMisc() {
    this.velDisplay.set(this.trueLoc.copy().add(this.vel.copy().mult(10)));
  }

  checkCollision() {
    //returns undefined when no collision
    //returns new location when collision
    var dist;
    this.collision = false;

    //when more than 9 tiles: use mapController.getIndicesNeighborTiles() for efficiency
    for (let j = 0; j < tiles.length; j++) {
      if (tiles[j].containsBoulder) {
        dist = this.trueLoc.copy().sub(tiles[j].boulder.trueLoc).mag();
        if (dist < tiles[j].boulder.r + this.r) {
          for (let k = 0; k < tiles[j].boulder.elements.length; k++) {

            dist = this.trueLoc.copy().sub(tiles[j].boulder.elements[k].trueLoc).mag();
            if (abs(dist) < this.r + tiles[j].boulder.elements[k].r) {
              this.repel(tiles[j].boulder);
              this.collision = true;
              break;
            }
          }

        }
      }
    }
  }

  repel(boulder) {
    
    //find boulder element at which player gets repelled
    var incoming = CustomFunction.interpolate(this.trueLocPrevFrame.copy(), this.trueLoc.copy(), round(this.vel.mag() / 2) + 1);

    var dist;
    var repelElement;

    for (let i = 0; i < incoming.length; i++) {
      for (let j = 0; j < boulder.elements.length; j++) {

        dist = incoming[i].copy().sub(boulder.elements[j].trueLoc).mag();

        if (dist < boulder.elements[j].r + this.r) {
          repelElement = boulder.elements[j];
          break;
        }
      }
      if (repelElement != undefined) {
        break;
      }
    }
    
    
    var contactVec = repelElement.trueLoc.copy().sub(this.trueLoc);

    var newVelAng = 2*contactVec.heading()-this.vel.heading()+PI;
    var currentV = this.vel.mag();

    
    //calculate overlap
    var overlap = repelElement.r + this.r - contactVec.mag();
    
    //move player outside of boulder element
    this.trueLoc.add(contactVec.mult(-1).setMag(overlap));
    
  
    this.vel.set(1, 0).rotate(newVelAng).mult(currentV);

    
    
  }

  shoot() {
    var dir = createVector(1, 0).rotate(this.ang);
    bullets.push(new Bullet(this.trueLoc.copy(), dir));
  }


  display() {
    push();
    translate(mc.toScreen(this.trueLoc).x, mc.toScreen(this.trueLoc).y);
    rotate(this.ang);

    fill(0);

    strokeWeight(1);
    if (this.collision) {
      stroke(255, 0, 0);
    } else {
      stroke(255);
    }
    circle(0, 0, this.r);

    stroke(255, 0, 0);
    strokeWeight(3);
    line(0, 0, this.r, 0);
    stroke(255, 80);
    strokeWeight(1);
    line(0, 0, 2 * width, 0);
    pop();

    var opac = map(this.vel.mag(), 0, this.maxV, 50, 255);
    stroke(50, 200, 240, opac);
    strokeWeight(4);
    line(mc.toScreen(this.trueLoc).x, mc.toScreen(this.trueLoc).y, mc.toScreen(this.velDisplay).x, mc.toScreen(this.velDisplay).y);

    stroke(255, 150);
    strokeWeight(1);
    line(screenCenter.x - 10, screenCenter.y, screenCenter.x + 10, screenCenter.y);
    line(screenCenter.x, screenCenter.y - 10, screenCenter.x, screenCenter.y + 10);

    fill(255);
    noStroke();
    var debugText = round(this.trueLoc.x) + ", " + round(this.trueLoc.y);
    text(debugText, mc.toScreen(this.trueLoc).x + 15, mc.toScreen(this.trueLoc).y + 15);
  }
}