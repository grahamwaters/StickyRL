class MapController {
  constructor() {
    
    this.offset = createVector(width/2-gridsize/2, height/2-gridsize/2);
    this.centerLoc = createVector();
    this.totalMapShiftPrevFrame = createVector();
  }
  
  shiftByOffset(){
    this.centerLoc.add(this.offset);
  }

  updateMapPos() {
   
    var deltaMapShift = this.totalMapShiftPrevFrame.copy().sub(this.totalMapShift());
    var delta = this.playerMovement().sub(deltaMapShift); //amount world has to move

    if (delta.y < 0) {
      this.moveMap("down", delta.y);
      //print(frameCount, "map down");
    }
    if (delta.y > 0) {
      this.moveMap("up", delta.y);
    }
    if (delta.x < 0) {
      this.moveMap("right", delta.x);
      //print(frameCount, "map right");
    }
    if (delta.x > 0) {
      this.moveMap("left", delta.x);
      //print(frameCount, "map left");
    }
    this.totalMapShiftPrevFrame = this.totalMapShift();
  }

  moveMap(dir, stepsize) {
    switch (dir) {
      case "up":
        this.centerLoc.y -= stepsize;
        break;
      case "right":
        this.centerLoc.x -= stepsize;
        break;
      case "down":
        this.centerLoc.y -= stepsize;
        break;
      case "left":
        this.centerLoc.x -= stepsize;
        break;
    }
    this.updateTiles(dir);
  }

  playerMovement() {
    var playerMovement = player.trueLoc.copy().sub(player.trueLocPrevFrame);
    return playerMovement;
  }

  totalMapShift() {
    var maxShift = map(player.maxV, 0, 50, 0, width/2);
    var dZ = map(this.playerMovement().mag(), 0, player.maxV, 0, maxShift); //distance player must be from center based on its speed
    var totalMapShift = player.vel.copy().setMag(dZ); 
    return totalMapShift;
  }

  updateTiles(mapMovementDir) {
    var sideToDelete = this.checkPosOfFringeTiles();
    if (sideToDelete != undefined) {
      this.deleteSide(sideToDelete);

      switch (sideToDelete) {
        case "top":
          this.addSide("bottom");
          break;
        case "right":
          this.addSide("left");
          break;
        case "bottom":
          this.addSide("top");
          break;
        case "left":
          this.addSide("right");
          break;
      }
      tiles = CustomFunction.sort2Darray(tiles);
      this.updateCornerIndices();
    }
  }

  checkPosOfFringeTiles() {
    if (tiles[this.topLeft].isOutsideActiveArea("left")) {
          return "left";
        }
    else if (tiles[this.topLeft].isOutsideActiveArea("top")) {
          return "top";
        }
    else if (tiles[this.bottomRight].isOutsideActiveArea("right")) {
          return "right";
        }
    else if (tiles[this.bottomRight].isOutsideActiveArea("bottom")) {
          return "bottom";
        }
    else {
      return;
    }
  }

  updateCornerIndices() {
    this.topLeft = 0;
    this.bottomRight = tiles.length - 1;

    this.lowX = tiles[this.topLeft].index[0];
    this.highX = tiles[this.bottomRight].index[0];
    this.lowY = tiles[this.topLeft].index[1];
    this.highY = tiles[this.bottomRight].index[1];

    //print("init: topleft", this.lowX, this.lowY, "- bottomright", this.highX, this.highY, "- nX", this.highX-this.lowX+1, "-nY", this.highY-this.lowY+1);
  }



  deleteSide(sideToDelete) {
    switch (sideToDelete) {
      case "left":
        for (let i = tiles.length - 1; i >= 0; i--) {
          if (tiles[i].index[0] == this.lowX) {
            tiles.splice(i, 1);
          }
        }
        break;

      case "top":
        for (let i = tiles.length - 1; i >= 0; i--) {
          if (tiles[i].index[1] == this.lowY) {
            tiles.splice(i, 1);
          }
        }
        break;
      case "right":
        for (let i = tiles.length - 1; i >= 0; i--) {
          if (tiles[i].index[0] == this.highX) {
            tiles.splice(i, 1);
          }
        }
        break;

      case "bottom":
        for (let i = tiles.length - 1; i >= 0; i--) {
          if (tiles[i].index[1] == this.highY) {
            tiles.splice(i, 1);
          }
        }
        break;
    }
  }

  addSide(side) {
    
    var n;
    
    switch (side) {
      case "top":
        //print("add top");
        n = this.highX - this.lowX + 1;
        for (let i = 0; i < n; i++) {
          tiles.push(new Tile([this.lowX + i, this.lowY - 1]));
        }
        break;
      case "bottom":
        //print("add bottom");
        n = this.highX - this.lowX + 1;
        for (let i = 0; i < n; i++) {
          tiles.push(new Tile([this.lowX + i, this.highY + 1]));
        }
        break;
      case "left":
        //print("add left");
        n = this.highY - this.lowY + 1;
        for (let i = 0; i < n; i++) {
          tiles.push(new Tile([this.lowX - 1, this.lowY + i]));
        }
        break;
      case "right":
        //print("add right");
        n = this.highY - this.lowY + 1;
        for (let i = 0; i < n; i++) {
          tiles.push(new Tile([this.highX + 1, this.lowY + i]));
        }
        break;
    }
    
  }
  
  toScreen(trueCoordinates){
    return this.centerLoc.copy().add(trueCoordinates);
  }

  logTiles() {
    print("active tiles at framecount", frameCount, "screen size:", width)
    for (let i = 0; i < tiles.length; i++) {
      print(i + ": [" + tiles[i].index[0] + ",  " + tiles[i].index[1] + "]; screen pos: " + round(tiles[i].position.x) + ", " + round(tiles[i].position.y));
    }
  }
  
  getIndexCurrentTile(location){
    var index = [floor(location.x / gridsize), floor(location.y / gridsize)]
    return index;
  }
  
  getIndizesNeighborTiles(indexCurrentTile){
    var x = indexCurrentTile[0];
    var y = indexCurrentTile[1];
    var indizes = [[x-1, y-1], [x, y-1], [x+1, y-1], [x-1, y], [x+1, y], [x-1, y+1], [x, y+1], [x+1, y+1]];
    return indizes;
  }

  display() {
    fill(255);
    noStroke();
    text(tiles.length, 5, 16);

    //move to separate class!!!
    var radius = width / 4;
    stroke(255, 30);
    strokeWeight(1);
    noFill();
    //circle(width/2, height/2, radius);

    fill(255);
    noStroke();
    var str = "x: " + (this.centerLoc.x + width / 2) + ", y: " + (this.centerLoc.y + height / 2);
    //text(str, 5, 40);
  }
}