class Tile {
  constructor(index) {
    this.index = index;
    this.pos = createVector(this.index[0] * gridsize, this.index[1] * gridsize);
    
    //print(frameCount, this.pos);

    this.trueLoc = this.pos.copy().add(mc.centerLoc);

    this.lines = new Array(round(random(10, 30)));
    for (let i = 0; i < this.lines.length; i++) {
      this.lines[i] = new Line();
    }

    if (random(1) > .1) {
      var relBoulderPosition = createVector();
      relBoulderPosition.x = random(gridsize / 5, gridsize * 4 / 5);
      relBoulderPosition.y = random(gridsize / 5, gridsize * 4 / 5);
      this.boulder = new Boulder(this.pos, relBoulderPosition);
      this.containsBoulder = true;
    }
    
    this.r = sin(index[0] * 0.015) * 100 + 100; //0 - 200
    this.b = sin(index[1] * 0.015) * 100 + 155; //55-255
  }

  update() {
    this.trueLoc.set(mc.centerLoc.x + this.index[0] * gridsize, mc.centerLoc.y + this.index[1] * gridsize);
  }

  isOutsideActiveArea(side) {
    switch (side) {
      case "left":
        if (this.trueLoc.x < screenCenter.x-(tileBuffer+1)*gridsize){
          
          return true;
        } else {
          return false;
        }

      case "right":
        if (this.trueLoc.x > screenCenter.x+tileBuffer*gridsize){
          return true;
        } else {
          return false;
        }

      case "top":
        if(this.trueLoc.y < screenCenter.y-(tileBuffer+1)*gridsize){
          return true;
        } else {
          return false;
        }

      case "bottom":
        if (this.trueLoc.y > screenCenter.y+tileBuffer*gridsize){
          return true;
        } else {
          return false;
        }
    }
  }

  displayFill() {
    fill(this.r, 0, this.b);
    //stroke(this.r, 0, this.b);
    stroke(255, 30);
    strokeWeight(1);
    rect(this.trueLoc.x, this.trueLoc.y, gridsize, gridsize);
  }
  display() {

    textSize(16);
    fill(255, 150);
    noStroke();
    var debugText = "[" + this.index[0] + ", " + this.index[1] + "]";
    text(debugText, this.trueLoc.x + 5, this.trueLoc.y + 36);

    debugText = this.pos.x + ", " + this.pos.y;
    text(debugText, this.trueLoc.x + 5, this.trueLoc.y + 18);

    for (let i = 0; i < this.lines.length; i++) {
      this.lines[i].display(this.trueLoc);
    }
    if (this.boulder) {
      this.boulder.display();
    }
  }
}

class Line {
  constructor() {
    this.l = random(gridsize * sqrt(2) * 0.1, gridsize * sqrt(2));
    this.x1 = random(0, gridsize);
    this.y1 = random(0, gridsize);

    this.x2 = this.x1 + cos(-PI / 4) * this.l;
    this.y2 = this.y1 + sin(-PI / 4) * this.l;

    this.opac = random(2, 80);

  }
  display(tilePosLoc) {
    stroke(255, this.opac);
    strokeWeight(1);
    line(tilePosLoc.x + this.x1, tilePosLoc.y + this.y1, tilePosLoc.x + this.x2, tilePosLoc.y + this.y2);
  }
}