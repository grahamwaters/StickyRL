class Boulder {
  constructor(trueLocTile, relPosInTile) {
    var nElements = round(random(20, 40));
    var minElementR = 10;
    var maxElementR = 25;
    this.r = 70;

    this.relPosInTile = relPosInTile;
    this.trueLoc = p5.Vector.add(trueLocTile, this.relPosInTile);

    this.elements = new Array(nElements);
    this.elements[0] = new BoulderElement(this.trueLoc, createVector(0, 0), random(minElementR, maxElementR));

    var rElement, indexFather, father, rFather, minDist, maxDist, relAng, pos, fit;

    for (let i = 1; i < nElements; i++) {
      fit = false;
      while (!fit) {
        rElement = round(random(minElementR, maxElementR));
        indexFather = floor(random(0, i));
        pos = createVector();
        father = this.elements[indexFather];
        rFather = father.r;
        minDist = 0;
        maxDist = 0;
        relAng = random(TWO_PI);

        if (rElement >= rFather) {
          minDist = rElement - rFather;
          maxDist = (rElement + rFather) * 0.6;
        } else if (rElement < rFather) {
          minDist = rFather - rElement;
          maxDist = (rFather + rElement) * 0.6;
        }

        pos.x = father.relPosToBoulderCenter.x + random(cos(relAng) * minDist, cos(relAng) * maxDist);
        pos.y = father.relPosToBoulderCenter.y + random(sin(relAng) * minDist, sin(relAng) * maxDist);
        if(pos.mag() + rElement < this.r){
          fit = true;
        }

      }
      this.elements[i] = new BoulderElement(this.trueLoc, pos, rElement);
    }
  }

  display() {
    for (let i = 0; i < this.elements.length; i++) {
      this.elements[i].displayOutline();
    }
    for (let i = 0; i < this.elements.length; i++) {
      this.elements[i].displayFill();
    }
    stroke(255, 70);
    strokeWeight(1);
    noFill();
    circle(mc.toScreen(this.trueLoc).x, mc.toScreen(this.trueLoc).y, this.r);
  }
}


class BoulderElement {
  constructor(boulderTrueLoc, relPosToBoulderCenter, r) {
    this.relPosToBoulderCenter = relPosToBoulderCenter;
    this.r = r;
    this.trueLoc = p5.Vector.add(boulderTrueLoc, relPosToBoulderCenter);

  }

  displayCoords() {


    fill(255);
    noStroke();
    var debugText = round(this.trueLoc.x) + ", " + round(this.trueLoc.y);
    text(debugText, this.screenPos.x, this.screenPos.y);

  }

  displayOutline() {

    noStroke()
    fill(255);
    circle(mc.toScreen(this.trueLoc).x, mc.toScreen(this.trueLoc).y, this.r);

  }

  displayFill() {
    noStroke();
    fill(50);
    circle(mc.toScreen(this.trueLoc).x, mc.toScreen(this.trueLoc).y, this.r - 1);
  }
}