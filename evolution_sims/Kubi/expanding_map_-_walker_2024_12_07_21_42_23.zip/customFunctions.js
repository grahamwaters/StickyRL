class CustomFunction {
  static sort2Darray(input2DArray) {

    //new array which contains sorted chunks
    var sortedChunks = [];

    //variables
    var tempLowestX;
    var tempLowestY;

    //temporary unsorted array which contains all chunks with the same y-value
    var tempSameY;

    //loop while there are still chunks in the chunksCopy-array
    while (input2DArray.length > 0) {

      //arbitrary assign y-value of first chunk as temporary lowest y-value
      tempLowestY = input2DArray[0].index[1];

      //go through remaining chunks and find the truly lowest y-value
      for (let i = 1; i < input2DArray.length; i++) {
        if (input2DArray[i].index[1] < tempLowestY) {
          tempLowestY = input2DArray[i].index[1];
        }
      }

      tempSameY = [];

      //copy all chunks with this lowest y-value to the same temporary array and cut them from the inputArray
      for (let i = input2DArray.length - 1; i >= 0; i--) {
        if (input2DArray[i].index[1] == tempLowestY) {
          tempSameY.push(input2DArray[i]);
          input2DArray.splice(i, 1);
        }
      }

      //loop while there still chunks in the tempSameY-array
      while (tempSameY.length > 0) {
        //arbitrary assign x-value of first chunk in tempSameY-array as temporary lowest x-value
        tempLowestX = tempSameY[0].index[0];

        //go through tempSameY-array and find the truly lowest x-value
        for (let i = 1; i < tempSameY.length; i++) {
          if (tempSameY[i].index[0] < tempLowestX) {
            tempLowestX = tempSameY[i].index[0];
          }
        }

        //copy all chunks with this lowest x-value to the final sortedChunks-array and cut them from the tempSameY-array
        for (let i = tempSameY.length - 1; i >= 0; i--) {
          if (tempSameY[i].index[0] == tempLowestX) {
            sortedChunks.push(tempSameY[i]);
            tempSameY.splice(i, 1);
          }
        }
      }
    }
    return sortedChunks;
  }

  static convertTo2PiSystem(origAng) {
    var newAng;
    if (origAng < 0) {
      newAng = TWO_PI - abs(origAng);
    } else {
      newAng = origAng;
    }
    return newAng;
  }

  static interpolate(coordsA, coordsB, nSteps) {
    var step = coordsB.sub(coordsA).div(nSteps);
    var interpolated = new Array(nSteps);
    for (let i = 0; i < nSteps; i++) {
      interpolated[i] = p5.Vector.add(coordsA, step.copy().mult(i + 1));
    }
    return interpolated;
  }

}