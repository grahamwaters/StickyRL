//enemies
//enemy-AI
//repulsion from boulders
//bug: player faster diagonally
//bug: lines get sometimes rendered on top of boulders
//support different canvas sizes
//boulder-DNA

function setup() {
  createCanvas(400, 400);
  tiles = [];
  paused = false;
  screenCenter = createVector(width / 2, height / 2);

  logFrameRate = [];
  avgFrameRate = frameRate();

  gridsize = 300;
  tileBuffer = 1;
  
  mc = new MapController();
  player = new Player();
  bullets = [];
  
  mover = [false, false, false, false];

  for (let i = -tileBuffer; i < width / gridsize + tileBuffer-1; i++) {
    for (let j = -tileBuffer; j < height / gridsize + tileBuffer-1; j++) {
      tiles.push(new Tile([i, j]));
    }
  }
  tiles = CustomFunction.sort2Darray(tiles);
  mc.updateCornerIndices();
  mc.shiftByOffset();
}

function draw() {
  background(0, 255, 0);
  if (!paused) {
    checkInput();
    player.updateHeading();
    player.updateTrueLoc();
    //player.checkCollision();
    
    mc.updateMapPos();
    handleBullets();
    for (let i = 0; i < tiles.length; i++) {
      tiles[i].update();
    }
    player.updateMisc();
    
  }
  
  for (let i = 0; i < tiles.length; i++) {
    tiles[i].displayFill();
  }
  
  for (let i = 0; i < tiles.length; i++) {
    tiles[i].display();
  }
  
  mc.display();
  for(let i = 0; i < bullets.length; i++){
   bullets[i].display(); 
  }
  player.display();
  Debugger.displayBottomLeft([player.vel.mag()]);
  updateFrameRate();
  displayFrameRate();
}

function checkInput() {

  if (mover[0]) { //forward
    player.move(0);
  }
  if (mover[1]) { //right
    player.move(1);
  }
  if (mover[2]) { //back
    player.move(2);
  }
  if (mover[3]) { //left
    player.move(3);
  }
}

function handleBullets() {
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].update();

    //event of finished impact animation
    if (bullets[i].impactAnimationFinished) {
      bullets.splice(i, 1);
      break;
    }
  }
}

function updateFrameRate() {
  var lArray = 30;
  if (logFrameRate.length >= lArray) {
    logFrameRate.splice(0, 1);
  }
  logFrameRate.push(frameRate());
  var avg = 0;
  for (let i = 0; i < logFrameRate.length; i++) {
    avg += logFrameRate[i];
  }
  avgFrameRate = avg / logFrameRate.length;
}

function displayFrameRate(){
  var notRed = map(avgFrameRate, 30, 55, 0, 255);
  noStroke();
  fill(255, notRed, notRed, 200);
  text(parseInt(avgFrameRate), width - 25, 20);
}

function keyPressed() {
  //moving
  if (key === "w" || key === "W") {
    mover[0] = true;
  }
  if (key === "d" || key === "D") {
    mover[1] = true;
  }
  if (key === "s" || key === "S") {
    mover[2] = true;
  }
  if (key === "a" || key === "A") {
    mover[3] = true;
  }

  //testing
  if (key === "t") {
    print("test");
  }
  
  if (key === "p" || key === "P") {
    paused = !paused;
  }
  
  if (key === "l" || key === "L") {
    mapController.logTiles();
  }
}

function keyReleased() {
  if (key === "w" || key === "W") {
    mover[0] = false;
  }
  if (key === "d" || key === "D") {
    mover[1] = false;
  }
  if (key === "s" || key === "S") {
    mover[2] = false;
  }
  if (key === "a" || key === "A") {
    mover[3] = false;
  }

    
}

function mouseClicked() {
  player.shoot();
}