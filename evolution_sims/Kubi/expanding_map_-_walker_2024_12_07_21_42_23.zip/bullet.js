class Bullet {
  constructor(loc, dir) {
    //movement
    this.loc = loc;
    this.lastLoc = loc;
    this.impactLocScreen = createVector();
    this.impactLocTrue = createVector();

    this.speed = 30;
    this.vel = dir.setMag(this.speed);

    this.interpolated = new Array(round(this.speed / 3));

    //status
    this.hitWall = false; //false until bullet hits or wall
    this.hitObj = false;

    //bullet color
    this.red = 60;
    this.green = 255;
    this.blue = 150;

    //animation
    this.impactAnimationTimer = 0;
    this.maxImpactAnimationTime = 18; //duration of impact animation
    this.impactAnimationFinished = false; //false until impact animation has finished
  }

  update() {
    if (!this.hitWall && !this.hitObj) { //flying bullet
      this.lastLoc = this.loc.copy();
      this.loc.add(this.vel);
      this.checkBoulders();
      if (!this.hitObj) {
        this.checkWalls();
      }
    } else { //impact explosion
      this.impactAnimationTimer++;
      if (this.impactAnimationTimer >= this.maxImpactAnimationTime) {
        this.impactAnimationFinished = true;
      }
    }
  }

  checkWalls() {
    if (mc.toScreen(this.loc).x < this.speed || mc.toScreen(this.loc).x > width-this.speed || mc.toScreen(this.loc).y < this.speed || mc.toScreen(this.loc).y > height-this.speed) {
      this.interpolated = CustomFunction.interpolate(this.lastLoc.copy(), this.loc.copy(), this.interpolated.length);
      var coords;
      for (let i = 0; i < this.interpolated.length; i++){
        coords = mc.toScreen(this.interpolated[i].copy());
        if (coords.x < 0 || coords.x > width || coords.y < 0 || coords.y > height){
          this.hitWall = true;
          this.impactLocScreen = coords;
          break;
        }
      }
    }
  }

  checkBoulders() {
    var dist;

    //when more than 9 chunks: use mapController.getIndicesNeighborChunks() for efficiency
    for (let i = 0; i < tiles.length; i++) {
      if (tiles[i].containsBoulder) {
        dist = this.loc.copy().sub(tiles[i].boulder.trueLoc).mag();
        if (dist < tiles[i].boulder.r) {
          this.interpolated = CustomFunction.interpolate(this.lastLoc.copy(), this.loc.copy(), this.interpolated.length);
          for (let j = 0; j < this.interpolated.length; j++) {
            for (let k = 0; k < tiles[i].boulder.elements.length; k++) {

              dist = this.interpolated[j].copy().sub(tiles[i].boulder.elements[k].trueLoc).mag();
              if (abs(dist) < tiles[i].boulder.elements[k].r) {
                this.hitObj = true;
                this.impactLocTrue = this.interpolated[j].copy();
                break;
              }
            }
            if (this.hitObj) {
              break;
            }
          }
        }
      }
      if (this.hitObj) {
        break;
      }
    }

  }
  


  display() {
    if (!this.hitWall && !this.hitObj) {
      let temp = this.vel.copy().mult(-1).setMag(15).add(this.loc);
      stroke(this.red, this.green, this.blue);
      strokeWeight(6);
      line(mc.toScreen(this.loc).x, mc.toScreen(this.loc).y, mc.toScreen(temp).x, mc.toScreen(temp).y);
    } else {
      this.animateImpact();
    }
  }

  animateImpact() {

    //animation of impact explosion on wall
    var r = map(this.impactAnimationTimer, 0, this.maxImpactAnimationTime, 1, 25);
    var opacity = map(this.impactAnimationTimer, 0, this.maxImpactAnimationTime, 255, 0);
    noStroke();
    fill(this.red, this.green, this.blue, opacity);
    if (this.hitWall) {
      circle(this.impactLocScreen.x, this.impactLocScreen.y, r);
    } else {
      circle(mc.toScreen(this.impactLocTrue).x, mc.toScreen(this.impactLocTrue).y, r);
    }
  }
}