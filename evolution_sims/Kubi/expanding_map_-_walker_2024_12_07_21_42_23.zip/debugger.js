class Debugger{
  
  static displayBottomLeft(data){
    fill(255);
    noStroke();
    var str = round(data[0]);
    for(let i = 1; i < data.length; i++){
      str+=", ";
      str+=round(data[i]);
    }
    text(str, 5, height-5);
  }
  
}