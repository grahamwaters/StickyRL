class Particle {
  constructor(x, y){
    this.loc = createVector(x, y)
    this.vel = createVector(0, 0)
    this.maxSpeed = 1
    this.dia = 3
  }
  
  update(vector){
    this.vel.add(vector)
    this.vel.mult(0.9)
    this.vel.limit(this.maxSpeed)
    this.loc.add(this.vel)
    this.checkWalls()
  }
  
  checkWalls(){
    if(this.loc.x < 0) this.loc.x = width - 1
    if(this.loc.x >= width) this.loc.x = 0
    if(this.loc.y < 0) this.loc.y = height - 1
    if(this.loc.y >= height) this.loc.y = 0
  }
  
  render(){
     noStroke()
    fill(255)
    ellipse(this.loc.x, this.loc.y, this.dia, this.dia)
  }
}