function copyPixelsFromImage(inputImage) {
  // copies data from image pixel array of an image into a separate 4-channel-array
  inputImage.loadPixels();
  let pixelData = []

  for (let y = 0; y < inputImage.height; y++) {
    for (let x = 0; x < inputImage.width; x++) {
      let index = (x + y * inputImage.width) * 4;
      pixelData.push(inputImage.pixels[index + 0]);
      pixelData.push(inputImage.pixels[index + 1]);
      pixelData.push(inputImage.pixels[index + 2]);
      pixelData.push(inputImage.pixels[index + 3]);
    }
  }
  return pixelData
}

function convertToBW(pixelData, w, h) {
  // converts a color pixel array to a 4-channel black and white pixel array
  let output = []
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let index = (x + y * w) * 4;
      let r = pixelData[index + 0];
      let g = pixelData[index + 1];
      let b = pixelData[index + 2];

      let bright = (r + g + b) / 3

      // first 3 values: brightness
      for (let i = 0; i < 3; i++) {
        output.push(bright)
      }
      // alpha
      output.push(255)
    }
  }
  return output
}

function renderImage(pixelData, w, h) {
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {

      // flip video
      let index = pixelIndexReverse(x, y, w, 4)

      let r = pixelData[index + 0];
      let g = pixelData[index + 1];
      let b = pixelData[index + 2];

      fill(r, g, b)
      noStroke();
      rect(x * videoScale, y * videoScale, videoScale, videoScale)
    }
  }
}

function renderEdgeData(edgeData, w, h) {
  let maxPixelstrength = max(edgeData[0])
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {

      let index = pixelIndexReverse(x, y, w, 1)


      colorMode(HSB, 100)
      let hue = map(edgeData[1][index], -HALF_PI, HALF_PI, 0, 100)
      let saturation = map(edgeData[0][index], 0, 255, 0, 100)
      let bright = map(edgeData[0][index], 0, maxPixelstrength, 0, 100)
      
      fill(hue, saturation, bright)
      noStroke();
      rect(x * gridScale, y * gridScale, gridScale, gridScale)
      colorMode(RGB)
    }
  }
}

function edgeDetection(pixelData, w, h) {
  /*let filterVertical = [
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1]
  ]*/
  
  let filterVertical = [
    [-1, 1, 0],
    [-1, 1, 0],
    [-1, 1, 0]
  ]

  /*let filterHorizontal = [
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1]
  ]
  */
  
  let filterHorizontal = [
    [-1, -1, -1],
    [1, 1, 1],
    [0, 0, 0]
  ]

  let filteredData = []
  let orientations = []


  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let edgeVertical = convolusion(pixelData, x, y, w, h, filterVertical)
      let edgeHorizontal = convolusion(pixelData, x, y, w, h, filterHorizontal)

      let filteredPixel = sqrt(sq(edgeVertical) + sq(edgeHorizontal))
      
      let orientation = atan(edgeHorizontal/edgeVertical)

      /*for (let i = 0; i < 4; i++) {
        filteredData.push(filteredPixel)
      }*/
      filteredData.push(filteredPixel)
      orientations.push(orientation)
    }
  }
  return [filteredData, orientations]
}

function gaussianBlur(pixelData, w, h, strength) {
  //https://computergraphics.stackexchange.com/questions/39/how-is-gaussian-blur-implemented

  let filteredData = []

  let filter;
  if (strength == 1) {
    filter = 
      [
        [1, 2, 1],
        [2, 4, 2],
        [1, 2, 1]
      ]
  }
  else if(strength == 2){
    filter = 
      [
        [1, 4, 6, 4, 1],
        [4, 16, 24, 16, 4],
        [6, 24, 36, 24, 6],
        [4, 16, 24, 16, 4],
        [1, 4, 6, 4, 1]
      ]
  }
  
  let d = floor(filter[0].length/2)

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      
      let sumR = 0
      let sumG = 0
      let sumB = 0
      
      let filterSum = 0
      
      for (let dy = -d; dy <= d; dy++) {
        for (let dx = -d; dx <= d; dx++) {
          if (x + dx >= 0 && y + dy >= 0 && x + dx < w && y + dy < h) {
            let index = pixelIndex(x + dx, y + dy, w, 4)
            
            sumR += pixelData[index + 0] * filter[dy + d][dx + d]
            sumG += pixelData[index + 1] * filter[dy + d][dx + d]
            sumB += pixelData[index + 2] * filter[dy + d][dx + d]

            filterSum += filter[dy + d][dx + d]
          }
        }
      }
      sumR /= filterSum
      sumG /= filterSum
      sumB /= filterSum
      
      filteredData.push(sumR)
      filteredData.push(sumG)
      filteredData.push(sumB)
      filteredData.push(255)
    }
  }
  return filteredData
}

function convolusion(data, x, y, w, h, filter) {
  let sum = 0

  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      //if(x + dx >= 0 && y + dy >= 0 && x + dx < w && y + dy < h){
      //let index = pixelIndex(x + dx, y + dy, w)
      //sum += data[index] * filter[dy + 1][dx + 1]
      //}
      let index;
      if (x + dx < 0 || y + dy < 0 || x + dx >= w || y + dy >= h) {
        //edge case
        index = pixelIndex(x, y, w, 4)
      } else {
        index = pixelIndex(x + dx, y + dy, w, 4)
      }
      sum += data[index] * filter[dy + 1][dx + 1]
    }
  }
  return sum
}

function pixelIndex(x, y, w, nChannels) {
  return (x + y * w) * nChannels
}

function pixelIndexReverse(x, y, w, nChannels) {
  return (w - (x + 1) + (y * w)) * nChannels
}