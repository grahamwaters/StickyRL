// https://www.youtube.com/watch?v=rNqaw8LT2ZU

gridScale = 10
nParticles = 500

function setup() {
  createCanvas(480, 360)
  background(30)
  
  video = createCapture(VIDEO)
  video.hide()
  
  // reduce video resolution (aspect ratio stays the same!)
  video.size(width / gridScale, height / gridScale)

  particles = []
  for(let i = 0; i < nParticles; i++){
    particles.push(new Particle(random(width), random(height)))
  }
}

function draw() {
  background(30, 50)
  let pixelData = copyPixelsFromImage(video)  // 1D-array
  
  pixelData = gaussianBlur(pixelData, video.width, video.height, 1) // 1D-array
  
  

  edgeData = edgeDetection(pixelData, video.width, video.height)    // 1D-array
  //renderEdgeData(edgeData, video.width, video.height)

  let noisemap = generateNoisemap(width/gridScale, height/gridScale, 0.01)
  let vectormapNoise = generateVectormapFromNoisemap(noisemap)
  
  let vectormapEdges = generateVectormapFromEdgeArray(edgeData[1], video.width, video.height)
  
  if(frameCount > 120){
  for(let p of particles){
    let indX = floor(p.loc.x / gridScale)
    let indY = floor(p.loc.y / gridScale)
    p.update(vectormapNoise[indY][indX])
    p.render()
  } 
  }
}

function keyPressed() {
  if (key == 'b' || key == 'B') {
    blurMode++
    if(blurMode > 2) blurMode = 0
  }
  if (key == 'e' || key == 'E') {
    toggleEdges = !toggleEdges
  }
}



