function generateNoisemap(w, h, noiseScale){
  let noisemap = []
  for (let y = 0; y < h; y++) {
    noisemap[y] = [];
    for (let x = 0; x < w; x++) {
      let n = noise(x * noiseScale, y * noiseScale, frameCount * noiseScale);
      noisemap[y].push(n)
    }
  }
  return noisemap
}

function generateVectormapFromNoisemap(noisemap){
  let vectormap = []
  for(let y = 0; y < noisemap.length; y++){
    vectormap[y] = []
    for(let x = 0; x < noisemap[y].length; x++){
      let vector = createVector(1, 0)
      vector.rotate(TWO_PI * noisemap[y][x])
      vectormap[y].push(vector)
    }
  }
  return vectormap
}

function generateVectormapFromEdgeArray(edgeArray, w, h){
  let vectormap = []
  for(let y = 0; y < h; y++){
    vectormap[y] = []
    for(let x = 0; x < w; x++){
      let index = x + y * w
      let vector = createVector(1, 0)
      vector.rotate(TWO_PI * edgeArray[index])
      vectormap[y].push(vector)
    }
  }
  return vectormap
}