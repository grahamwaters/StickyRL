mapWidth = 300;
mapHeight = 300;
panelHeight = 150;
buffer = 10;
mapX = buffer;
mapY = buffer;
dragging = false;
dX = 0;
dY = 0

function setup() {
  createCanvas(560, mapHeight + panelHeight + 3 * buffer);
  pixelDensity(1);

  mode = "terrain";

  octaveOffsets = generateOctaveOffsets();
  regions = createRegions();

  ui = new UI();
  ui.init();

  editor = new MapEditor(ui);
  editor.init();
  UI.connect(ui, editor);

  generator = new MapGenerator();

  world = new Map(mapX, mapY, mapWidth, mapHeight);
  world.init();
  world.createTexture();
}

function draw() {
  if (dragging) {
    dX += (mouseX - mouseXStart)*editor.noiseScale;
    dY += (mouseY - mouseYStart)*editor.noiseScale;
    mouseXStart = mouseX;
    mouseYStart = mouseY;
    world.init();
    world.createTexture();
  }
  
  background(0);
  image(world.texture, world.x, world.y);
  ui.displayText();
  displayGraph();
  displayMapMode();
}

function displayGraph() {
  // NEEDS COMPLETE OVERHAUL!!

  let panelY = mapY + mapHeight + buffer;
  let panelX = mapX;
  let panelWidth = mapWidth;
  let heightTerrainBand;

  noStroke();
  for (let i = regions.length - 1; i >= 0; i--) {
    heightTerrainBand = map(regions[i].height, 0, 1, 0, panelHeight);

    fill(regions[i].clr);

    rect(panelX, panelY + panelHeight - heightTerrainBand, panelWidth, heightTerrainBand);
  }

  let currentDY = 0;
  for (let i = 0; i < 10; i++) {
    fill(map(i, 9, 0, 0, 255));

    rect(panelX + panelWidth + 5, panelY + currentDY, 25, panelHeight / 10);
    currentDY += panelHeight / 10;
  }
  colorMode(RGB);


  let y = editor.crossSectionY;
  let noiseValue, vertexY;
  noFill();
  stroke(255, 30, 30);
  strokeWeight(2);

  beginShape();
  for (let x = 0; x < mapWidth; x++) {

    noiseValue = generator.noiseMap[y][x];

    vertexY = height - buffer - panelHeight * noiseValue;
    vertex(x + panelX, vertexY + 1);

  }
  endShape();

  line(panelX, y + mapY, panelX + panelWidth + 15, y + mapY);

  if (mouseOnMap() || mouseOnPanel()) {
    stroke(255, 150);
    strokeWeight(1);
    line(mouseX, mapY, mouseX, mapY + mapHeight);
    line(mouseX, panelY, mouseX, panelY + panelHeight);

    stroke(255, 30, 30);
    strokeWeight(7);
    point(mouseX, y + mapY);

    vertexY = height - buffer - panelHeight * generator.noiseMap[y][mouseX - panelX];
    point(mouseX, vertexY);
    
    if(mouseOnMap()){
      let value = generator.noiseMap[editor.crossSectionY][mouseX-mapX];
      value = round(value*100)/100
      fill(255)
      noStroke();
      textSize(16)
      textAlign(LEFT, BOTTOM)
      text(value, mouseX + 3, buffer + editor.crossSectionY)
    }
  }
}

function mouseOnMap() {
  return (mouseX >= mapX && mouseX < mapX + mapWidth && mouseY >= mapY && mouseY < mapY + mapHeight);
}

function mouseOnPanel() {
  return (mouseX >= mapX && mouseX <= mapX + mapWidth && mouseY >= mapY + mapHeight + buffer && mouseY <= height - buffer);
}

function generateOctaveOffsets() {
  let offsets = [];
  let offsetX, offsetY;
  for (let i = 0; i < 10; i++) {
    offsetX = random(-100000, 100000);
    offsetY = random(-100000, 100000);
    offsets.push(createVector(offsetX, offsetY));
  }
  return offsets;
}

function createRegions() {
  let regions = [];

  deepWater = new TerrainType("deep water", 0.1, color(50, 50, 150));
  regions.push(deepWater);

  mediumWater = new TerrainType("medium water", 0.3, color(62, 62, 194));
  regions.push(mediumWater);

  shallowWater = new TerrainType("shallow water", 0.5, color(71, 71, 255));
  regions.push(shallowWater);

  beach = new TerrainType("beach", 0.53, color(217, 210, 120));
  regions.push(beach);

  grass = new TerrainType("grass", 0.63, color(67, 204, 67));
  regions.push(grass);

  forest = new TerrainType("forest", 0.78, color(17, 99, 33));
  regions.push(forest);

  dirt = new TerrainType("dirt", 0.85, color(30, 75, 40));
  regions.push(dirt);

  rock = new TerrainType("rock", 0.95, color(48, 41, 41));
  regions.push(rock);

  snow = new TerrainType("snow", 1, color(255));
  regions.push(snow);

  return regions;
}

function newTerrain() {
  octaveOffsets = generateOctaveOffsets();
  world.init();
  world.createTexture();
}

function changeMode() {
  if (mode == "greyscale") mode = "height";
  else if (mode == "height") mode = "terrain";
  else if (mode == "terrain") mode = "greyscale";
  world.init();
  world.createTexture();
}

function displayMapMode() {
  textSize(14);
  fill(255);
  noStroke();
  
  let str;
  
  if(mode == "greyscale"){
    str = "map mode: noise";
  }
  else { 
    str = "map mode: " + mode;
  }
  text(str, 380, 450);
}