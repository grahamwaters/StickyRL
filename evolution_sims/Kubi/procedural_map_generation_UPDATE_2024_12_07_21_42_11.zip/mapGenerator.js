class MapGenerator {
  generateMap(width, height, noiseScale, octaves, persistance, lacunarity, scaleAdjustment, shift){
    this.noiseMap = Noise.generateNoiseMap(width, height, noiseScale, octaves, persistance, lacunarity, scaleAdjustment, shift);
    
    if(mode == "terrain") return MapGenerator.convertNoiseToTerrainMap(this.noiseMap);
    else if (mode =="height") return MapGenerator.convertNoiseToHeightMap(this.noiseMap);
    else if (mode =="greyscale") return MapGenerator.convertNoiseToGreyscaleMap(this.noiseMap);
  }
  
  static convertNoiseToTerrainMap(noiseMap){
    let terrainMap = [];
    
    let height = noiseMap.length;
    let width = noiseMap[0].length;
    
    let currentHeight;
    
    for(let y = 0; y < height; y++){
      for(let x = 0; x < width; x++){
        currentHeight = noiseMap[y][x];
        
        for(let i = 0; i < regions.length; i++){

          if(currentHeight <= regions[i].height){
            terrainMap.push(regions[i].clr);
           break; 
          }
        }
      }
    }
    return terrainMap;
  }
  
  static convertNoiseToHeightMap(noiseMap){
    let heightMap = [];
    
    let height = noiseMap.length;
    let width = noiseMap[0].length;
    
    let currentHeight, discretizedHeight;
    
    for(let y = 0; y < height; y++){
      for(let x = 0; x < width; x++){
        currentHeight = noiseMap[y][x];
        discretizedHeight = floor(currentHeight*10)/10
        heightMap.push(color(map(discretizedHeight, 0, 0.9, 0, 255)));
      }
    }
    return heightMap;
  }
  
  static convertNoiseToGreyscaleMap(noiseMap){
    let greyscaleMap = [];
    
    let height = noiseMap.length;
    let width = noiseMap[0].length;
    
    let clr;
    
    for(let y = 0; y < height; y++){
     for(let x = 0; x < width; x++){
       clr = color(round(map(noiseMap[y][x], 0, 1, 0, 255)));
       greyscaleMap.push(clr);
     }
    }
    return greyscaleMap;
  }
}

class TerrainType{
  constructor(name, height, color){
   this.name = name;
    this.height = height; 
    this.clr = color;
  }
}