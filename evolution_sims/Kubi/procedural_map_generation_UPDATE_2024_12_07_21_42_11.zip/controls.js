function mousePressed() {
  if (mouseOnMap() && !dragging) {
    dragging = true;
    mouseXStart = mouseX;
    mouseYStart = mouseY;
  }

}

function mouseReleased() {
  dragging = false;
}