class Map {
  constructor(x, y, width, height) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.texture = createImage(this.width, this.height);
  }

  init() {
    this.noiseScale = editor.noiseScale;
    this.octaves = editor.octaves;
    this.persistance = editor.persistance;
    this.lacunarity = editor.lacunarity;
    this.scaleAdjustment = editor.scaleAdjustment;
    this.shift = editor.shift;

    this.data = generator.generateMap(this.width, this.height, this.noiseScale, this.octaves, this.persistance, this.lacunarity, this.scaleAdjustment, this.shift);
  }

  createTexture() {
    this.texture.loadPixels();
    let indPixels;
    let indData = 0;

    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        indPixels = (y * this.width + x) * 4;
        this.texture.pixels[indPixels + 0] = red(this.data[indData]);
        this.texture.pixels[indPixels + 1] = green(this.data[indData]);
        this.texture.pixels[indPixels + 2] = blue(this.data[indData]);
        this.texture.pixels[indPixels + 3] = 255;
        indData++;
      }
    }
    this.texture.updatePixels();
  }
}