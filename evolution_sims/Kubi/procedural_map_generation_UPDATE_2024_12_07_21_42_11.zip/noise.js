class Noise {

  static generateNoiseMap(mapWidth, mapHeight, scale, octaves, persistance, lacunarity, scaleAdjustment, shift) {
    let noiseMap = [];

    if (scale <= 0) scale = 0.0001;
    
    let halfWidth = mapWidth/2;
    let halfHeight = mapHeight/2;

    for (let y = 0; y < mapHeight; y++) {
      
      noiseMap[y] = [];
      
      for (let x = 0; x < mapWidth; x++) {

        let amplitude = 1;
        let frequency = 1;
        let noiseHeight = 0;
        
        for (let i = 0; i < octaves; i++) {
          let sampleX = (x-halfWidth) * scale * frequency + octaveOffsets[i].x-dX*frequency;
          let sampleY = (y-halfHeight) * scale * frequency + octaveOffsets[i].y-dY*frequency;
          
          let perlinValue = noise(sampleX, sampleY) * 2 - 1;
          
          noiseHeight += perlinValue * amplitude;
          
          amplitude *= persistance;
          frequency *= lacunarity;
        }
        
        noiseMap[y].push(noiseHeight);
        
      }
    }
    
    let max = 0;
    let amplitude = 1
    for (let i = 0; i < octaves; i++) {
      max += amplitude;
      amplitude *= persistance;
    }
    max*=scaleAdjustment
    
    for (let y = 0; y < mapHeight; y++) {
      for (let x = 0; x < mapWidth; x++) {
        noiseMap[y][x] += shift
        noiseMap[y][x] = map(noiseMap[y][x], -max, max, 0, 1);
        if(noiseMap[y][x] < 0) noiseMap[y][x] = 0
        if(noiseMap[y][x] > 1) noiseMap[y][x] = 1
      }
    }
    return noiseMap;
  }


}