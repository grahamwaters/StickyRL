class UI {
  init() {
    let y = 42
    let dy = 55
    this.sliderNoiseScale = createSlider(0, 0.03, 0.01, 0.001);
    this.sliderNoiseScale.position(380, y);
    y+=dy

    this.sliderOctaves = createSlider(1, 5, 4, 1);
    this.sliderOctaves.position(380, y);
    y+=dy

    this.sliderLacunarity = createSlider(1, 3, 2, 0.001);
    this.sliderLacunarity.position(380, y);
    y+=dy

    this.sliderPersistance = createSlider(0, 1, 0.5, 0.01);
    this.sliderPersistance.position(380, y);
    y+=dy
    
    this.sliderScaleAdjustment = createSlider(0, 1, 0.5, 0.01);
    this.sliderScaleAdjustment.position(380, y)
    y+=dy
    
    this.sliderShift = createSlider(-1, 1, 0, 0.05);
    this.sliderShift.position(380, y)

    this.sliderCrossSectionY = createSlider(0, mapWidth - 1, mapWidth / 2, 1);
    this.sliderCrossSectionY.style('transform', 'rotate(90deg)')
    this.sliderCrossSectionY.style('width', mapHeight + 10 + 'px');
    this.sliderCrossSectionY.position(170, 147);
    
    this.buttonNewTerrain = createButton('generate new map');
    this.buttonNewTerrain.style('width', '140px')
    this.buttonNewTerrain.position(380, 360);
    
    this.buttonMode = createButton('change map mode');
    this.buttonMode.style('width', '140px')
    this.buttonMode.position(380, 400);
  
  }

  static connect(ui, editor) {
    ui.sliderNoiseScale.input(function() { UI.updateParams(ui, editor);});
    ui.sliderOctaves.input(function() { UI.updateParams(ui, editor);});
    ui.sliderLacunarity.input(function() { UI.updateParams(ui, editor);});
    ui.sliderPersistance.input(function() { UI.updateParams(ui, editor);});
    ui.sliderScaleAdjustment.input(function() { UI.updateParams(ui, editor);});
    ui.sliderShift.input(function() { UI.updateParams(ui, editor);});
    ui.sliderCrossSectionY.input(function() { UI.listen(ui, editor);});
    
    ui.buttonNewTerrain.mousePressed(newTerrain);
    ui.buttonMode.mousePressed(changeMode);
  }
  
  static updateParams(ui, editor) {
    editor.noiseScale = 0.03-ui.sliderNoiseScale.value();
    editor.octaves = ui.sliderOctaves.value();
    editor.persistance = ui.sliderPersistance.value();
    editor.lacunarity = ui.sliderLacunarity.value();
    editor.scaleAdjustment = 1-ui.sliderScaleAdjustment.value();
    editor.shift = ui.sliderShift.value()

    world.init();
    world.createTexture();
  }

  static listen(ui, editor) {
    editor.crossSectionY = ui.sliderCrossSectionY.value();
  }

  displayText() {
    textSize(14);
    fill(255);
    noStroke();

    let y = 35
    let dy = 55
    text('zoom:', 380, y);
    y+=dy
    text('octaves:', 380, y);
    y+=dy
    text('frequency increase:', 380, y);
    y+=dy
    text('amplitude persistance:', 380, y);
    y+=dy
    text('constrast:', 380, y);
    y+=dy
    text('altitude shift:', 380, y)
  }
}

class MapEditor {
  constructor(ui) {
    this.ui = ui;
  }

  init() {
    this.noiseScale = 0.03-this.ui.sliderNoiseScale.value();
    this.octaves = this.ui.sliderOctaves.value();
    this.persistance = this.ui.sliderPersistance.value();
    this.lacunarity = this.ui.sliderLacunarity.value();
    this.crossSectionY = this.ui.sliderCrossSectionY.value();
    this.scaleAdjustment = 1-this.ui.sliderScaleAdjustment.value();
    this.shift = this.ui.sliderShift.value();
  }
}

function mouseClicked(){
   mouseXStart = mouseX;
  mouseYStart = mouseY;
}