class FoodManager {
  constructor(nFoods) {
    this.nInitialFoods = nFoods
    this.foods = []
    
    this.nRenderedFoods = 0 // for stats
    this.spawner = new Counter("descending", settings.food.spawnTime, 1, 0)
  }
  
  createInitialFoods() {
    for (let i = 0; i < this.nInitialFoods; i++) {
      this.foods.push(new Food())
    }
  }
  
  update(){
    for(let i = this.foods.length - 1; i >= 0; i--) {
      if(this.foods[i].eaten) {
        this.foods[i].die()
        this.foods.splice(i, 1)
      }
    }
    this.spawner.update()
    if(this.spawner.finished()) {
      this.foods.push(new Food(this.arena))
      this.spawner.reset()
    }
  }
  
  renderFood(){
    this.nRenderedFoods = 0
    for (let c of game.grid.cells) {
      if (cam.inView(c.centerLoc.x, c.centerLoc.y, c.size / 2)) {
        for (let f of c.foods) {
          if(cam.inView(f.loc.x, f.loc.y, f.dia / 2)){
            if(cam.view.zoom * f.dia > 1.8) {
              f.render()
              this.nRenderedFoods ++
            }
          }
        }
      }
    }
  }
}