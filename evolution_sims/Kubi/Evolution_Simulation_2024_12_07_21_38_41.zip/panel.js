class PanelBar {
  constructor(x, y, w, h){
    this.x = x
    this.y = y
    this.w = w
    this.h = h
    this.padding = 5
    this.layer = createGraphics(w, h)
    this.panels = []
    this.interactivePanels = []
    this.updatePanels = []
    this.wPanel = this.w - 2 * this.padding
    this.textElements = []
  }
  
  update() {
    for(let p of this.updatePanels){
      p.update()
    }
  }
  
  render(){
    this.layer.noStroke()
    this.layer.fill(settings.color.grey1.r)
    this.layer.rect(0, 0, this.w, this.h)
    image(this.layer, this.x, this.y)
  }
  
  renderTextElements(){
    for(let t of this.textElements) t.render()
  }
  
  renderPanels(){
    push()
    translate(this.x, this.y)
    for(let p of this.panels){
      p.render()
    }
    pop()
  }
  
  checkHover(){
    for(let p of this.interactivePanels){
      if(p.isHovered(this.x, this.y)){
      p.hoverAction(this.x, this.y)
    }
    }
  }
}

class PanelBar1 extends PanelBar {
  constructor(x, y, w, h){
    super(x, y, w, h)
    
    let yTemp = 6
    let xText = this.w / 2
    this.textElements.push(new TextElement(xText, yTemp, "MAIN STATS"))
    yTemp += 13
    this.mainPanel = new MainPanel(this.padding, yTemp, this.wPanel, 65)
    this.panels.push(this.mainPanel)
    
    yTemp += 65 + 2 * this.padding
    
    this.textElements.push(new TextElement(xText, yTemp, "SPECIES DISTRIBUTION"))
    yTemp += 13
    this.speciesPanel = new SpeciesPanel(this.padding, yTemp, this.wPanel, 150)
    this.panels.push(this.speciesPanel)
    yTemp += 150 + 2 * this.padding
    
    this.textElements.push(new TextElement(xText, yTemp, "MAP"))
    yTemp += 13
    let hMapPanel = this.wPanel / settings.cage.width * settings.cage.height
    this.mapPanel = new MapPanel(this.padding, yTemp, this.wPanel, hMapPanel)
    this.panels.push(this.mapPanel)
    yTemp += hMapPanel + 2 * this.padding
    
    
    
    this.textElements.push(new TextElement(xText, yTemp, "CONTROLS"))
    yTemp += 13
    this.buttonClimate = createButton('show / hide climate');
    this.buttonClimate.mousePressed(function() {
      showClimate = !showClimate
    })
    this.buttonClimate.position(this.padding, yTemp)
    this.buttonClimate.size(this.wPanel, settings.button.height)
    yTemp += settings.button.height + this.padding
    
    this.buttonTracking = createButton('toggle tracking');
    this.buttonTracking.mousePressed(function() {
      cam.tracking = !cam.tracking
    })
    this.buttonTracking.position(this.padding, yTemp)
    this.buttonTracking.size(this.wPanel, settings.button.height)
    yTemp += settings.button.height + this.padding
    
    this.buttonRandom = createButton('random creature');
    this.buttonRandom.mousePressed(function() {
    if (game.setCreatureFocus(floor(random(game.creatureManager.creatures.length)))) cam.tracking = true
  })
    this.buttonRandom.position(this.padding, yTemp)
    this.buttonRandom.size(this.wPanel, settings.button.height)
    yTemp += settings.button.height + this.padding
  
    /*this.buttonRelative = createButton('closest relative');
    this.buttonRelative.mousePressed(function() {
    let newFocusedCreature = game.creatureManager.findClosestRelative(game.focusedCreature)
    game.focusCreature(newFocusedCreature)
    cam.tracking = true
  })
    this.buttonRelative.position(this.padding, yTemp)
    this.buttonRelative.size(this.wPanel, settings.button.height)
    yTemp += settings.button.height + this.padding*/
    
    this.buttonNextInSpecies = createButton('next in species');
    this.buttonNextInSpecies.mousePressed(function() {
      let speciesPopulation = game.speciesManager.species.get(game.focusedCreature.species)
      let ind = speciesPopulation.indexOf(game.focusedCreature)
      ind ++
      if(ind >= speciesPopulation.length) ind = 0  
      let newFocusedCreature = speciesPopulation[ind]
      game.focusCreature(newFocusedCreature)
      cam.tracking = true
    })
    this.buttonNextInSpecies.position(this.padding, yTemp)
    this.buttonNextInSpecies.size(this.wPanel, settings.button.height)
    yTemp += settings.button.height + this.padding
    
    
    yTemp += 10
    
  }
}

class PanelBar2 extends PanelBar {
  constructor(x, y, w, h){
    super(x, y, w, h)
    
    let yTemp = 6
    let xText = this.x + this.w / 2
    
    this.textElements.push(new TextElement(xText, yTemp, "CREATURE STATS"))
    yTemp += 13
    this.creatureInfoPanel = new CreatureInfoPanel(this.padding, yTemp, this.wPanel, 95)
    this.panels.push(this.creatureInfoPanel)
    yTemp += 95 + 2 * this.padding
    
    this.textElements.push(new TextElement(xText, yTemp, "CREATURE TRAITS"))
    yTemp += 13
    this.traitsPanel = new TraitsPanel(this.padding, yTemp, this.wPanel, 95)
    this.panels.push(this.traitsPanel)
    yTemp += 95 + 2 * this.padding
    
    this.textElements.push(new TextElement(xText, yTemp, "BRAIN"))
    yTemp += 13
    this.brainPanel = new BrainPanel(this.padding, yTemp, this.wPanel, 150)
    this.panels.push(this.brainPanel)
    this.interactivePanels.push(this.brainPanel)
    this.updatePanels.push(this.brainPanel)
    yTemp += 150 + 2 * this.padding
    
    this.textElements.push(new TextElement(xText, yTemp, "ENERGY & LOAD"))
    yTemp += 13
    this.energyPanel = new EnergyPanel(this.padding, yTemp, this.wPanel, 15)
    this.panels.push(this.energyPanel)
    yTemp += 15 + 3
    
    this.loadPanel = new LoadPanel(this.padding, yTemp, this.wPanel, 100)
    this.panels.push(this.loadPanel)
    }
}

class Panel {
  constructor(x, y, w, h) {
    this.x = x
    this.y = y
    this.w = w
    this.h = h

    this.layer = createGraphics(this.w, this.h)
  }
  

  isHovered(offsetX, offsetY) {
    let xOverlap = mouseX > this.x + offsetX && mouseX < this.x + offsetX + this.w ? true : false
    let yOverlap = mouseY > this.y + offsetY && mouseY < this.y + offsetY + this.h ? true : false
    
    
    return xOverlap && yOverlap
  }

  render() {
    image(this.layer, this.x, this.y)
  }
  
  defaultBg(){
    this.layer.fill(settings.color.grey2.r)
    this.layer.noStroke()
    this.layer.rect(0, 0, this.w, this.h)
  }

  defaultFrame() {
    this.layer.noFill()
    this.layer.stroke(255)
    this.layer.strokeWeight(1)

    this.layer.rect(1, 1, this.w - 2, this.h - 2)
  }

  defaultText() {
    this.layer.noStroke()
    this.layer.fill(255)
    this.layer.textSize(12)
    this.layer.textAlign(LEFT, TOP)
  }

  titleText(x, y) {
    this.layer.noStroke()
    this.layer.fill(255)
    this.layer.textSize(14)
    this.layer.textAlign(CENTER, TOP)
    this.layer.text(this.title, x, y)
  }
}

class TextElement {
 constructor(x, y, str){
   this.str = str
   this.x = x
   this.y = y
 }
  render(){
    textAlign(CENTER, TOP)
    textSize(12)
    fill(255)
    noStroke()
    text(this.str, this.x, this.y)
  }
}

class TimePanel {    
  constructor(x, y, w, h, hBox){
    this.x = x
    this.y = y
    this.w = w
    this.h = h
    this.hBox = h
     
    this.dia = h
    this.hBox = hBox
    this.yBox = (this.h - this.hBox) / 2
    
    this.buttonPause = createButton('pause / resume');
    this.buttonPause.position(this.x + 8, this.y + this.yBox + 8)
    this.buttonPause.size(this.wPanel, settings.button.height)
    this.buttonPause.mousePressed(function() {
      if(focused) paused = !paused
  })
    
    this.sliderSimSpeed = new Slider(1, 20, 1, 1)
    this.sliderSimSpeed.position(x + this.w - 108, this.y + this.h / 2 + 8, 98)
    
    this.layer = createGraphics(this.w, this.h)
  }
  
  isHovered() {
    let xOverlap = mouseX > this.x && mouseX < this.x + this.w ? true : false
    let yOverlap = mouseY > this.y + this.yBox && mouseY < this.y + this.yBox + this.hBox ? true : false

    return (xOverlap && yOverlap)
  }
  
  render() {
    this.renderBox()
    this.renderClock()
    this.sliderSimSpeed.render()
  }
  
  renderBox(){
    this.layer.fill(settings.color.grey2.r)
    this.layer.noStroke()
    this.layer.rect(0, this.yBox, this.w, this.hBox)
    
    // frame
    this.layer.noFill()
    this.layer.stroke(255)
    this.layer.strokeWeight(1)
    this.layer.rect(1, this.yBox + 1, this.w - 2, this.hBox - 2)
    
    this.layer.noStroke()
    this.layer.fill(255)
    this.layer.textSize(12)
    this.layer.textAlign(LEFT, TOP)
    
    this.layer.text("sim speed: x", this.w - 100, 22)
    this.layer.text(this.sliderSimSpeed.value, this.w - 30, 22)
  }
  
  checkHover(){
   this.sliderSimSpeed.mouseHovered() 
  }
  
  renderClock(){
    // background
    this.layer.noStroke()
    this.layer.fill(settings.color.grey1.r)
    this.layer.circle(this.w / 2, this.h / 2, this.dia)
    
    // arc
    let ang = map(game.year.value, 0, 1, 0, TWO_PI) - HALF_PI
    this.layer.noStroke()
    let b = map(game.year.value, 0, 1, 70, 120)
    let g = map(game.year.value, 0, 1, 40, 60)
    let r = map(game.year.value, 0, 1, 40, 60)
    this.layer.fill(r, g, b)
    this.layer.arc(this.w / 2, this.h / 2, this.dia, this.dia, -HALF_PI, ang)
    
    // outer border
     this.layer.stroke(255)
    this.layer.strokeWeight(1)
    this.layer.noFill()
    this.layer.circle(this.w / 2, this.h / 2, this.dia - 2)
    
    // inner circle / text background
    this.layer.noStroke()
    this.layer.fill(settings.color.grey2.r)
    this.layer.circle(this.w / 2, this.h / 2, this.dia - 15)
    
    // text 
    this.layer.noStroke()
    this.layer.fill(255)
    this.layer.textAlign(CENTER, CENTER)
    let year = floor(game.time.value)
    
    if (year < 100) {
      this.layer.textSize(26)
    }
    else if (year >= 100 && year < 1000) {
      this.layer.textSize(22)
    }
    else {
     this.layer.textSize(19) 
    }
    
    this.layer.text(floor(game.time.value), this.w / 2, this.h / 2 -5)
    
    this.layer.noStroke()
    this.layer.fill(255)
    this.layer.textSize(12)
    this.layer.textAlign(CENTER, TOP)
    this.layer.text("year", this.w / 2, this.h / 2 + 9)
    
    image(this.layer, this.x, this.y)
  }
}

class SpeciesPanel extends Panel {
  constructor(x, y, w, h, title) {
    super(x, y, w, h, title)

    this.colors = []
    this.values = []

    this.resolution = 2
    this.hAvailable = h - 2
    let wAvailable = w - 2
    this.maxYearsDisplayed = wAvailable / this.resolution
  }
  update(data) {
    let colors = []
    let values = []

    // avg color, ratio
    for (let [speciesId, creatures] of data.entries()) {
      let nCreatures = creatures.length

      if (nCreatures > 0) {
        values.push(nCreatures / game.creatureManager.creatures.length)

        let r = 0
        let g = 0
        let b = 0

        for (let c of creatures) {
          r += c.traits.color.red
          g += c.traits.color.green
          b += c.traits.color.blue
        }

        colors.push([r / nCreatures, g / nCreatures, b / nCreatures])
      }
    }

    this.colors.push(colors)
    this.values.push(values)

    if (this.values.length > this.maxYearsDisplayed) {
      this.values.splice(0, 1)
      this.colors.splice(0, 1)
    }

    this.updateLayer()
  }

  updateLayer() {
    this.defaultBg()

    let w = this.resolution
    let x = 1
    this.layer.noStroke()

    // go through years
    for (let year = 0; year < this.values.length; year++) {

      let y = 1

      // go through values per year
      for (let i = 0; i < this.values[year].length; i++) {
        let h = this.values[year][i] * this.hAvailable

        let r = this.colors[year][i][0]
        let g = this.colors[year][i][1]
        let b = this.colors[year][i][2]

        this.layer.fill(r, g, b)
        this.layer.rect(x, y, w, h)

        y += h
      }
      x += w
    }
    this.defaultFrame()
  }

  render() {

    image(this.layer, this.x, this.y)


  }
}

class MapPanel extends Panel {
  constructor(x, y, w, h) {
    super(x, y, w, h)
    
    this.dragging = false
    this.prevX = null
    this.prevY = null
  }
  
  mousePressed(offsetX, offsetY) {
    cam.tracking = false
    this.dragging = true
    this.prevX = mouseX - offsetX - this.x
    this.prevY = mouseY - offsetY - this.y
    
    let x = mouseX - offsetX - this.x
    let y = mouseY - offsetY - this.y
    
    let xWorld = map(x, 0, this.w, -settings.cage.width/2, settings.cage.width/2)
    let yWorld = map(y, 0, this.h, -settings.cage.height/2, settings.cage.height/2)
    
    cam.setView(xWorld, yWorld)
  }
  mouseDragged(offsetX, offsetY){
    if(!this.dragging) return

    let x = mouseX - offsetX - this.x
    let y = mouseY - offsetY - this.y
    
    let dx = x - this.prevX
    let dy = y - this.prevY
    
    let dxWorld = map(dx, 0, this.w, 0, settings.cage.width)
    let dyWorld = map(dy, 0, this.h, 0, settings.cage.height)
    
    cam.setView(cam.view.x + dxWorld, cam.view.y + dyWorld)
    
    this.prevX = x
    this.prevY = y
  }
  mouseReleased(){
    this.dragging = false
  }
  render() {
    this.defaultBg()

    let wAvailable = this.w - 2
    let hAvailable = this.h - 2
    
    let wCage = game.cage.w
    let hCage = game.cage.h

    this.layer.strokeWeight(5)

    for (let c of game.creatureManager.creatures) {
      let x = 1 + (c.loc.x + wCage / 2) / wCage * wAvailable
      let y = 1 + (c.loc.y + hCage / 2) / hCage * hAvailable

      this.layer.stroke(c.traits.color.red, c.traits.color.green, c.traits.color.blue)
      this.layer.point(x, y)
    }
    
    
    
    let x1 = (cam.view.xMin + wCage / 2) / wCage * this.w
    let x2 = (cam.view.xMax + wCage / 2) / wCage * this.w
    let y1 = (cam.view.yMin + hCage / 2) / hCage * this.h
    let y2 = (cam.view.yMax + hCage / 2) / hCage * this.h
    
    let w = x2 - x1
    let h = y2 - y1

    this.layer.strokeWeight(2)
    this.layer.stroke(255, 0, 0)
    this.layer.noFill()
    this.layer.rect(x1, y1, w, h)
    
    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class TilemapPanel extends Panel {
  render(){
    this.defaultBg()
    
    /*
    let max = 0
    for(let y = 0; y < gameManager.grid.nCellsY; y++){
      for(let x = 0; x < gameManager.grid.nCellsX; x++){
        let cellId = y * gameManager.grid.nCellsX + x
        if(gameManager.grid.cells[cellId].creatures.length > max){
          max = gameManager.grid.cells[cellId].creatures.length
        }
          
      }
    }*/

    let w = (this.w - 2) / game.grid.nCellsX
    let h = (this.h - 2) / game.grid.nCellsY
    
    let r, g, b, count
    
    for(let y = 0; y < game.grid.nCellsY; y++){
      for(let x = 0; x < game.grid.nCellsX; x++){
        let cellId = y * game.grid.nCellsX + x
        
        r = 0
        g = 0
        b = 0
        count = 0
        
        if(game.grid.cells[cellId].creatures.length > 0){
          for(let c of game.grid.cells[cellId].creatures) {
            r += c.traits.color.red
            g += c.traits.color.green
            b += c.traits.color.blue
            count ++
          }

          this.layer.fill(r / count, g / count, b / count)
        }
        else this.layer.noFill()
        
        this.layer.noStroke()
        this.layer.rect(1 + x * w, 1 + y * h, w, h)  
      }
    }
    let wCage = game.cage.w
    let hCage = game.cage.h
    
    let x1 = (cam.view.xMin + wCage / 2) / wCage * this.w
    let x2 = (cam.view.xMax + wCage / 2) / wCage * this.w
    let y1 = (cam.view.yMin + hCage / 2) / hCage * this.h
    let y2 = (cam.view.yMax + hCage / 2) / hCage * this.h
    
    let wView = x2 - x1
    let hView = y2 - y1

    this.layer.strokeWeight(2)
    this.layer.stroke(255, 0, 0)
    this.layer.noFill()
    this.layer.rect(x1, y1, wView, hView)
    
    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
  
  hoverAction() {
    let worldX = ((mouseX - (this.x + 1)) / (this.w - 2)) * game.cage.w - game.cage.w / 2
    let worldY = ((mouseY - (this.y + 1)) / (this.h - 2)) * game.cage.h - game.cage.h / 2

    // finish
  }
}

class BrainPanel extends Panel {
  render() {
    this.defaultBg()

    this.brain = game.focusedCreature.brain

    this.layer = this.brain.render(this.layer)

    this.defaultFrame()
    image(this.layer, this.x, this.y)

    if (this.tempPanel) this.tempPanel.render()
  }

  update() {
    this.tempPanel = undefined
  }

  hoverAction(offsetX, offsetY) {
    for (let n of this.brain.nodes.values()) {
      if (n.checkHover(mouseX - this.x - offsetX, mouseY - this.y - offsetY)) {

        let w1 = 200
        let w2 = 220
        let w3 = 130

        let h1 = 35
        let h2 = h1
        let h3 = h1

        let x1 = this.x + n.renderLoc.x - w1 - 15
        let x2 = this.x + n.renderLoc.x - w2 - 15
        let x3 = this.x + n.renderLoc.x - w3 - 15

        let y1 = this.y + n.renderLoc.y - h1 / 2
        let y2 = this.y + n.renderLoc.y - h2 / 2
        let y3 = y1
        if (n.type == "input") {
          this.tempPanel = new TempBrainPanel(x1, y1, w1, h1)
          this.tempPanel.txt1 = "SENSOR NODE"
          this.tempPanel.txt2 = n.label + ": " + (round(n.output * 100) / 100)
        } else if (n.type == "hidden") {
          this.tempPanel = new TempBrainPanel(x2, y2, w2, h2)
          this.tempPanel.txt1 = "HIDDEN NODE"
          this.tempPanel.txt2 = "activation function: " + n.activation
        }
        if (n.type == "output") {
          this.tempPanel = new TempBrainPanel(x3, y3, w3, h3)
          this.tempPanel.txt1 = "OUTPUT NODE"
          this.tempPanel.txt2 = n.label + ": " + (round(n.output * 100) / 100)
        }
      }
    }
  }

}

class TempBrainPanel extends Panel {
  render() {
    this.defaultBg()
    this.defaultText()
    this.layer.text(this.txt1, 5, 5)
    if (this.txt2) this.layer.text(this.txt2, 5, 20)
    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class MainPanel extends Panel {
  render() {
    this.defaultBg()
    this.defaultText()
    
    let y = 5
    let dy = 15

    

    let str = "Creatures: " + game.creatureManager.creatures.length
    this.layer.text(str, 5, y)
    y += dy
    
    str = "Species: " + game.speciesManager.nSpeciesAlive
    this.layer.text(str, 5, y)
    y += dy
    
    str = "Eggs: " + game.eggManager.eggs.length
    this.layer.text(str, 5, y)
    y += dy

    str = "Foods: " + game.foodManager.foods.length
    this.layer.text(str, 5, y)

    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class EnergyPanel extends Panel {
  render() {
    let c = game.focusedCreature
    this.defaultBg()
    
    this.layer.noStroke();
    if (c.energy.value >= c.energy.defaultValue * 0.5) this.layer.fill(30, 200, 0)
    else if (c.energy.value < c.energy.defaultValue * 0.5 && c.energy.value >= c.energy.defaultValue * 0.2) this.layer.fill(200, 200, 0)
    else this.layer.fill(255, 0, 0)

    let maxW = this.w - 2;
    let w = map(c.energy.value, c.energy.defaultValue, c.energy.threshold, maxW, 0)
    if (w < 0) w = 0
    this.layer.rect(1, 1, w, this.h - 2)

    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class LoadPanel extends Panel {
  render() {
    let creature = game.focusedCreature
    this.defaultBg()
    
    
    let x1 = this.w / 6
    let x2 = this.w / 2
    let x3 = this.w / 6 * 5
    
    let y1 = 16
    let y3 = this.h - 15
    let y2 = y3 - 15
    let y4 = this.h - 3
    
    // values as text
    this.defaultText()
    this.layer.textAlign(CENTER, BOTTOM)
    this.layer.text(round(creature.baseLoad * 100) / 100, x1, y1)
    this.layer.text(round(creature.variableLoad * 100) / 100, x2, y1)
    this.layer.text(round(creature.temperatureLoad * 100) / 100, x3, y1)
    
    // values as bar
    let maxH = y2 - y1 - 1
    let w = 20
    let maxValue = 1
    
    this.layer.noStroke()
    this.layer.fill(settings.color.blue2.r, settings.color.blue2.g, settings.color.blue2.b)
    let hBaseLoad = map(creature.baseLoad, 0, maxValue, 0, maxH)
    if(hBaseLoad > maxH) {
      this.layer.fill(255, 0, 0)
      hBaseLoad = maxH
    }
    this.layer.rect(x1 - w / 2, y2, w, -hBaseLoad)
    
    this.layer.fill(settings.color.blue2.r, settings.color.blue2.g, settings.color.blue2.b)
    let hVarLoad = map(creature.variableLoad, 0, maxValue, 0, maxH)
    if(hVarLoad > maxH) {
      this.layer.fill(255, 0, 0)
      hVarLoad = maxH
    }
    this.layer.rect(x2 - w / 2, y2, w, -hVarLoad)
    
    this.layer.fill(settings.color.blue2.r, settings.color.blue2.g, settings.color.blue2.b)
    let hClimatePenalty = map(creature.temperatureLoad, 0, maxValue, 0, maxH)
    if(hClimatePenalty > maxH) {
      let g = sin(game.time.value * 100) * 30 + 30
      let b = g
      this.layer.fill(255, g, b)
      hClimatePenalty = maxH
    }
    this.layer.rect(x3 - w / 2, y2, w + 2, -hClimatePenalty)
    
    // horizontal line
    this.layer.stroke(255)
    this.layer.strokeWeight(1)
    
    this.layer.line(10, y2, this.w - 10, y2)
    
    // description text
    this.defaultText()
    this.layer.textAlign(CENTER, BOTTOM)
    this.layer.text("base", x1, y3)
    this.layer.text("load", x1, y4)
    
    this.layer.text("variable", x2, y3)
    this.layer.text("load", x2, y4)
    
    this.layer.text("climate", x3, y3)
    this.layer.text("penalty", x3, y4)

    this.defaultFrame()
    
    image(this.layer, this.x, this.y)
  }
}

class TraitsPanel extends Panel {
  render() {
    let creature = game.focusedCreature
    this.defaultBg()
    
    this.defaultText()

    let y = 5
    let dy = 15

    let str = "Size: " + round(creature.traits.size)
    this.layer.text(str, 5, y)
    y += dy
    
    str = "Max speed: " + round(creature.traits.maxSpeed * 100) / 100
    this.layer.text(str, 5, y)
    y += dy

    str = "Agility: " + round(creature.traits.agility * 100) / 100
    this.layer.text(str, 5, y)
    y += dy
    
    

    str = "Vision range: " + round(creature.traits.visionRange)
    this.layer.text(str, 5, y)
    y += dy

    str = "Vision angle: " + (round(creature.traits.visionAngle * 100) / 100)
    this.layer.text(str, 5, y)
    y += dy

    str = "Comfort climate: " + round(creature.traits.comfortTemperature * 100) / 100
    this.layer.text(str, 5, y)
    y += dy

    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class CreatureInfoPanel extends Panel {
  render() {
    let creature = game.focusedCreature
    this.defaultBg()
    
    this.defaultText()

    let y = 5
    let dy = 15

    let str = "ID: " + creature.id
    this.layer.text(str, 5, y)
    y += dy
    
    str = "Generation: " + creature.generation
    this.layer.text(str, 5, y)
    y += dy

    str = "Age: " + round(creature.age.value)
    this.layer.text(str, 5, y)
    y += dy

    str = "Offspring: " + creature.stats.offspring
    this.layer.text(str, 5, y)
    y += dy
    
    str = "Species ID: " + creature.species
    this.layer.text(str, 5, y)
    y += dy

    str = "Species size: " + game.speciesManager.species.get(creature.species).length
    this.layer.text(str, 5, y)
    y += dy

    this.defaultFrame()
    image(this.layer, this.x, this.y)
  }
}

class CameraPanel extends Panel {
  render() {

    this.defaultFrame()
    this.defaultText()

    
    let y = 5
    let dy = 15
    
    let str = "world center: " + round(cam.world.x) + ", " + round(cam.world.y)
  this.layer.text(str, 5, y)
    y += dy

    str = "Cam position: " + round(cam.view.x) + " | " + round(cam.view.y)
    this.layer.text(str, 5, y)
    y += dy

    str = "Zoom: " + cam.view.zoom
    this.layer.text(str, 5, y)
    y += dy

    str = "Rendered creatures: " + game.creatureManager.nRenderedCreatures
    this.layer.text(str, 5, y)
    y += dy

    str = "Rendered foods: " + game.foodManager.nRenderedFoods
    this.layer.text(str, 5, y)
    y += dy

    image(this.layer, this.x, this.y)
  }
}