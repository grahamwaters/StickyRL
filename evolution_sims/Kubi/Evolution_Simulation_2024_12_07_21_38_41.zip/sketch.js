// maybe: scrolling when hovering on map

// input: hearing (distance to creature left / right)
// mutation: change activation?
// mutation: set bias to 0 (or disable?) -> adjust calculations
// (make generic function for food and creature detection)
// calculation of creature similarity also based on traits (and activation function, if they can mutate)
// (input: smelling (distance to food left / right))
// (input: wall detection in front)


paused = false
showClimate = false

function setup() {
  canvas = createCanvas(settings.window.width, settings.window.height)

  cam = new Cam(settings.panel.bar.width, 0, width - 2 * settings.panel.bar.width, height, 0.5, 0.5)
  //canvas.mouseWheel(e => cam.zoom(e))
  /*canvas.mouseWheel(function(e){
    cam.zoom(e)
    return false
  })*/

  //cam.tracking = true

  game = new Game()


  game.init()

  framerateTracker = new FramerateTracker(width - settings.panel.bar.width - 5, 5, "white", frameRate())
  game.update()
}

function draw() {
  if (focused) {
    if (!paused) {
      for (let i = 0; i < game.panelManager.timePanel.sliderSimSpeed.value; i++) {
        game.update()
      }
    }
  }

  if (cam.tracking == true) {
    cam.setView(game.focusedCreature.loc.x, game.focusedCreature.loc.y)
  }

  background(20)
  game.updateAlways()
  game.renderAllObjects()

  framerateTracker.update(frameRate())
  framerateTracker.render()

  if (!focused) displayClickRequest();
}