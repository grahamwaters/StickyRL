function mousePressed(e) {
  if(mouseX <= settings.panel.bar.width){
    if(game.panelManager.panelBar1.mapPanel.isHovered(game.panelManager.panelBar1.x, game.panelManager.panelBar1.y)){
       game.panelManager.panelBar1.mapPanel.mousePressed(game.panelManager.panelBar1.x, game.panelManager.panelBar1.y)
    }
  }
  else if (mouseX > settings.panel.bar.width && mouseX < width - settings.panel.bar.width) {
    if(!game.panelManager.timePanel.isHovered()){
      cam.mousePressed(e)
    }
    else {
      game.panelManager.timePanel.sliderSimSpeed.mousePressed()
    }
  }
}

function mouseDragged(e) {
  cam.mouseDragged(e)
  game.panelManager.panelBar1.mapPanel.mouseDragged(game.panelManager.panelBar1.x, game.panelManager.panelBar1.y)
  game.panelManager.timePanel.sliderSimSpeed.mouseDragged()
}

function mouseReleased(e) {
  cam.mouseReleased(e)
  game.panelManager.panelBar1.mapPanel.mouseReleased()
  game.panelManager.timePanel.sliderSimSpeed.mouseReleased()
}

function mouseClicked(){

    if(game.setCreatureFocus(-1)) cam.tracking = true
  
}

function mouseWheel(e){
    cam.zoom(e)
    return false
  }

function keyPressed() {
  if (key == "p") {paused = !paused}
  
  if (key == "r") {
    if(game.setCreatureFocus(floor(random(game.creatureManager.creatures.length)))) cam.tracking = true
  }
  
  if (key == "a") {game.focusedCreature.attack()}
  
  if (key == "y") {print(game.speciesManager.species)}
}

/*function windowResized() {
  let availableWidth = window.innerWidth
  let availableHeight = window.innerHeight
  
  let w = clamp(availableWidth, settings.window.minWidth, settings.window.maxWidth)
  let h = clamp(availableHeight, settings.window.minHeight, settings.window.maxHeight)
  
  resizeCanvas(w, h);
  print(width)
}*/