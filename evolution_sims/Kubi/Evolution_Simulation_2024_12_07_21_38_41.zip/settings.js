settings = {
  general: {
    timePerFrame: 0.005,
  },
  
  button: {
    height: 24
  },

  color: {
    grey1: {    // panel bar
      r: 15,
      g: 15,
      b: 15
    },
    grey2: {     // sub panels
      r: 8,
      g: 8,
      b: 8
    },
    blue1: {      // button default
      r: 40,
      g: 40,
      b: 70
    },
    blue2: {      // button highlight
      r: 60,
      g: 60,
      b: 120
    },
    blue3: {      // slider highlight
      r: 130,
      g: 130,
      b: 255
    },
    red: {        // hover highlight

    }
  },

  window: {
    width: 1000,
    height: 550,
  },


  population: {
    initialSize: 150
  },

  cage: {
    width: 5000,
    height: 4000
  },

  creature: {
    general: {
      maxAge: 50,
    },

    reproduction: {
      breedingTime: 1000
    },

    attack: {
      chargeTime: 210,
      displayTime: 15,

      force: {
        minTotal: 120,
        maxTotal: 250
      }
    },

    size: {
      minInitial: 20,
      maxInitial: 50,

      minTotal: 10,
      maxTotal: 60,

      maxMutation: 0.8
    },

    hearing: {
      range: {
        minInitial: 70,
        maxInitial: 330,

        minTotal: 20,
        maxTotal: 380,

        maxMutation: 2
      }
    },

    vision: {
      angle: {
        minInitial: 0.6,
        maxInitial: 2.3,

        minTotal: 0.1,
        maxTotal: 2.8,

        maxMutation: 0.02
      },

      range: {
        minInitial: 70,
        maxInitial: 330,

        minTotal: 20,
        maxTotal: 380,

        maxMutation: 2
      }
    },

    speed: {
      minInitial: 1,
      maxInitial: 2,

      minTotal: 0.5,
      maxTotal: 2.5,

      maxMutation: 0.05
    },

    agility: {
      minInitial: 0.05,
      maxInitial: 0.15,

      minTotal: 0.01,
      maxTotal: 0.19,

      maxMutation: 0.02
    },

    color: {
      maxMutation: 5
    },

    comfortTemperature: {
      maxTotal: 1,
      minTotal: 0,

      maxMutation: 0.03
    },

    energy: {
      cost: {
        baseLoad: {
          sizeFactor: 0.007,
          visionRangeFactor: 0.00045,
          visionAngleFactor: 0.07,
          temperatureFactor: 2.2,
          hearingRangeFactor: 0.0003
        },
        variable: {
          speedFactor: 0.1,
          agilityFactor: 0.95
        }
      }
    }
  },

  food: {
    initialAmount: 1000,
    spawnTime: 5,

    dia: {
      min: 2,
      max: 8
    },

    value: {
      min: 300,
      max: 600
    }
  },

  egg: {
    hatchTime: 300,
    dia: 7,
  },

  panel: {
    bar: {
      width: 150
    },
  }
}