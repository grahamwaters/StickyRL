class Neat {
  constructor(nInputs, nOutputs, labels) {
    this.nInputs = nInputs
    this.nOutputs = nOutputs
    
    this.innovationTracker = new InnovationTracker()
    this.innovationTracker.createDefaultConnections(nInputs, nOutputs)
    this.innovationTracker.increaseInnoNumberBy(nInputs + nOutputs)
    
    this.mutationController = new MutationController(this.innovationTracker)
    
    this.labels = labels
    
    this.params = {
      c1: 1,
      c2: 1,
      c3: 0.5,
      c4: 0.5
    }
    
    this.activationFunctions = ["sigmoid", "modifiedSigmoid", "reLU", "absolute", "gaussian", "hyperbolicTangent"]
  }
  
  calcDistance(genome1, genome2) {
    // both genomes have no connections
    if (genome1.connections.size == 0 && genome2.connections.size == 0) return 0

    // find out max connection IDs of the two genomes
    let maxConID1 = max(Array.from(genome1.connections.keys()))
    let maxConID2 = max(Array.from(genome2.connections.keys()))

    // genome1 must be the one with the highest connection ID; if not the case, swap!
    if (maxConID1 < maxConID2) {

      // swap genomes
      let tempGenome = genome1
      genome1 = genome2
      genome2 = tempGenome

      // swap max connection IDs
      let tempConID = maxConID1
      maxConID1 = maxConID2
      maxConID2 = tempConID
    }

    let nMatching = 0
    let nExcess = 0
    let nDisjoint = 0
    let weightDiff = 0

    let checkedIDs = []

    // go through connections of genome 1 and compare them to genome 2
    for (let c of genome1.connections.values()) {
      let id = c.id

      // matching gene
      if (genome2.connections.has(id)) {
        nMatching++
        weightDiff += abs(c.weight - genome2.connections.get(id).weight)
      }

      // disjoint or excess gene
      else {
        // excess gene
        if (id > maxConID2) {
          nExcess++
        }
        // disjoint gene
        else {
          nDisjoint++
        }
      }
      checkedIDs.push(id)
    }

    // go through connections of genome 2 and find connections that are not included in genome 1
    for (let c of genome2.connections.values()) {
      if (!checkedIDs.includes(c.id)) {
        nDisjoint++
      }
    }

    // go through nodes of genome1
    let matchingNodes = 0
    let biasDiff = 0
    for (let n of genome1.nodes.values()) {
      if (n.type != "input") {
        let nodeID = n.id
        if (genome2.nodes.has(nodeID)) {
          biasDiff += abs(n.bias - genome2.nodes.get(nodeID).bias)
          matchingNodes++
        }
      }
    }

    if (nMatching > 0) { // otherwise division by zero!
      weightDiff /= nMatching
    } else weightDiff = 0

    if (matchingNodes > 0) { // otherwise division by zero!
      biasDiff /= matchingNodes
    } else biasDiff = 0

    let n = max(genome1.connections.size, genome2.connections.size)
    if (n < 20) n = 1

    // formula see neat paper
    let dist = (nExcess * this.params.c1) / n + (nDisjoint * this.params.c2) / n + weightDiff * this.params.c3 + biasDiff * this.params.c4

    return dist
  }

  
  createGenome(id){
    let genome = new Genome(this.nInputs, this.nOutputs, id)
    genome.createInitialNodes(this.labels)
    genome.createRandomConnections(this.innovationTracker, 0.33)
    return genome
  }
  
  createNextGeneration(){
    this.genomes = this.evolutionController.evolve(this.genomes)
  }
      
  processInput(indGenome, inputs){
    let result = this.genomes[indGenome].process(inputs)
    return result
  }
  
  wire(genome, inNodeID, outNodeID){
    genome.addConnectionMutation(inNodeID, outNodeID, this.innovationTracker)
  }
  
  setupRendering(indGenome, x, y, w, h){
    this.genomes[indGenome].setupRendering(x, y, w, h)
  }
    
  calcRenderLocs(indGenome){
    this.genomes[indGenome].calcRenderLocs()
  }
  
  render(indGenome){
    this.genomes[indGenome].render()
  }
}



// new innovation number for every global new node
class InnovationTracker {
  constructor() {
    this.innoNumber = 1 // gets increased only when a new node is created

    this.globalConnections = []
  }

  createDefaultConnections(nInputs, nOutputs) {
    let index = 1

    for (let i = 1; i <= nInputs; i++) {
      for (let j = nInputs + 1; j <= nInputs + nOutputs; j++) {
        this.globalConnections.push([index, i, j])
        index++
      }
    }
  }
  
  addConnection(inNodeID, outNodeID) {
    let newConnectionID = this.globalConnections.length + 1
    this.globalConnections.push([newConnectionID, inNodeID, outNodeID])
  }

  getConnectionID(inNodeID, outNodeID) {
    for (let i = 0; i < this.globalConnections.length; i++) {
      if (inNodeID == this.globalConnections[i][1]) {
        if (outNodeID == this.globalConnections[i][2]) {
          return this.globalConnections[i][0]
        }
      }
    }
    return -1
  }
  
  getNextConnectionID(){
    return this.globalConnections.length + 1
  }

  incrementInnoNumber() {
    this.innoNumber++
  }

  increaseInnoNumberBy(value) {
    this.innoNumber += value
  }
}
  
class MutationController {
  constructor(innovationTracker){
    this.innovationTracker = innovationTracker
    
    this.nTries = 50
    
    this.probabilities = {
      addNode: 0.04,
      addConnection: 0.08,
      toggleConnection: 0.08,
      changeWeights: 0.85,
      shiftWeight: 0.95,  // "randomize weight" is inverse value
      changeBiases: 0.85,
      shiftBias: 0.95      // "randomize bias" is inverse value
    }
  }
  
  mutate(genome){
    let rand = random()

    if(rand < this.probabilities.addNode) this.addNodeMutation(genome)
    if(rand < this.probabilities.addConnection) this.addConnectionMutation(genome)
    if(rand < this.probabilities.toggleConnection) this.toggleConnectionMutation(genome)
    if(rand < this.probabilities.changeWeights) this.changeWeightsMutation(genome)
    if(rand < this.probabilities.changeBiases) this.changeBiasesMutation(genome)
  }
  
  addNodeMutation(genome){
    let nTries = this.nTries
    
    // create an array containing all IDs of the genome's connections
    let conIDs = Array.from(genome.connections.keys())
    
    while(nTries > 0) {
      // picks a random connection ID 
      let randConID = getRandValue(conIDs)
      
      // remove connection ID from (temporary) ID array so it doesn't get picked twice
      conIDs.splice(findIndex(conIDs, randConID), 1)

      // "add Node" mutation on connection with chosen ID
      if(genome.addNodeMutation(randConID, this.innovationTracker)) {
        return
      } else {
        nTries--
      }
    }
  }
    
  addConnectionMutation(genome){
    let nTries = this.nTries
    
    let nodeIDs = Array.from(genome.nodes.keys())
        
    while(nTries > 0) {
      // pick random node IDs
      let randNodeID1 = getRandValue(nodeIDs)
      let randNodeID2 = getRandValue(nodeIDs)

      // connect chosen nodes
      if(genome.addConnectionMutation(randNodeID1, randNodeID2, this.innovationTracker)) {
        return
      } else {
        nTries--
      }
    }
  }
    
  toggleConnectionMutation(genome){
    // create an array containing all IDs of the genome's connections
    let conIDs = Array.from(genome.connections.keys())
    
    // picks a random connection ID 
    let randConID = getRandValue(conIDs)
    
    genome.toggleConnectionMutation(randConID)
  }
    
  changeWeightsMutation(genome){
    // NEAT paper: "each weight had a 90% chance of being uniformly perturbed and a 10% chance of being assigned a new random value"
    for(let conID of genome.connections.keys()){
      let rand = random()
      
      if(rand < this.probabilities.shiftWeight){
        genome.shiftWeightMutation(conID)
      }
      else {
        genome.randomizeWeightMutation(conID)
      }
    }
  }
    
    changeBiasesMutation(genome){

    for(let nodeID of genome.nodes.keys()){
      let rand = random()
      
      if(rand < this.probabilities.shiftBias){
        genome.shiftBiasMutation(nodeID)
      }
      else {
        genome.randomizeBiasMutation(nodeID)
      }
    }
  }
}
    
    
// long list: https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
// recommendations: https://towardsdatascience.com/neuro-evolution-on-steroids-82bd14ddc2f6
class Activation {
  static sigmoid(x) {
    // NEAT paper uses a modified sigmoid function!
    // see here ways to modify: https://en.wikipedia.org/wiki/Logistic_function
    return 1 / (1 + Math.exp(-x));
  }
  
  static modifiedSigmoid(x){
    // modified as in NEAT paper
    return 1 / (1 + Math.exp(-4.9 * x));
  }
  
  static reLU(x){
    // https://en.wikipedia.org/wiki/Rectifier_(neural_networks)
    if(x > 0) return x
    else return 0
  }
  
  static hyperbolicTangent(x){
    // https://en.wikipedia.org/wiki/Hyperbolic_functions
    let numerator = Math.exp(2 * x) - 1
    let denominator = Math.exp(2 * x) + 1
    return numerator / denominator
  }
  
  static hardHyperbolicTangent(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return max(-1, min(1, x))
  }
  
  static identity(x) {
    // https://en.wikipedia.org/wiki/Identity_function
    return x
  }
  
  static binaryStep(x) {
    // https://en.wikipedia.org/wiki/Heaviside_step_function
    if(x > 0) return 1
    else return 0
  }
  
  static bipolar(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    if(x > 0) return 1
    if(x < 0) return -1
    else return 0
  }
  
  static bipolarSigmoid(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    let numerator = 1 - Math.exp(-x)
    let denominator = 1 + Math.exp(-x)
    return numerator / denominator
  }
  
  static absolute(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return abs(x)
  }
  
  static gaussian(x){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    return exp(-0.5 * sq(x))      
  }
  
  static piecewiseLinear(x, xMin, xMax){
    // https://stats.stackexchange.com/questions/115258/comprehensive-list-of-activation-functions-in-neural-networks-with-pros-cons
    if(x < xMin) return 0
    if(x > xMax) return 1
    
    let m = 1 / (xMax - xMin)
    let b = 1 - m * xMax
    return m * x + b
  }
}

