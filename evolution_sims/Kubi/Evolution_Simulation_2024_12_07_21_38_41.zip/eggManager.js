class EggManager {
  constructor() {
    this.eggs = []
  }
  
  update(){
    for(let i = this.eggs.length - 1; i >= 0; i--) {
      let e = this.eggs[i]
      e.update()
      if(e.hatched) this.eggs.splice(i, 1)
    }
  }
  
  renderEggs(){
    for (let e of this.eggs) {
      if(cam.inView(e.loc.x, e.loc.y, e.dia / 2)){
        e.render()
      }
    }
  }
}