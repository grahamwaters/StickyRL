class SpeciesManager {
  constructor(){
    this.species = new Map()
    this.nSpeciesAlive = 0
  }
}