class Game {
  constructor() {
    this.cage = new Cage(settings.cage.width, settings.cage.height)
    this.foodManager = new FoodManager(settings.food.initialAmount)
    this.eggManager = new EggManager()
    this.creatureManager = new CreatureManager(settings.population.initialSize)
    this.speciesManager = new SpeciesManager()

    this.time = new Counter("ascending", 1, settings.general.timePerFrame)
    this.year = new Counter("ascending", 0, settings.general.timePerFrame, 1)

    this.grid = new Grid()
    
    this.panelManager = new PanelManager()
  }

  init() {
    this.creatureManager.createInitialPopulation()

    this.focusedCreature = this.creatureManager.creatures[0]
    this.focusedCreature.focused = true
    
    this.setupBrainRendering()

    this.foodManager.createInitialFoods()

    this.grid.calcCellLocations()
    
    this.panelManager.panelBar1.speciesPanel.update(this.speciesManager.species)
  }

  update() {
    this.creatureManager.update()
    this.eggManager.update()
    this.foodManager.update()
    this.time.update()
    this.year.update()
    
    
    if(this.year.finished()){
      this.year.reset()
      this.panelManager.panelBar1.speciesPanel.update(this.speciesManager.species)
    }
  }
  
  updateAlways(){
    this.creatureManager.updateMin()
    this.panelManager.update()
    this.checkHover()
  }
  
  checkHover(){
    if(mouseX <= this.panelManager.panelBar1.w) {
      this.panelManager.panelBar1.checkHover()
    }
    else if(mouseX > cam.screen.x && mouseX < cam.screen.x + cam.screen.width){
      if(this.panelManager.timePanel.isHovered()){
        this.panelManager.timePanel.checkHover()
      }
      else{
        this.creatureManager.checkHover()
      }
    }
    else if(mouseX >= width - this.panelManager.panelBar2.w){
      this.panelManager.panelBar2.checkHover()
    }
  }

  focusCreature(creature) {
    this.focusedCreature.focused = false
    this.focusedCreature = creature
    this.focusedCreature.focused = true

    this.setupBrainRendering()
  }

  setCreatureFocus(ind) {
    if (ind < 0 && this.creatureManager.hoveredCreature) {
      this.focusedCreature.focused = false
      this.focusedCreature = this.creatureManager.hoveredCreature
      this.focusedCreature.focused = true

      this.setupBrainRendering()

      return true
    } else if (ind >= 0 && ind < this.creatureManager.creatures.length) {
      this.focusedCreature.focused = false
      this.focusedCreature = this.creatureManager.creatures[ind]
      this.focusedCreature.focused = true

      this.setupBrainRendering()

      return true
    }
    return false
  }

  setupBrainRendering() {
    let y = 0
    let w = this.panelManager.panelBar2.brainPanel.w
    let h = this.panelManager.panelBar2.brainPanel.h
    this.focusedCreature.brain.setupRendering(0, y, w, h)
    this.focusedCreature.brain.calcRenderLocs()
  }

  renderAllObjects() {
    push()
  translate(cam.screen.x + cam.world.x, cam.screen.y + cam.world.y);
  scale(cam.view.zoom)

    
    this.cage.render()
    this.grid.renderCells()
    this.foodManager.renderFood()
    this.eggManager.renderEggs()
    this.creatureManager.renderCreatures()
    
    pop()
    
    this.panelManager.render()
  }
}