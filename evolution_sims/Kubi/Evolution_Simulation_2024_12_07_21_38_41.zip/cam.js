class Cam {
  constructor(screenX, screenY, screenWidth, screenHeight, relWorldX, relWorldY) {
    // describes screen position and width in canvas
    this.screen = {
      x: screenX,
      y: screenY,
      width: screenWidth,
      height: screenHeight
    }
    
    // describes world center in relation to screen
    this.world = {
      x: this.screen.width * relWorldX,
      y: this.screen.height * relWorldY
    }
    
    this.viewPos = {
      prevX: null,
      prevY: null,
      isDragging: false
    }
    
    this.settings = {
      zoomStep: 0.25,
      minZoom: 0.25,
      maxZoom: 4
    }

    // describes part of the world that is visible
    this.view = {
      x: 0,
      y: 0,
      xMin: -this.world.x,
      xMax: this.screen.width - this.world.x,
      yMin: -this.world.y,
      yMax: this.screen.height - this.world.y,
      zoom: 1
    }
    
    this.tracking = true
  }
  
  toggleTracking() {
   this.tracking = !this.tracking
  }
  
  inView(worldX, worldY, buffer){
    let inXView = false
    let inYView = false
    
    if(!buffer) buffer = 0

    if (worldX + buffer > this.view.xMin && worldX - buffer < this.view.xMax) {
      inXView = true
    }
    if (worldY + buffer > this.view.yMin && worldY - buffer < this.view.yMax) {
      inYView = true 
    }
    
    return (inXView && inYView) ? true : false
  }
  
  calcWorldPos(screenX, screenY){
    let x = (screenX - this.world.x - this.screen.x) / this.view.zoom
    let y = (screenY - this.world.y - this.screen.y) / this.view.zoom
    
    return createVector(x, y)
  }
  
  setView(worldX, worldY){
    this.view.x = worldX
    this.view.y = worldY
    
    this.updateWorld()
  }
  
  updateWorld() {
    this.world.x = this.screen.width / 2 - this.view.x * this.view.zoom
    this.world.y = this.screen.height / 2 - this.view.y * this.view.zoom
    
    this.updateFrame()
  }

  updateView() {
    this.updateFrame()

    this.view.x =  this.view.xMin + (this.view.xMax -  this.view.xMin) / 2
    this.view.y = this.view.yMin + (this.view.yMax - this.view.yMin) / 2
  }
  
  updateFrame() {
    this.view.xMin = -this.world.x / this.view.zoom
    this.view.xMax = (this.screen.width / this.view.zoom) - (this.world.x / this.view.zoom)
    
    this.view.yMin = -this.world.y / this.view.zoom
    this.view.yMax = (this.screen.height / this.view.zoom) - (this.world.y / this.view.zoom)
  }

  mousePressed(e) {
      this.viewPos.isDragging = true;
      this.viewPos.prevX = e.clientX;
      this.viewPos.prevY = e.clientY;
    this.tracking = false
  }

  mouseDragged(e) {
   
    const {
      prevX,
      prevY,
      isDragging
    } = this.viewPos;
    if (!isDragging) return;

    const pos = {
      x: e.clientX,
      y: e.clientY
    };
    const dx = pos.x - prevX;
    const dy = pos.y - prevY;

    if (prevX || prevY) {
      this.world.x += dx;
      this.world.y += dy;
      this.viewPos.prevX = pos.x
      this.viewPos.prevY = pos.y

      this.updateView()
    }
                                                                      
  }

  mouseReleased() {
    this.viewPos.isDragging = false;
    this.viewPos.prevX = null;
    this.viewPos.prevY = null;
  }

  zoom(e) {
    if(mouseX > this.screen.x && mouseX < this.screen.x + this.screen.width){
    const {
      x,
      y,
      deltaY
    } = e;

    const direction = deltaY > 0 ? -1 : 1;
    const factor = this.settings.zoomStep;
    const zoom = direction * factor;
    
    if((this.view.zoom < this.settings.maxZoom && direction > 0) || (this.view.zoom > this.settings.minZoom && direction < 0)){
      const wx = (x - this.screen.x - this.world.x) / (this.screen.width * this.view.zoom);
      const wy = (y - this.screen.y - this.world.y) / (this.screen.height * this.view.zoom);

      this.world.x -= wx * this.screen.width * zoom;
      this.world.y -= wy * this.screen.height * zoom;
      this.view.zoom += zoom;
      
      this.view.zoom = clamp(this.view.zoom, this.settings.minZoom, this.settings.maxZoom)

      this.updateView()
    }
    }
  }
}