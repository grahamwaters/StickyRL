class Egg {
  constructor(creatureID, species, generation, type, loc, genes) {
    this.creatureID = creatureID
    this.species = species
    this.generation = generation
    this.loc = loc
    this.type = type

    this.brain = genes.brain
    this.traits = genes.traits
    
    
    this.hatchTimer = new Counter("descending", settings.egg.hatchTime, 1, 0)
    this.hatched = false

    this.dia = settings.egg.dia
    
    this.color = this.traits.color
  }
  
  update(){
    this.hatchTimer.update()
    
    if(this.hatchTimer.finished()){
      let offspring = new Creature(this.creatureID, this.species, this.generation, this.type, this.brain, this.traits, this.loc.copy())
      game.creatureManager.creatures.push(offspring)
      
      this.hatched = true
    }
  }
  
  render(){
    stroke(255)
    strokeWeight(1)
    fill(this.color.red, this.color.green, this.color.blue)
    circle(this.loc.x, this.loc.y, this.dia)
    point(this.loc.x, this.loc.y)
  }
}

