class PanelManager {
  constructor() {
    
    this.panelBar1 = new PanelBar1(0, 0, settings.panel.bar.width, height)
    this.panelBar2 = new PanelBar2(width - settings.panel.bar.width, 0, settings.panel.bar.width, height)
    
    this.timePanel = new TimePanel(width / 2 - 150, 15, 300, 70, 40)
  }
  
  update(){
    this.panelBar2.update()
    this.timePanel.sliderSimSpeed.update()
    //this.checkHover(this.brainPanel)
    //this.checkHover(this.tilemapPanel)
  }
  
  render(){
    this.panelBar1.render()
    this.panelBar1.renderTextElements()
    this.panelBar1.renderPanels()
    this.panelBar2.render()
    this.panelBar2.renderTextElements()
    this.panelBar2.renderPanels()
    this.timePanel.render()
  }
  
}