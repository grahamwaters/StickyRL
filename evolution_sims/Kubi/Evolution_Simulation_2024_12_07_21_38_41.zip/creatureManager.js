class CreatureManager {
  constructor(popSize) {
    this.popSize = popSize

    let labels = {
      input: ['angle creature left (view)',
        'angle creature right (view)',
        'distance creature (view)',
        'creature in tounge range (view)',
        'dissimilarity creature (view)',
        'angle food left (view)',
        'angle food right (view)',
        'distance food (view)',
        'energy',
        'fertility',
        'attack charge',
        'temperature difference'
      ],
      output: ['move forward',
        'turn right',
        'turn left',
        'reproduce',
        'attack'
      ]
    }
    this.neat = new Neat(12, 5, labels)

    this.nRenderedCreatures = 0 // for stats
    this.creatures = []
  }

  createInitialPopulation() {
    for (let i = 0; i < this.popSize; i++) {
      let newCreature = new Creature(i, i, 1, "pioneer", this.neat.createGenome(i))
      this.creatures.push(newCreature)
    }
    
    this.nextCreatureID = this.popSize
    this.nextSpeciesID = this.popSize
  }
  
  updateMin(){
    for(let c of this.creatures) c.updateMin()
  }
  
  checkHover(){
    let hoveredCreature
    this.hoveredCreature = undefined
    
    for (let c of game.grid.cells) {
      if (cam.inView(c.centerLoc.x, c.centerLoc.y, c.size / 2)) {

        for (let cr of c.creatures) {
          if (cam.inView(cr.loc.x, cr.loc.y, cr.traits.size / 2)) {
            if (cr.isHovered()) {
              hoveredCreature = cr
            }
          }
        }
      }
    }
    if (hoveredCreature) {
      hoveredCreature.hovered = true
      this.hoveredCreature = hoveredCreature
    }
  }

  update() {

    let focusNewCreature = false
    
    for (let i = this.creatures.length - 1; i >= 0; i--) {
      let c = this.creatures[i]
      c.update()
      if (!c.alive) {
        let newFood = new Food(c.loc.copy())
        newFood.setValueBasedOnCreatureSize(c.traits.size)
        game.foodManager.foods.push(newFood)

        if (c.focused) focusNewCreature = true
        c.die()

        this.creatures.splice(i, 1)
        continue
      }

      
    }
    if(focusNewCreature) {
      game.setCreatureFocus(floor(random(game.creatureManager.creatures.length)))                  
    }

    /*let hoveredCreature
    this.hoveredCreature = undefined

    let focusNewCreature = false
    
    for (let i = this.creatures.length - 1; i >= 0; i--) {
      let c = this.creatures[i]
      c.update()
      if (!c.alive) {
        let newFood = new Food(c.loc.copy())
        newFood.setValueBasedOnCreatureSize(c.traits.size)
        game.foodManager.foods.push(newFood)

        if (c.focused) focusNewCreature = true
        c.die()

        this.creatures.splice(i, 1)
        continue
      }

      if (cam.inView(c.loc.x, c.loc.y, c.traits.size / 2)) {
        if (c.isHovered()) {
          hoveredCreature = c
        }
      }
    }
    if(focusNewCreature) {
      game.setCreatureFocus(floor(random(game.creatureManager.creatures.length)))                  
    }

    if (hoveredCreature) {
      hoveredCreature.hovered = true
      this.hoveredCreature = hoveredCreature
    }*/
  }

  findClosestRelative(creature) {
    let minDist = Infinity
    let closestRelative

    for (let c of this.creatures) {
      if (c != creature) {
        let dist = game.creatureManager.neat.calcDistance(creature.brain, c.brain)
        if (dist < minDist) {
          minDist = dist
          closestRelative = c
        }
      }
    }
    return closestRelative
  }

  renderCreatures() {
    this.nRenderedCreatures = 0
    let focusedCreature
    let hoveredCreature
    for (let c of game.grid.cells) {
      if (cam.inView(c.centerLoc.x, c.centerLoc.y, c.size / 2)) {

        for (let cr of c.creatures) {
          if (cam.inView(cr.loc.x, cr.loc.y, cr.traits.size / 2)) {
            if(cr.focused) focusedCreature = cr
            else cr.render()
            if(cr.hovered) hoveredCreature = cr
            this.nRenderedCreatures++
          }
        }
      }
    }
    // render focused creature and hovered creature last
    if(focusedCreature) focusedCreature.render()
    if(hoveredCreature) hoveredCreature.renderHoverRing()
    
    
  }
}