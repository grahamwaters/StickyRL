class Cage {
  constructor(w, h) {
    this.w = w
    this.h = h
  }
  
  getTemperatureFromYLoc(yLoc){
    let temperature = map(yLoc + this.h / 2, 0, this.h, 0, 1)
    return temperature
  }
  
  render() {
    
    // border
    stroke(255)
    strokeWeight(1)
    noFill()
    rectMode(CENTER)
    rect(0, 0, this.w, this.h)
    rectMode(CORNER)
    
    // center
    line(0, -20, 0, 20)
    line(-20, 0, 20, 0)
  }
}