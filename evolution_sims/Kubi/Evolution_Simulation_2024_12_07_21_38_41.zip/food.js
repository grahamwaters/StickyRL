class Food {
  constructor(loc){
    this.value = random(settings.food.value.min, settings.food.value.max)
    
    this.dia = this.setDiaBasedOnValue()
    
    let cage = game.cage
    
    if(loc) this.loc = loc
    else {
      this.loc = createVector(random(-cage.w / 2 + this.dia / 2, cage.w / 2 - this.dia / 2), random(-cage.h / 2 + this.dia / 2, cage.h / 2 - this.dia / 2))
    }
    
    this.cellId = game.grid.getCellInfoFromLoc(this.loc.copy()).cellId
    game.grid.insertInto(this, this.cellId)
    
    this.eaten = false
  }
  
  die() {
    game.grid.removeFrom(this, this.cellId)
  }
  
 setValueBasedOnCreatureSize(size) {
   this.value = map(size, settings.creature.size.minTotal, settings.creature.size.maxTotal, settings.food.value.min, settings.food.value.max)
   this.dia = this.setDiaBasedOnValue()
 }
  
  setDiaBasedOnValue(){
    return map(this.value, settings.food.value.min, settings.food.value.max, settings.food.dia.min, settings.food.dia.max)
  }
  
  render() {
    stroke(200)
    strokeWeight(1)
    fill(255, 80, 0)
    circle(this.loc.x, this.loc.y, this.dia)
  }
}