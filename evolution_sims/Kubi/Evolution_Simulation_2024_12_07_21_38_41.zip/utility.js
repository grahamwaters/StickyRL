class Slider{
  constructor(minValue, maxValue, defaultValue, step){
    this.minValue = minValue
    this.maxValue = maxValue
    this.value = defaultValue
    this.tempValue = this.value
    this.step = step
    
    this.x = 0
    this.y = 0
    this.w = 100
    
    this.rThumb = 6
    this.xTrack = this.x + this.rThumb
    this.wTrack = this.w - 2 * this.rThumb
    
    this.dragged = false
    this.hovered = false
    this.prevX = null
    
    this.updateThumbPosition()
  }
  
  position(x, y, w){
    this.x = x
    this.y = y
    this.w = w
    this.xTrack = this.x + this.rThumb
    this.wTrack = this.w - 2 * this.rThumb
    this.updateThumbPosition()
  }
  
  mouseOnThumb(){
    let dist = p5.Vector.sub(createVector(this.xThumb, this.y), createVector(mouseX, mouseY)).mag()
    if(dist <= this.rThumb) return true
    return false
  }
  
  mouseHovered(){
    this.hovered = false
    if(this.mouseOnThumb()){
      this.hovered = true
    }
  }
  
  mousePressed() {
    this.dragged = false
    
    if(this.mouseOnThumb()){
      this.prevX = mouseX
      this.dragged = true
    }
  }
  
  mouseDragged(){
    if(this.dragged){
    let dX
    let mouseTooLow = false
    let mouseTooHigh = false
    if(mouseX <= this.xTrack){
      if(this.prevX > this.xTrack) {
        dX = this.xTrack - this.prevX
      }
      else dX = 0
      this.prevX = this.xTrack
      mouseTooLow = true
    }
    else if(mouseX > this.xTrack && mouseX < this.xTrack + this.wTrack){
      dX = mouseX - this.prevX
      this.prevX = mouseX
    }
    else {
      if(this.prevX < this.xTrack + this.wTrack) {
        dX = this.xTrack + this.wTrack - this.prevX
      }
      else dX = 0
      this.prevX = this.xTrack + this.wTrack
      mouseTooHigh = true
    }
    
    let valuePerPixel = (this.maxValue - this.minValue) / this.wTrack
    let dValue = dX * valuePerPixel
    
    this.tempValue += dValue
    let deltaTempActual = this.tempValue - this.value
    let steppedDeltaTempActual = round(deltaTempActual * (1 / this.step)) / (1 / this.step)

    if (abs(steppedDeltaTempActual) >= this.step){
      this.value += steppedDeltaTempActual
    }
    
    if(this.value < this.minValue || mouseTooLow) this.value = this.minValue
    if(this.value > this.maxValue || mouseTooHigh) this.value = this.maxValue
    this.updateThumbPosition()
    }
  }
  
  mouseReleased(){
    this.dragged = false
    this.tempValue = this.value
  }
  
  update(){
    this.hovered = false
    //this.dragged = false
  }
  
  updateThumbPosition(){
    this.xThumb = this.xTrack + map(this.value, this.minValue, this.maxValue, 0, this.wTrack)
  }
  
  render(){
    // track
    stroke(255)
    strokeWeight(4)
    line(this.xTrack, this.y, this.xTrack + this.wTrack, this.y)
    
    // thumb
    if(this.hovered || this.dragged) {
      fill(settings.color.blue3.r, settings.color.blue3.g, settings.color.blue3.b)
      stroke(255)
    }
    else {
      fill(settings.color.blue2.r, settings.color.blue2.g, settings.color.blue2.b)
      noStroke()
    }
    
    strokeWeight(1)
    
    circle(this.xThumb, this.y, this.rThumb * 2)
    //strokeWeight(this.rThumb * 2)
    //point(this.xThumb, this.y)
  }
}


class Counter {
  constructor(type, defaultValue, step, threshold) {
    this.type = type // ascending or descending
    this.defaultValue = defaultValue
    this.value = defaultValue
    this.step = step
    this.threshold = threshold
  }

  update() {
    if (this.type == "ascending") this.value += this.step
    else if (this.type == "descending") this.value -= this.step
  }

  changeValueBy(value) {
    this.value += value
  }

  setValueTo(value) {
    this.value = value
  }

  finished() {
    if (this.type == "ascending") {
      if (this.value >= this.threshold) return true
    } else if (this.type == "descending") {
      if (this.value <= this.threshold) return true
    }
    return false
  }

  reset() {
    this.value = this.defaultValue;
  }
}

function findIndex(array, value) {
  for (let i = 0; i < array.length; i++) {
    if (array[i] == value) return i
  }
  return -1
}

function getRandValue(array) {
  let randInd = floor(random(array.length))
  return array[randInd]
}

function getRandKey(map){
  let keys = Array.from(map.keys())
  return keys[floor(random(keys.length))]
}

function roundDecimals(value, nDigits) {
  let factor = pow(10, nDigits)
  let result = round(value * factor) / factor
  return result
}

class FramerateTracker {
  constructor(x, y, tint, framerate) {
    this.x = x
    this.y = y
    this.tint = tint
    this.logFramerate = [];
    this.avgFramerate = framerate;
  }
  update(framerate) {
    let lArray = 30;
    if (this.logFramerate.length >= lArray) {
      this.logFramerate.splice(0, 1);
    }
    this.logFramerate.push(framerate);
    let avg = 0;
    for (let i = 0; i < this.logFramerate.length; i++) {
      avg += this.logFramerate[i];
    }
    this.avgFramerate = avg / this.logFramerate.length;
  }

  render() {
    let str = parseInt(this.avgFramerate) + " fps";

    if (this.tint == "white") {
      let notRed = map(this.avgFramerate, 30, 55, 0, 255);
      fill(255, notRed, notRed, 200);
    } else if (this.tint == "black") {
      var red = map(this.avgFramerate, 30, 55, 255, 0);
      fill(red, 0, 0);
    }

    textAlign(RIGHT, TOP);
    textSize(14);
    noStroke();
    text(str, this.x, this.y);
  }
}

function clamp(value, min, max) {
  if (value < min) return min
  if (value > max) return max
  else return value
}

function greatestCommonDivisor(a, b) {
  // https://de.wikipedia.org/wiki/Euklidischer_Algorithmus
  if (b == 0) return a

  else {
    return greatestCommonDivisor(b, a % b)
  }
}

function findFactors(n) {
  // https://de.wikipedia.org/wiki/Probedivision
  let primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271]

  let ind = 0
  let p = primes[ind]
  let factors = [n]
  let x = n
  let count = 0

  if (sq(primes[primes.length - 1]) >= n) {
    while (sq(p) <= n) {
      if (x % p == 0) {
        x /= p
        if (!factors.includes(x)) factors.push(x)
        if (!factors.includes(p)) factors.push(p)

        count++
      } else {
        if (count > 1 && !factors.includes(count * p)) factors.push(count * p)
        count = 0
        ind++
        p = primes[ind]
      }
    }

    if (!factors.includes(1)) factors.push(1)
    factors = sort(factors)
    return factors
  } else return -1
}

class Intersection {
  // http://jeffreythompson.org/collision-detection/line-circle.php
  // LINE/CIRCLE
  static lineCircle(x1, y1, x2, y2, cx, cy, r) {

    // is either end INSIDE the circle?
    // if so, return true immediately
    let inside1 = Intersection.pointCircle(x1, y1, cx, cy, r);
    let inside2 = Intersection.pointCircle(x2, y2, cx, cy, r);
    if (inside1 || inside2) return true;

    // get length of the line
    let distX = x1 - x2;
    let distY = y1 - y2;
    let len = sqrt((distX * distX) + (distY * distY));

    // get dot product of the line and circle
    let dot = (((cx - x1) * (x2 - x1)) + ((cy - y1) * (y2 - y1))) / pow(len, 2);

    // find the closest point on the line
    let closestX = x1 + (dot * (x2 - x1));
    let closestY = y1 + (dot * (y2 - y1));

    // is this point actually on the line segment?
    // if so keep going, but if not, return false
    let onSegment = Intersection.linePoint(x1, y1, x2, y2, closestX, closestY);
    if (!onSegment) return false;

    // get distance to closest point
    distX = closestX - cx;
    distY = closestY - cy;
    let distance = sqrt((distX * distX) + (distY * distY));

    if (distance <= r) {
      return true;
    }
    return false;
  }


  // POINT/CIRCLE
  static pointCircle(px, py, cx, cy, r) {

    // get distance between the point and circle's center
    // using the Pythagorean Theorem
    let distX = px - cx;
    let distY = py - cy;
    let distance = sqrt((distX * distX) + (distY * distY));

    // if the distance is less than the circle's
    // radius the point is inside!
    if (distance <= r) {
      return true;
    }
    return false;
  }


  // LINE/POINT
  static linePoint(x1, y1, x2, y2, px, py) {

    // get distance from the point to the two ends of the line
    let d1 = dist(px, py, x1, y1);
    let d2 = dist(px, py, x2, y2);

    // get the length of the line
    let lineLen = dist(x1, y1, x2, y2);

    // since floats are so minutely accurate, add
    // a little buffer zone that will give collision
    let buffer = 0.1; // higher # = less accurate

    // if the two distances are equal to the line's
    // length, the point is on the line!
    // note we use the buffer here to give a range,
    // rather than one #
    if (d1 + d2 >= lineLen - buffer && d1 + d2 <= lineLen + buffer) {
      return true;
    }
    return false;
  }
  
  // CIRCLE/RECTANGLE
  static circleRect(cx, cy, radius, rx, ry, rw, rh) {

  // temporary variables to set edges for testing
  let testX = cx;
  let testY = cy;

  // which edge is closest?
  if (cx < rx)         testX = rx;      // test left edge
  else if (cx > rx+rw) testX = rx+rw;   // right edge
  if (cy < ry)         testY = ry;      // top edge
  else if (cy > ry+rh) testY = ry+rh;   // bottom edge

  // get distance from closest edges
  let distX = cx-testX;
  let distY = cy-testY;
  let distance = sqrt( (distX*distX) + (distY*distY) );

  // if the distance is less than the radius, collision!
  if (distance <= radius) {
    return true;
  }
  return false;
}
}

function displayClickRequest() {
  fill(255, 50);
  noStroke();
  rect(0, 0, width, height);

  noStroke();
  textSize(20);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Click here to activate the simulation", width / 2, height / 2);
}