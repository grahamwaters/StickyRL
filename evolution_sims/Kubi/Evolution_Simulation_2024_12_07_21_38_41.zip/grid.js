class Grid {
  constructor() {
    this.cellSize = this.calcCellSize()

    this.cells = []

    this.nCellsX = settings.cage.width / this.cellSize
    this.nCellsY = settings.cage.height / this.cellSize

    for (let i = 0; i < this.nCellsX * this.nCellsY; i++) {
      let x = this.calcGridXFromId(i)
      let y = this.calcGridYFromId(i)

      let temperatureZone = map(y, 0, this.nCellsY - 1, 0, 1)
      this.cells.push(new Cell(i, x, y, temperatureZone, this.cellSize))
    }
  }

  query(cellId, radius, type) {
    let gridX = this.calcGridXFromId(cellId)
    let gridY = this.calcGridYFromId(cellId)

    let queryIds = [cellId]

    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {

        if (dx == 0 && dy == 0) continue

        let x = gridX + dx
        let y = gridY + dy

        if (x < 0 || y < 0) continue
        if (x >= this.nCellsX || y >= this.nCellsY) continue

        let id = y * this.nCellsX + x
        queryIds.push(id)
      }
    }

    let creatures = []
    let foods = []

    for (let i = 0; i < queryIds.length; i++) {
      let id = queryIds[i]
      if (type == "creature" || type == "both") {
        creatures = creatures.concat(this.cells[id].creatures)
      }
      if (type == "food" || type == "both") {
        foods = foods.concat(this.cells[id].foods)
      }
    }
    return {
      creatures: creatures,
      foods: foods
    }
  }

  calcCellSize() {
    let largestPossibleSize = greatestCommonDivisor(settings.cage.width, settings.cage.height)
    let possibleSizes = findFactors(largestPossibleSize)
    let visionRange = settings.creature.vision.range.maxTotal

    let size = possibleSizes[0]

    for (let i = 1; i < possibleSizes.length; i++) {
      if (possibleSizes[i] >= visionRange) {
        size = possibleSizes[i]
        break
      }
    }
    return size
  }

  calcGridXFromId(cellId) {
    return cellId % this.nCellsX
  }

  calcGridYFromId(cellId) {
    return floor(cellId / this.nCellsX)
  }

  // not in use (?)
  calcCellIdFromLoc(loc) {
    let locX = loc.x + game.cage.w / 2
    let locY = loc.y + game.cage.h / 2

    let gridX = floor(locX / this.cellSize)
    let gridY = floor(locY / this.cellSize)

    let cellID = gridY * this.nCellsX + gridX

    return cellID
  }

  getCellInfoFromLoc(loc) {
    let locX = loc.x + game.cage.w / 2
    let locY = loc.y + game.cage.h / 2

    let gridX = floor(locX / this.cellSize)
    let gridY = floor(locY / this.cellSize)

    let cellId = gridY * this.nCellsX + gridX

    return {
      cellId: cellId,
      gridX: gridX,
      gridY: gridY
    }
  }

  insert(object) {
    let cellId = this.calcCellIdFromLoc(object.loc.copy())
    this.cells[cellId].addObject(object)
  }

  insertInto(object, cellId) {
    if (this.cells[cellId] != undefined) {
      this.cells[cellId].addObject(object)
    } else {
      print("error grid.insertInto")
      print(object)
      print(cellId)
    }
  }

  removeFrom(object, cellId) {
    this.cells[cellId].removeObject(object)
  }

  test() {
    let sum = 0
    for (let c of this.cells) {
      sum += c.creatures.length
    }
    print(sum)
  }

  calcCellLocations() {
    for (let c of this.cells) c.calcLocation()
  }

  renderCells() {
    for (let c of this.cells) {

      if (cam.inView(c.centerLoc.x, c.centerLoc.y, c.size / 2)) {
        c.render()
      }
    }
  }
}


class Cell {
  constructor(id, x, y, temperatureZone, size) {
    this.x = x
    this.y = y
    this.id = id
    this.temperatureZone = temperatureZone
    this.size = size

    this.centerLoc = createVector()

    this.creatures = []
    this.foods = []
  }

  calcLocation() {
    let centerX = this.x * this.size + this.size / 2 - game.cage.w / 2
    let centerY = this.y * this.size + this.size / 2 - game.cage.h / 2

    this.centerLoc.set(centerX, centerY)
  }

  addObject(object) {
    if (object instanceof Creature) {
      this.creatures.push(object)
    } else if (object instanceof Food) {
      this.foods.push(object)
    }
  }

  removeObject(object) {
    if (object instanceof Creature) {
      let ind = this.creatures.indexOf(object)
      this.creatures.splice(ind, 1)
    } else if (object instanceof Food) {
      let ind = this.foods.indexOf(object)
      this.foods.splice(ind, 1)
    }
  }

  render() {
    stroke(255, 10)
    strokeWeight(1)

    if (showClimate) {
      let r, g, b

      let min = 25
      let max = 100
      r = map(this.temperatureZone, 0, 1, min, max)
      g = min
      b = map(this.temperatureZone, 0, 1, max, min)
      fill(r, g, b)
    } else noFill()
    rect(this.x * this.size - game.cage.w / 2, this.y * this.size - game.cage.h / 2, this.size, this.size)
  }
}