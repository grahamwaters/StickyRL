class Obstacle {
  constructor() {
    this.pos = createVector(round(random(width)), round(random(height)));
    this.dia = round(random(minDiaObstacle, maxDiaObstacle));
    this.checkSpace();
  }

  checkSpace() {
    let dist;

    dist = p5.Vector.sub(start, this.pos).mag();
    if (dist < 2 * this.dia) {
      this.pos = createVector(round(random(width)), round(random(height)));
      this.checkSpace();
      return;
    }

    dist = p5.Vector.sub(target, this.pos).mag();
    if (dist < 2 * this.dia) {
      this.pos = createVector(round(random(width)), round(random(height)));
      this.checkSpace();
      return;
    }

    let diaTemp;
    for (let o of obstacles) {
      dist = p5.Vector.sub(o.pos, this.pos).mag();
      if (dist < this.dia / 2 + o.dia / 2) {
        if (dist > o.dia / 2 + minDiaObstacle / 2) {
          this.dia = dist - o.dia / 2;
        } else {
          this.pos = createVector(round(random(width)), round(random(height)));
        }
        this.checkSpace();
        return;
      }
    }
  }

  display() {
    stroke(255, 150);
    strokeWeight(1);
    noFill();
    circle(this.pos.x, this.pos.y, this.dia);
  }
}