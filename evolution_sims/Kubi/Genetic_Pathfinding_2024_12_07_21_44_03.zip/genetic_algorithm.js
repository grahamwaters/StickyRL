class GeneticAlgorithm {
  constructor() {
    this.init();
  }
  
  init(){
    this.maxScore = 0;
    this.summedScore = 0;
  }

  evaluate(runner) {
    let score;
    if (runner.crashed) score = 0;
    else {
      let distTarget = p5.Vector.sub(target, runner.lastLoc).mag();
      score = 1 / distTarget;
    }
    this.summedScore += score;
    if(score > this.maxScore) this.maxScore = score;
    
    return score;
  }

  makeNewGen() {
    let newGen = [];
    let fitness, rand, ind;
    let newRunner;

    for (let i = 0; i < nRunners; i++) {
      
      rand = random();

      while (rand > 0) {
        ind = floor(random(nRunners - 1));
        rand -= search.runners[ind].score/this.summedScore;
      }
      newRunner = new Runner(true);
      let father = search.runners[ind];
      let mutationRate = map(father.score, 0, this.maxScore, 0.7, 0.01);
      let smoothRate = 0.1;
      let genome;
      
      let iMax = father.stepCollision-50;
      if(iMax < 0) iMax = 1;
      
      for(let i = 0; i < iMax; i++){
        genome = father.genes[i];
        if(random() < mutationRate){
          genome.rotate(random(-PI/10, PI/10));
        }
        
        if(random() < smoothRate && i < iMax-2){
          genome.add(father.genes[i+1]);
          genome.setMag(genome.mag()/2);
        }
        newRunner.genes.push(genome);
      }
      newGen.push(newRunner);
    }
    return newGen;
  }
}