class Search {
  constructor() {
    this.runners = [];

    this.init();
    
    
  }

  init() {
    this.finished = false;
    this.nRunnersEvaluated = 0;
    if (generation == 1) {
      for (let i = 0; i < nRunners; i++) {
        this.runners[i] = new Runner(false);
      }
    } else {
      ga.init();
      this.runners = ga.makeNewGen();
    }
  }

  update() {
    if (this.nRunnersEvaluated < nRunners) {
      for (let r of this.runners) r.update();
    } else {
      this.finished = true;
    }
  }

  display() {
    for (let r of this.runners) r.display();
  }
}