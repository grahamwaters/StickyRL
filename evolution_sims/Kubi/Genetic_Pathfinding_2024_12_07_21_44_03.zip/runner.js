class Runner {
  constructor(inherit) {
    this.heir = inherit;
    this.loc = start.copy();
    this.genes = [];
    if (!this.heir) {
      this.initDNA();
    }
    this.nSteps = 0;

    // states
    this.collided = false; // true when collision with obstacle; mainly used for color choise and evaluation; runners continue running when collided = true
    this.alive = true; // false when outside frame or when target reached; runner stops running when alive = false
    this.evaluated = false;

    this.crashed = false; // true when runner hits any wall but right wall
  }

  initDNA() {

    // first genome is random
    let genome = p5.Vector.random2D();
    genome.setMag(stepSize);
    this.genes.push(genome);
  }

  update() {
    if (this.alive) {
      let genome;

      if (!this.heir) {
        genome = this.createNewGenome();
        this.genes.push(genome);
      } else if (this.heir) {
        if (this.nSteps < this.genes.length) {
          genome = this.genes[this.nSteps];
        } else {
          if(!this.blub){
          stroke(255, 255, 0);
          strokeWeight(3);
          point(this.loc.x, this.loc.y);
            this.blub = true;
          }
          
          genome = this.createNewGenome();
          this.genes.push(genome);
        }
      }

      this.loc.add(genome);
      this.nSteps++;

      this.checkCollision();
      this.checkWalls();
      this.checkTarget();
    }
    if (this.collided && !this.evaluated) {
      search.nRunnersEvaluated++;
      this.score = ga.evaluate(this);
      this.evaluated = true;
    }
  }

  createNewGenome() {
    let genome;
    let straightCon = p5.Vector.sub(target, start);
    let rand = random();

    // go random
    if (rand < 0.3) {
      genome = p5.Vector.random2D();
    }

    // go straight ahead
    else if (rand >= 0.3 && rand < 0.9 && this.genes.length>0) {
      genome = this.genes[this.genes.length - 1].copy();
    }

    // go towards target
    else {
      genome = straightCon.copy();
    }

    genome.setMag(stepSize);
    return genome;
  }

  checkCollision() {
    let dist;
    for (let o of obstacles) {
      dist = p5.Vector.sub(o.pos, this.loc).mag();
      if (dist <= o.dia / 2) {
        if(!this.collided) this.stepCollision = this.nSteps;
        this.collided = true;
        
        this.lastLoc = this.loc.copy();
        return;
      }
    }
  }

  checkWalls() {
    if (this.loc.x < 0 || this.loc.x > width || this.loc.y < 0 || this.loc.y > height) {

      if (this.loc.x < width && !this.collided) this.crashed = true;
      if(!this.collided) this.stepCollision = this.nSteps;
      this.collided = true;
      this.alive = false;
      this.lastLoc = this.loc.copy();

    }
  }

  checkTarget() {
    let dist = p5.Vector.sub(target, this.loc).mag();
    if (dist < targetDia/2) {
      if(!this.collided) this.stepCollision = this.nSteps;
      if(!this.collided) print("target");
      this.collided = true;
      this.alive = false;
      this.lastLoc = this.loc.copy();
      
    }
  }

  display() {
    if (!this.collided) stroke(0, 255, 0, 100);
    else stroke(255, 20);
    strokeWeight(1);
    point(this.loc.x, this.loc.y);
    if (this.crashed) {
      stroke(255, 0, 0);
      strokeWeight(10);
      point(this.lastLoc.x, this.lastLoc.y);
    }
  }
}