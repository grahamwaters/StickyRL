function keyPressed(){
 if(key === "p" || key === "P"){
   paused = !paused;
 }
}