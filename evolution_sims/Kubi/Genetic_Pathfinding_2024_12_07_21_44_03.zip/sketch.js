const nRunners = 100;
let generation = 1;
const stepSize = 2;
const nObstacles = 90;
const minDiaObstacle = 20;
const maxDiaObstacle = 40;
const simSpeed = 50;
const targetDia = 15;
paused = false;

function setup() {
  createCanvas(700, 400);
  start = createVector(50, height / 2);
  target = createVector(width - 50, height / 2);
  ga = new GeneticAlgorithm();

  obstacles = [];
  for (let i = 0; i < nObstacles; i++) obstacles.push(new Obstacle());

  search = new Search();
background(0);
  for (let o of obstacles) o.display();

}

function draw() {
  if (!paused) {
    if (!search.finished) {
      for (let i = 0; i < simSpeed; i++) {
        search.update();

        displayStartAndTarget();
        search.display();
      }
    } else if (search.finished) {
      generation++;
      search.init();
      background(0);
      displayStartAndTarget();
      for (let o of obstacles) o.display();
    }
  }
}

function displayStartAndTarget() {
  strokeWeight(5);
  stroke(0, 0, 255);
  point(start.x, start.y);
  noFill();
  stroke(0, 255, 0);
  strokeWeight(1);
  circle(target.x, target.y, targetDia);
}